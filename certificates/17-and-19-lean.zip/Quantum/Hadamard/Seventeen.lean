import Quantum.Hadamard.SeventeenExtenders
import Quantum.Hadamard.SeventeenStarts
import Quantum.Hadamard.GoethalsProgression
import Quantum.Hadamard.GoethalsResidues

namespace HadamardMod
open Seventeen
set_option maxRecDepth 500000
set_option maxHeartbeats 0

theorem seventeen_all (k : ℕ) : AtOrder 17 (4*k) := by
  by_cases zero : k=0
  · subst k; simpa using empty_order 17
  have pos : 0<k := by omega
  by_cases easy : k%17≤4
  · exact goethals_residue easy

  have rem := Nat.mod_lt k (by decide : 0<17)
  have m : (4*k)%17=(4*(k%17))%17 := by simp [Nat.mul_mod]
  have hard : (4*k)%17=1 ∨ (4*k)%17=2 ∨ (4*k)%17=3 ∨ (4*k)%17=5 ∨ (4*k)%17=6 ∨ (4*k)%17=7 ∨ (4*k)%17=9 ∨ (4*k)%17=10 ∨ (4*k)%17=11 ∨ (4*k)%17=13 ∨ (4*k)%17=14 ∨ (4*k)%17=15 := by
    rw [m]
    generalize z : k%17 = v at *
    interval_cases v <;> norm_num at *
  rcases hard with h|h|h|h|h|h|h|h|h|h|h|h
  · exact extend_seed_progression (b:=255) (u:=4) d1 (by decide) (by decide) (by decide)
      seed1 pos h
  · exact extend_seed_progression (b:=17) (u:=2) d2 (by decide) (by decide) (by decide)
      seed2 pos h
  · exact extend_seed_progression (b:=204) (u:=1) d3 (by decide) (by decide) (by decide)
      seed3 pos h
  · exact extend_seed_progression (b:=646) (u:=1) d5 (by decide) (by decide) (by decide)
      seed5 pos h
  · exact extend_seed_progression (b:=68) (u:=1) d6 (by decide) (by decide) (by decide)
      seed6 pos h
  · exact extend_seed_progression (b:=17) (u:=1) d7 (by decide) (by decide) (by decide)
      seed7 pos h
  · exact extend_seed_progression (b:=221) (u:=1) d9 (by decide) (by decide) (by decide)
      seed9 pos h
  · exact extend_seed_progression (b:=204) (u:=1) d10 (by decide) (by decide) (by decide)
      seed10 pos h
  · exact extend_seed_progression (b:=425) (u:=1) d11 (by decide) (by decide) (by decide)
      seed11 pos h
  · exact extend_seed_progression (b:=425) (u:=1) d13 (by decide) (by decide) (by decide)
      seed13 pos h
  · exact extend_seed_progression (b:=646) (u:=1) d14 (by decide) (by decide) (by decide)
      seed14 pos h
  · exact extend_seed_progression (b:=85) (u:=1) d15 (by decide) (by decide) (by decide)
      seed15 pos h


theorem seventeen_all_integer (k:ℕ) : IntegralSolution 17 (4*k) := integer_gram (seventeen_all k)
#print axioms seventeen_all_integer
end HadamardMod
