import Quantum.Hadamard.NineteenSkew
import Quantum.Hadamard.Regular
namespace HadamardMod.Nineteen
noncomputable section
private def primeCore (q : ℕ) [NeZero q] (hp : q.Prime) (hq : q%4=3) : SkewCore 19 (ZMod q) := by
  have : Fact q.Prime := ⟨hp⟩
  exact paleySkew 19 q hq
private theorem h20 : AtOrder 19 20 := by
  have : Fact (Nat.Prime 19) := ⟨by decide⟩
  exact paley_order 19 19 (by decide)
def d1 : Extender 19 (Fin 20 × Fin 20) 1 :=
  regularExtension (Classical.choose_spec h20) (by decide)
def d2 : Extender 19 (Fin 39) 2 where
  toRows := skew39.inner
  dim := by decide
  pos := by decide
def d5 : Extender 19 (ZMod 43 × ZMod 23) 5 :=
  lexExtension (primeCore 43 (by decide) (by decide)) (primeCore 23 (by decide) (by decide)).inner (by decide)
def d9 : Extender 19 (ZMod 31 × Fin 27) 9 :=
  lexExtension (primeCore 31 (by decide) (by decide)) skew27.inner (by decide)
def d13 : Extender 19 (Fin 27 × ZMod 31) 13 :=
  lexExtension skew27 (primeCore 31 (by decide) (by decide)).inner (by decide)
def d17 : Extender 19 (Fin 63 × Fin 35) 17 :=
  lexExtension skew63 skew35.inner (by decide)
def d6 : Extender 19 (ZMod 23 × ZMod 43) 6 :=
  lexExtension (primeCore 23 (by decide) (by decide)) (primeCore 43 (by decide) (by decide)).inner (by decide)
def d10 : Extender 19 (Fin 55 × ZMod 47) 10 :=
  lexExtension skew55 (primeCore 47 (by decide) (by decide)).inner (by decide)
def d14 : Extender 19 (ZMod 3 × Fin 51) 14 :=
  lexExtension (primeCore 3 (by decide) (by decide)) skew51.inner (by decide)
def d18 : Extender 19 (ZMod 47 × Fin 55) 18 :=
  lexExtension (primeCore 47 (by decide) (by decide)) skew55.inner (by decide)
def d3 : Extender 19 (ZMod 67 × ZMod 59) 3 :=
  lexExtension (primeCore 67 (by decide) (by decide)) (primeCore 59 (by decide) (by decide)).inner (by decide)
def d7 : Extender 19 (Fin 35 × Fin 63) 7 :=
  lexExtension skew35 skew63.inner (by decide)
def d11 : Extender 19 (ZMod 59 × ZMod 67) 11 :=
  lexExtension (primeCore 59 (by decide) (by decide)) (primeCore 67 (by decide) (by decide)).inner (by decide)
def d15 : Extender 19 (Fin 15 × ZMod 71) 15 :=
  lexExtension skew15 (primeCore 71 (by decide) (by decide)).inner (by decide)
end
end HadamardMod.Nineteen
