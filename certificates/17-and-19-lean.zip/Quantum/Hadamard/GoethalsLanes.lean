import Quantum.Hadamard.Basic

/-! Seventeen modular Hamming weights in one integer remainder. Binary coordinates
occupy the low bits of consecutive bytes. The radix 256 equals one modulo 17. -/
namespace HadamardMod.Lanes
open Finset

def mask : ℕ → ℕ
  | 0 => 0
  | n+1 => (mask n <<< 8) ||| 1

def Clean : ℕ → ℕ → Prop
  | 0,w => w=0
  | n+1,w => w%256≤1 ∧ Clean n (w>>>8)

private theorem mask_low (n:ℕ) : mask (n+1)%256=1 := by
  change ((mask n <<< 8) ||| 1) % 2^8=1
  rw [Nat.or_mod_two_pow,Nat.shiftLeft_eq]
  simp [Nat.mul_mod]

private theorem mask_high (n:ℕ) : mask (n+1)>>>8=mask n := by
  change (((mask n <<< 8) ||| 1) >>> 8)=mask n
  rw [Nat.shiftRight_or_distrib]
  change (mask n <<< 8 >>> 8) ||| 0=mask n
  simp [Nat.shiftRight_eq_div_pow,Nat.shiftLeft_eq]

theorem clean_of_mask (n w:ℕ) (h:w &&& mask n=w) : Clean n w := by
  induction n generalizing w with
  | zero => simpa [mask,Clean] using h.symm
  | succ n ih =>
    constructor
    · have low := congrArg (fun x:ℕ => x%2^8) h
      simp only [Nat.and_mod_two_pow] at low
      change w%256 &&& (mask (n+1)%256) = w%256 at low
      rw [mask_low] at low
      exact low ▸ Nat.and_le_right
    · apply ih
      simpa only [Nat.shiftRight_and_distrib,mask_high] using congrArg (fun x:ℕ => x>>>8) h

def signAt (w i:ℕ) : ZMod 17 := if (w>>>(8*i))%256=0 then 1 else -1

private theorem sign_succ (w i:ℕ) : signAt w (i+1)=signAt (w>>>8) i := by
  simp only [signAt,←Nat.shiftRight_add]
  rw [show 8*(i+1)=8+8*i by omega]

private theorem byte_cast (w:ℕ) : (w:ZMod 17)=(w%256:ℕ)+(w>>>8:ℕ) := by
  have h := Nat.mod_add_div w 256
  have cast := congrArg (fun x:ℕ => (x:ZMod 17)) h
  simp only [Nat.cast_add,Nat.cast_mul] at cast
  have h256 : ((256:ℕ):ZMod 17)=1 := by decide
  rw [h256,one_mul] at cast
  simpa only [Nat.shiftRight_eq_div_pow] using cast.symm

theorem dot (n x y:ℕ) (hx:Clean n x) (hy:Clean n y) :
    (∑ i:Fin n,signAt x i.val*signAt y i.val)=
      (n:ZMod 17)-2*((x^^^y:ℕ):ZMod 17) := by
  induction n generalizing x y with
  | zero =>
    change x=0 at hx
    change y=0 at hy
    simp [hx,hy]
  | succ n ih =>
    obtain ⟨lx,hx⟩:=hx
    obtain ⟨ly,hy⟩:=hy
    rw [Fin.sum_univ_succ]
    simp only [Fin.val_zero,Fin.val_succ,sign_succ]
    rw [ih _ _ hx hy, byte_cast (x^^^y),Nat.shiftRight_xor_distrib]
    change signAt x 0*signAt y 0+_=(n+1:ℕ)-2*(((x^^^y)%2^8:ℕ)+(↑(x>>>8^^^y>>>8):ZMod 17))
    rw [Nat.xor_mod_two_pow]
    have x01 : x%256=0 ∨ x%256=1 := by omega
    have y01 : y%256=0 ∨ y%256=1 := by omega
    rcases x01 with h|h <;> rcases y01 with j|j <;>
      norm_num [signAt,h,j] <;> ring

/-- Packed binary rows provide an ordinary sign matrix. Two distinct rows are checked
by reducing a single xor modulo seventeen. -/
theorem of_rows {n M:ℕ} (W:Fin n→ℕ) (hm : mask n=M)
    (valid:∀ i,W i &&& M=W i)
    (orth:∀ i j:Fin n,i<j → (2*(W i^^^W j))%17=n%17) : AtOrder 17 n := by
  let H : RowMatrix 17 (Fin n) := fun i j => signAt (W i) j.val
  refine ⟨H,⟨fun i j => by dsimp [H,signAt];split <;> simp [Sign],?_⟩⟩
  intro i j ne
  change (∑ a:Fin n,signAt (W i) a.val*signAt (W j) a.val)=0
  have a (u:Fin n) := clean_of_mask n (W u) (hm ▸ valid u)
  rw [dot n _ _ (a i) (a j)]
  have z : (2*(W i^^^W j))%17=n%17 := by
    rcases lt_or_gt_of_ne ne with t|t
    · exact orth i j t
    · simpa only [Nat.xor_comm] using orth j i t
  have e := (ZMod.natCast_eq_natCast_iff _ _ 17).mpr z
  push_cast at e
  linear_combination -e

#print axioms of_rows
end HadamardMod.Lanes
