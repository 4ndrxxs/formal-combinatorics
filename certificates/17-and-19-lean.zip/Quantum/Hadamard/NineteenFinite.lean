import Quantum.Hadamard.NineteenExtenders
import Quantum.Hadamard.NineteenSeed739
import Quantum.Hadamard.GoethalsProgression
import Quantum.Hadamard.GoethalsResidues
namespace HadamardMod
open Nineteen
set_option maxRecDepth 500000
set_option maxHeartbeats 0

def nineteenBound : ℕ → ℕ
  | 1 => 399
  | 2 => 19
  | 3 => 988
  | 5 => 247
  | 6 => 247
  | 7 => 551
  | 9 => 209
  | 10 => 646
  | 11 => 988
  | 13 => 209
  | 14 => 38
  | 15 => 266
  | 17 => 551
  | 18 => 646
  | _ => 0

theorem nineteen_from_table_five
    (catalogue : ∀ a : ℕ, 0<a → a≤nineteenBound ((4*a)%19) → a≠739 → AtOrder 19 (4*a))
    (k : ℕ) : AtOrder 19 (4*k) := by
  by_cases zero : k=0
  · subst k; simpa using empty_order 19
  have pos : 0<k := by omega
  by_cases easy : k%19≤4
  · exact goethals_residue easy
  have small {b r : ℕ} (bound : b=nineteenBound r) (a:ℕ) (ha:0<a) (h:a≤b) (hr : (4*a)%19=r) :
      AtOrder 19 (4*a) := by
    by_cases x : a=739
    · subst a; exact Cert739.result
    exact catalogue a ha (by simpa only [hr,←bound] using h) x
  have rem := Nat.mod_lt k (by decide : 0<19)
  have m : (4*k)%19=(4*(k%19))%19 := by simp [Nat.mul_mod]
  have hard : (4*k)%19=1 ∨ (4*k)%19=2 ∨ (4*k)%19=3 ∨ (4*k)%19=5 ∨ (4*k)%19=6 ∨ (4*k)%19=7 ∨ (4*k)%19=9 ∨ (4*k)%19=10 ∨ (4*k)%19=11 ∨ (4*k)%19=13 ∨ (4*k)%19=14 ∨ (4*k)%19=15 ∨ (4*k)%19=17 ∨ (4*k)%19=18 := by
    rw [m]
    generalize z : k%19=v at *
    interval_cases v <;> norm_num at *
  rcases hard with h|h|h|h|h|h|h|h|h|h|h|h|h|h
  · exact extend_seed_progression (b:=399) (u:=4) d1 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=19) (u:=2) d2 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=988) (u:=1) d3 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=247) (u:=1) d5 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=247) (u:=1) d6 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=551) (u:=1) d7 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=209) (u:=1) d9 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=646) (u:=1) d10 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=988) (u:=1) d11 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=209) (u:=1) d13 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=38) (u:=1) d14 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=266) (u:=1) d15 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=551) (u:=1) d17 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
  · exact extend_seed_progression (b:=646) (u:=1) d18 (by decide) (by decide) (by decide)
      (small (by decide)) pos h
#print axioms nineteen_from_table_five
end HadamardMod
