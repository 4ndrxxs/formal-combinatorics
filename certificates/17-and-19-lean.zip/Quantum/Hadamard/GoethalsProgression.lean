import Quantum.Hadamard.Extension

/-! Convert a modular core step and a finite initial progression into all
positive multiples of four in the congruence class. -/
namespace HadamardMod

theorem extend_seed_progression {m r b u k : ℕ} {I : Type*} [Fintype I]
    (D : Extender m I (r:ZMod m)) (hb : 0<b) (hm : b%m=0)
    (delta : 4*b=u*(Fintype.card I-1))
    (small : ∀ a : ℕ, 0<a → a≤b → (4*a)%m=r → AtOrder m (4*a))
    (hk : 0<k) (hr : (4*k)%m=r) : AtOrder m (4*k) := by
  let a := (k-1)%b+1
  let t := (k-1)/b
  have ha : 0<a := by dsimp [a]; omega
  have hab : a≤b := by
    have hd := Nat.mod_lt (k-1) hb
    dsimp [a]; omega
  have decomp : k=a+t*b := by
    dsimp [a,t]
    have e := Nat.mod_add_div (k-1) b
    rw [Nat.mul_comm b _] at e
    omega
  have ar : (4*a)%m=r := by
    have zero : (4*(t*b))%m=0 := by rw [←Nat.mul_assoc, Nat.mul_mod, hm]; simp
    rw [decomp, Nat.mul_add,Nat.add_mod, zero,Nat.add_zero,Nat.mod_mod] at hr
    exact hr
  have cast : ((4*a : ℕ) : ZMod m)=(r : ZMod m) := by
    rw [←ZMod.natCast_mod (4*a) m, ar]
  have size : 4*k=4*a+(t*u)*(Fintype.card I-1) := by
    calc
      _=4*a+t*(4*b) := by rw [decomp]; ring
      _=_ := by rw [delta]; ring
  rw [size]
  exact D.iterate (by omega) (small a ha hab ar) cast (t*u)

end HadamardMod

