import Quantum.Hadamard.GoethalsBits

/-! Reduce circulant certificates to representatives of multiplier orbits.
A finite descending rank is a witness that all shifts reach a checked one. -/
namespace HadamardMod
open Finset
variable {k m : ℕ} [NeZero k]

private theorem corr_neg_fin (f : Seq m (Fin k)) (s : Fin k) :
    cyclicCorr f f (-s) = cyclicCorr f f s := by
  have h := Equiv.sum_comp (Equiv.addRight s) (fun j => f j*f (j+ -s))
  change (∑ j,f (j+s)*f (j+s+-s))=_ at h
  simpa only [add_neg_cancel_right,cyclicCorr,mul_comm] using h.symm

private theorem corr_unit_fin (f : Seq m (Fin k)) (u v s : Fin k) (hu : u*v=1)
    (sym : ∀ x,f (u*x)=f x) : cyclicCorr f f (u*s)=cyclicCorr f f s := by
  let E : Fin k ≃ Fin k := {
    toFun := fun x => u*x, invFun := fun x => v*x
    left_inv := by intro x; dsimp; rw [←mul_assoc,mul_comm v u,hu,one_mul]
    right_inv := by intro x; dsimp; rw [←mul_assoc,hu,one_mul] }
  have h := E.sum_comp (fun j => f j*f (j+u*s))
  change (∑ x,f (u*x)*f (u*x+u*s))=_ at h
  simpa only [←mul_add,sym,cyclicCorr] using h.symm

theorem of_multiplier_four {g : ℕ} (codes : Fin 4 → ℕ) (U V : Fin g → Fin k)
    (level : Fin k → ℕ) (step : Fin k → Fin g)
    (bounds : ∀ t,codes t<2^k)
    (units : ∀ j,U j*V j=1)
    (symm : ∀ j, U j = -1 ∨ ∀ t (x:Fin k),
      (codes t).testBit (U j*x).val = (codes t).testBit x.val)
    (down : ∀ s:Fin k,s≠0 → level s≠0 → level (U (step s)*s)<level s)
    (initial : ∀ s:Fin k,s≠0 → level s=0 →
      (2*(cyclicChanges k (codes 0) s.val+cyclicChanges k (codes 1) s.val+
        cyclicChanges k (codes 2) s.val+cyclicChanges k (codes 3) s.val))%m=(4*k)%m) :
    AtOrder m (4*k) := by
  let F (t:Fin 4) := bitSeq m k (codes t)
  let C (s:Fin k) := ∑ t,cyclicCorr (F t) (F t) s
  have invariant (j:Fin g) (s:Fin k) : C (U j*s)=C s := by
    apply Finset.sum_congr rfl
    intro t _
    rcases symm j with r|h
    · simpa [r] using corr_neg_fin (F t) s
    · apply corr_unit_fin _ _ (V j) _ (units j)
      intro x
      simp only [F,bitSeq,h]
  have base (s:Fin k) (ns:s≠0) (r:level s=0) : C s=0 := by
    have h := (ZMod.natCast_eq_natCast_iff _ _ m).mpr (initial s ns r)
    push_cast at h
    dsimp only [C,F]
    rw [Fin.sum_univ_four,cyclicCorr_bits (bounds 0),cyclicCorr_bits (bounds 1),
      cyclicCorr_bits (bounds 2),cyclicCorr_bits (bounds 3)]
    linear_combination -h
  have done (z:ℕ) : ∀ s:Fin k,level s=z → s≠0 → C s=0 := by
    induction z using Nat.strong_induction_on with
    | ind z prior =>
      intro s rank ns
      by_cases zero : level s=0
      · exact base s ns zero
      · let j := step s
        have nz : U j*s≠0 := by
          intro e
          have el := congrArg (fun y : Fin k => V j*y) e
          simpa [←mul_assoc,mul_comm (V j) (U j),units j,ns] using el
        rw [←invariant j s]
        exact prior _ (rank ▸ down s ns zero) _ rfl nz
  exact of_bit_sequences codes (fun s ns => done _ s rfl ns)

#print axioms of_multiplier_four
end HadamardMod
