import Quantum.Hadamard.Goethals

/-! Four one-defect or constant generators supply five residue classes at
every modulus. The construction works over the actual residue ring. -/
namespace HadamardMod
open Finset
variable {m k : ℕ} [NeZero k]

private def defect (m k : ℕ) [NeZero k] (j : Fin k) : ZMod m :=
  if j=0 then -1 else 1

private theorem defect_corr (s : Fin k) (hs : s≠0) :
    cyclicCorr (defect m k) (defect m k) s=(k:ZMod m)-4 := by
  have expand (j : Fin k) : defect m k j * defect m k (j+s) =
      1-(if j=0 then 2 else 0)-(if j+s=0 then 2 else 0) := by
    by_cases h : j=0 <;> by_cases h' : j+s=0
    · exact False.elim (hs (by simpa [h] using h'))
    · simp [defect,h,h',hs]; ring
    · simp [defect,h,h']; ring
    · simp [defect,h,h']
  have shift : (∑ j : Fin k, if j+s=0 then (2:ZMod m) else 0)=2 := by
    have t := Equiv.sum_comp (Equiv.addRight s) (fun j : Fin k => if j=0 then (2:ZMod m) else 0)
    change (∑ j : Fin k, if j+s=0 then (2:ZMod m) else 0)=_ at t
    simpa using t
  simp only [cyclicCorr,expand,Finset.sum_sub_distrib,shift]
  simp
  ring

/-- At every modulus, all orders 4k with k mod m in the first five
residues have a modular Hadamard matrix. -/
theorem goethals_residue {m k : ℕ} (h : k % m ≤ 4) : AtOrder m (4*k) := by
  by_cases hk : k=0
  · subst k
    simpa using empty_order m
  haveI : NeZero k := ⟨hk⟩
  generalize he : k%m = r at h
  have hc : (k:ZMod m)=(r:ZMod m) := by rw [←ZMod.natCast_mod k m,he]
  let f : Fin 4 → Seq m (Fin k) := fun t => if t.val<r then defect m k else fun _ => 1
  apply (show (∀ t j, Sign (f t j)) → (∀ s : Fin k, s≠0 →
      ∑ t, cyclicCorr (f t) (f t) s=0) → AtOrder m (4*k) by
    simpa only [Fintype.card_fin] using goethals_AtOrder f)
  · intro t j
    unfold f
    split
    · unfold defect
      split <;> simp [Sign]
    · exact Or.inl rfl
  · intro s hs
    have corr (t : Fin 4) : cyclicCorr (f t) (f t) s=
        (k:ZMod m)-(if t.val<r then 4 else 0) := by
      by_cases hh : t.val<r
      · simp [f,hh,defect_corr s hs]
      · simp [f,hh,cyclicCorr]
    simp only [corr,Fin.sum_univ_four,hc]
    interval_cases r <;> norm_num

#print axioms goethals_residue
end HadamardMod

