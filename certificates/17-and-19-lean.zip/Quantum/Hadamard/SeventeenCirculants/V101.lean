import Quantum.Hadamard.SeventeenCirculants.V73
namespace HadamardMod.Seventeen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert101
private def words : Fin 4 → ℕ := ![1188378688474935158893773168046,1560965017611938757160109600510,1188378688474935158893773168046,1550432784880709368503235994226]
private def mult (i:Fin 2) : Fin 101  := Fin.ofNat _ (#[97,100][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 101  := Fin.ofNat _ (#[25,100][i.val]! : ℕ)
private def level (i:Fin 101) : ℕ := #[0,0,0,16,25,13,16,21,25,7,13,19,16,18,21,4,23,11,7,2,13,12,19,8,14,1,18,23,21,6,4,8,23,10,11,9,5,22,2,9,13,3,12,5,19,20,8,22,14,17,1,2,16,15,21,7,19,18,4,11,4,12,8,3,23,6,10,10,9,24,9,3,5,20,22,17,2,15,7,18,11,12,3,6,10,24,5,20,17,15,20,14,6,24,22,15,14,24,17,1,1][i.val]!
private def step (i:Fin 101) : Fin 2  := Fin.ofNat _ (#[0,0,0,0,1,0,1,0,1,1,0,0,1,1,1,0,0,1,1,0,1,1,1,1,0,0,1,1,1,1,1,0,0,1,1,0,0,0,0,1,1,0,1,1,1,1,1,1,0,1,0,1,0,1,0,0,0,0,0,0,1,0,0,1,1,1,1,0,0,1,1,0,0,0,0,0,1,1,0,0,0,0,1,0,0,1,1,0,0,0,1,1,0,0,1,0,1,0,1,1,1][i.val]! : ℕ)
theorem result : AtOrder 17 (4*101) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert101
end HadamardMod.Seventeen
