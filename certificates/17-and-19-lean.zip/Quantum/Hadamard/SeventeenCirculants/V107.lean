import Quantum.Hadamard.SeventeenCirculants.V101
namespace HadamardMod.Seventeen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert107
private def words : Fin 4 → ℕ := ![162259276829213363391578010288126,50079290986288516948354744811034,162259276829213363391578010288126,50079290986288516948354744811034]
private def mult (i:Fin 2) : Fin 107  := Fin.ofNat _ (#[105,106][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 107  := Fin.ofNat _ (#[53,106][i.val]! : ℕ)
private def level (i:Fin 107) : ℕ := #[0,0,53,36,51,7,36,11,51,19,5,31,34,39,9,43,49,25,19,28,5,47,31,44,34,12,39,2,9,21,41,27,49,14,23,16,17,15,28,22,3,13,45,48,29,26,44,40,32,20,12,8,37,1,2,38,7,11,21,33,41,43,25,30,47,46,14,4,23,27,16,18,17,24,15,48,26,42,22,8,3,38,13,33,45,30,46,4,29,18,24,50,42,10,40,35,32,6,20,50,10,35,6,52,37,52,1][i.val]!
private def step (i:Fin 107) : Fin 2  := Fin.ofNat _ (#[0,0,1,0,0,1,1,1,1,0,0,0,0,0,0,1,0,1,1,0,1,1,1,0,1,0,1,0,1,0,0,1,1,0,0,0,0,0,1,0,0,0,0,1,0,1,1,0,0,0,1,1,0,0,1,1,0,0,1,1,1,0,0,1,0,1,1,1,1,0,1,1,1,1,1,0,0,1,1,0,1,0,1,0,1,0,0,0,1,0,0,1,0,1,1,1,1,1,1,0,0,0,0,1,1,0,1][i.val]! : ℕ)
theorem result : AtOrder 17 (4*107) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert107
end HadamardMod.Seventeen
