import Quantum.Hadamard.SeventeenCirculants.V113
namespace HadamardMod.Seventeen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert133
private def words : Fin 4 → ℕ := ![85740438909212841187621948329264431232,7528255820954909373392140861393552359066,10803944339628520837403743182602550886398,7528255820954909373392140861393552359066]
private def mult (i:Fin 3) : Fin 133  := Fin.ofNat _ (#[130,123,132][i.val]! : ℕ)
private def inv (i:Fin 3) : Fin 133  := Fin.ofNat _ (#[44,93,132][i.val]! : ℕ)
private def level (i:Fin 133) : ℕ := #[0,0,0,6,2,4,6,0,2,4,6,5,8,7,2,2,4,8,4,0,6,5,5,4,8,5,7,4,2,5,4,3,4,5,4,3,6,6,1,5,2,7,1,3,1,2,4,4,7,2,5,6,6,1,4,6,4,3,7,3,4,7,3,4,3,3,5,4,4,4,5,2,6,5,2,8,2,3,5,3,2,5,7,6,3,6,3,5,1,2,4,2,6,1,6,2,7,7,4,3,4,5,2,5,6,3,3,6,6,7,5,6,4,5,1,5,7,5,3,1,6,7,6,5,5,3,1,5,3,3,5,1,1][i.val]!
private def step (i:Fin 133) : Fin 3  := Fin.ofNat _ (#[0,0,0,2,1,2,2,0,1,1,2,1,2,2,2,0,1,2,1,0,2,2,1,0,2,1,2,2,1,0,1,2,1,2,2,1,1,1,0,1,2,2,0,1,0,2,0,2,2,1,1,1,2,1,2,2,2,2,1,2,1,2,2,1,0,1,2,1,2,2,2,1,1,2,0,2,0,1,1,1,2,0,2,2,2,1,1,2,0,2,2,2,1,1,2,2,2,2,2,1,1,2,1,2,2,2,1,1,2,1,2,2,1,1,2,2,1,2,2,1,1,1,2,1,2,2,2,1,0,2,1,2,2][i.val]! : ℕ)
theorem result : AtOrder 17 (4*133) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert133
end HadamardMod.Seventeen
