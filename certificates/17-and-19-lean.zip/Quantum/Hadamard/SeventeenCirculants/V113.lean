import Quantum.Hadamard.SeventeenCirculants.V109
namespace HadamardMod.Seventeen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert113
private def words : Fin 4 → ℕ := ![5546158919334382479983759334837912,8323268010583549438152487439614900,9467943812836609423723457802195860,8730167392447288724168755469075390]
private def mult (i:Fin 2) : Fin 113  := Fin.ofNat _ (#[109,112][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 113  := Fin.ofNat _ (#[28,112][i.val]! : ℕ)
private def level (i:Fin 113) : ℕ := #[0,0,0,0,7,0,0,3,7,0,0,5,7,0,3,5,5,6,6,4,7,3,2,4,7,1,1,1,1,2,3,5,5,6,4,3,7,3,4,4,7,5,3,2,3,5,4,5,5,4,2,3,7,4,1,1,1,2,2,2,3,6,4,3,5,6,6,3,4,4,3,2,4,6,3,5,4,6,2,5,5,6,6,4,1,2,2,2,2,6,3,3,2,6,5,5,5,6,4,2,1,6,4,1,1,6,2,1,1,6,1,1,1][i.val]!
private def step (i:Fin 113) : Fin 2  := Fin.ofNat _ (#[0,0,0,0,1,0,0,1,1,0,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,0,0,0,0,1,0,0,0,1,0,1,1,0,0,1,1,1,1,0,0,1,1,0,0,0,0,0,1,1,0,0,0,1,1,1,0,0,1,1,1,1,1,0,0,1,1,0,0,0,0,1,1,0,0,1,0,1,1,1,0,1,1,1,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,1,0,0,1,1,0,1,1,1][i.val]! : ℕ)
theorem result : AtOrder 17 (4*113) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert113
end HadamardMod.Seventeen
