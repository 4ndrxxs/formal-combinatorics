import Quantum.Hadamard.SeventeenCirculants.V13
namespace HadamardMod.Seventeen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert29
private def words : Fin 4 → ℕ := ![264232334,0,335244030,0]
private def mult (i:Fin 2) : Fin 29  := Fin.ofNat _ (#[25,28][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 29  := Fin.ofNat _ (#[7,28][i.val]! : ℕ)
private def level (i:Fin 29) : ℕ := #[0,0,0,5,7,4,5,1,7,3,4,2,5,6,1,2,5,4,3,3,2,6,2,4,3,6,6,1,1][i.val]!
private def step (i:Fin 29) : Fin 2  := Fin.ofNat _ (#[0,0,0,0,1,1,1,0,1,1,1,0,1,1,0,1,0,0,1,0,0,0,1,0,0,0,1,1,1][i.val]! : ℕ)
theorem result : AtOrder 17 (4*29) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert29
end HadamardMod.Seventeen
