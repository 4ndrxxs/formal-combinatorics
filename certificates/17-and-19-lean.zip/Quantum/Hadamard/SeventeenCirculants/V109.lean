import Quantum.Hadamard.SeventeenCirculants.V107
namespace HadamardMod.Seventeen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert109
private def words : Fin 4 → ℕ := ![649037107316853453566312041152510,647429776634410852044662736909822,119142980726776754562563975741160,531501457272519300525397369654038]
private def mult (i:Fin 1) : Fin 109  := Fin.ofNat _ (#[107][i.val]! : ℕ)
private def inv (i:Fin 1) : Fin 109  := Fin.ofNat _ (#[54][i.val]! : ℕ)
private def level (i:Fin 109) : ℕ := #[0,0,17,0,34,28,17,4,15,0,9,7,34,31,21,28,32,5,17,11,26,4,24,25,15,20,12,20,2,6,9,30,13,27,22,32,34,33,28,31,7,21,21,26,5,12,6,29,32,8,1,5,29,1,1,19,19,11,23,19,26,14,11,24,30,23,8,3,3,25,13,10,15,16,14,4,9,31,12,27,24,20,2,30,2,33,7,6,22,8,29,35,23,14,10,3,13,16,25,27,18,33,22,35,10,16,18,35,18][i.val]!
private def step (i:Fin 109) : Fin 1  := Fin.ofNat _ (#[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0][i.val]! : ℕ)
theorem result : AtOrder 17 (4*109) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert109
end HadamardMod.Seventeen
