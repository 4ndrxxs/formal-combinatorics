import Quantum.Hadamard.Basic

/-! Integer Hamming weights in one integer remainder. Binary coordinates
occupy the low bits of consecutive twelve-bit digits. The radix 4096 equals one modulo 4095. -/
namespace HadamardMod.Lanes4095
open Finset

def mask : ℕ → ℕ
  | 0 => 0
  | n+1 => (mask n <<< 12) ||| 1

def Clean : ℕ → ℕ → Prop
  | 0,w => w=0
  | n+1,w => w%4096≤1 ∧ Clean n (w>>>12)

private theorem mask_low (n:ℕ) : mask (n+1)%4096=1 := by
  change ((mask n <<< 12) ||| 1) % 2^12=1
  rw [Nat.or_mod_two_pow,Nat.shiftLeft_eq]
  simp [Nat.mul_mod]

private theorem mask_high (n:ℕ) : mask (n+1)>>>12=mask n := by
  change (((mask n <<< 12) ||| 1) >>> 12)=mask n
  rw [Nat.shiftRight_or_distrib]
  change (mask n <<< 12 >>> 12) ||| 0=mask n
  simp [Nat.shiftRight_eq_div_pow,Nat.shiftLeft_eq]

theorem clean_of_mask (n w:ℕ) (h:w &&& mask n=w) : Clean n w := by
  induction n generalizing w with
  | zero => simpa [mask,Clean] using h.symm
  | succ n ih =>
    constructor
    · have low := congrArg (fun x:ℕ => x%2^12) h
      simp only [Nat.and_mod_two_pow] at low
      change w%4096 &&& (mask (n+1)%4096) = w%4096 at low
      rw [mask_low] at low
      exact low ▸ Nat.and_le_right
    · apply ih
      simpa only [Nat.shiftRight_and_distrib,mask_high] using congrArg (fun x:ℕ => x>>>12) h

def signAt (w i:ℕ) : ZMod 4095 := if (w>>>(12*i))%4096=0 then 1 else -1

private theorem sign_succ (w i:ℕ) : signAt w (i+1)=signAt (w>>>12) i := by
  simp only [signAt,←Nat.shiftRight_add]
  rw [show 12*(i+1)=12+12*i by omega]

private theorem digit_cast (w:ℕ) : (w:ZMod 4095)=(w%4096:ℕ)+(w>>>12:ℕ) := by
  have h := Nat.mod_add_div w 4096
  have cast := congrArg (fun x:ℕ => (x:ZMod 4095)) h
  simp only [Nat.cast_add,Nat.cast_mul] at cast
  have h4096 : ((4096:ℕ):ZMod 4095)=1 := by decide
  rw [h4096,one_mul] at cast
  simpa only [Nat.shiftRight_eq_div_pow] using cast.symm

theorem dot (n x y:ℕ) (hx:Clean n x) (hy:Clean n y) :
    (∑ i:Fin n,signAt x i.val*signAt y i.val)=
      (n:ZMod 4095)-2*((x^^^y:ℕ):ZMod 4095) := by
  induction n generalizing x y with
  | zero =>
    change x=0 at hx
    change y=0 at hy
    simp [hx,hy]
  | succ n ih =>
    obtain ⟨lx,hx⟩:=hx
    obtain ⟨ly,hy⟩:=hy
    rw [Fin.sum_univ_succ]
    simp only [Fin.val_zero,Fin.val_succ,sign_succ]
    rw [ih _ _ hx hy, digit_cast (x^^^y),Nat.shiftRight_xor_distrib]
    change signAt x 0*signAt y 0+_=(n+1:ℕ)-2*(((x^^^y)%2^12:ℕ)+(↑(x>>>12^^^y>>>12):ZMod 4095))
    rw [Nat.xor_mod_two_pow]
    have x01 : x%4096=0 ∨ x%4096=1 := by omega
    have y01 : y%4096=0 ∨ y%4096=1 := by omega
    rcases x01 with h|h <;> rcases y01 with j|j <;>
      norm_num [signAt,h,j] <;> ring

/-- Packed binary rows provide an ordinary sign matrix. Two distinct rows are checked
by reducing a single xor modulo 4095. -/
theorem of_rows {n M:ℕ} (W:Fin n→ℕ) (hm : mask n=M)
    (valid:∀ i,W i &&& M=W i)
    (orth:∀ i j:Fin n,i<j → (2*(W i^^^W j))%4095=n%4095) : AtOrder 4095 n := by
  let H : RowMatrix 4095 (Fin n) := fun i j => signAt (W i) j.val
  refine ⟨H,⟨fun i j => by dsimp [H,signAt];split <;> simp [Sign],?_⟩⟩
  intro i j ne
  change (∑ a:Fin n,signAt (W i) a.val*signAt (W j) a.val)=0
  have a (u:Fin n) := clean_of_mask n (W u) (hm ▸ valid u)
  rw [dot n _ _ (a i) (a j)]
  have z : (2*(W i^^^W j))%4095=n%4095 := by
    rcases lt_or_gt_of_ne ne with t|t
    · exact orth i j t
    · simpa only [Nat.xor_comm] using orth j i t
  have e := (ZMod.natCast_eq_natCast_iff _ _ 4095).mpr z
  push_cast at e
  linear_combination -e

#print axioms of_rows
end HadamardMod.Lanes4095
