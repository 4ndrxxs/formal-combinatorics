import Quantum.Hadamard.GoethalsRadix4095
import Quantum.Hadamard.GoethalsInteger

namespace HadamardMod.Lanes4095

def before (W : ℕ → ℕ) (n i : ℕ) : ℕ → Bool
  | 0 => true
  | j+1 => (2*(W i ^^^ W j))%4095 == n%4095 && before W n i j

def rows (W : ℕ → ℕ) (n start : ℕ) : ℕ → Bool
  | 0 => true
  | c+1 => before W n (start+c) (start+c) && rows W n start c

theorem before_ok (W : ℕ → ℕ) (n i k : ℕ) (h:before W n i k=true) {j:ℕ} (hj:j<k) :
    (2*(W i ^^^ W j))%4095=n%4095 := by
  induction k with
  | zero => omega
  | succ k ih =>
    simp only [before,Bool.and_eq_true,beq_iff_eq] at h
    by_cases e : j=k
    · simpa [e] using h.1
    · exact ih h.2 (by omega)

theorem rows_ok (W : ℕ → ℕ) (n start c : ℕ) (h:rows W n start c=true)
    {i:ℕ} (lo:start ≤ i) (hi:i < start+c) : before W n i i=true := by
  induction c with
  | zero => omega
  | succ c ih =>
    simp only [rows,Bool.and_eq_true] at h
    by_cases e : i=start+c
    · simpa [e] using h.1
    · exact ih h.2 (by omega)

theorem combine (W : ℕ → ℕ) (n start a b : ℕ) (ha : rows W n start a=true)
    (hb : rows W n (start+a) b=true) : rows W n start (a+b)=true := by
  induction b with
  | zero => simpa using ha
  | succ b ih =>
    simp only [rows,Bool.and_eq_true] at hb
    rw [Nat.add_succ,rows,Bool.and_eq_true]
    constructor
    · simpa only [Nat.add_assoc] using hb.1
    · exact ih hb.2

theorem of_checked {n M:ℕ} (W : ℕ → ℕ) (hm:mask n=M)
    (valid:∀ i:Fin n, W i.val &&& M=W i.val) (tested:rows W n 0 n=true) : AtOrder 4095 n := by
  apply of_rows (fun i => W i.val) hm valid
  intro i j lt
  have row := rows_ok W n 0 n tested (Nat.zero_le j.val) (by simpa using j.isLt)
  simpa only [Nat.xor_comm] using before_ok W n j.val j.val row (show i.val<j.val from lt)

end HadamardMod.Lanes4095
