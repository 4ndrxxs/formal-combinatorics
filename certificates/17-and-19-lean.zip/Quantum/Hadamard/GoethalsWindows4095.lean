import Quantum.Hadamard.GoethalsRadix4095
import Quantum.Hadamard.Goethals
namespace HadamardMod.Lanes4095
open Finset

def window (w k s : ℕ) : ℕ := (w >>> (12*s)) % 2^(12*k)

theorem sign_window (w k s i:ℕ) (hi:i<k) :
    signAt (window w k s) i=signAt w (s+i) := by
  unfold signAt window
  have e : 2^(12*k)=(2:ℕ)^(12*i)*2^(12*(k-i)) := by
    rw [←pow_add]
    congr 1
    omega
  have dvd : 2^12 ∣ (2:ℕ)^(12*(k-i)) := Nat.pow_dvd_pow 2 (by omega)
  rw [Nat.shiftRight_eq_div_pow (_%_) (12*i),e,Nat.mod_mul_right_div_self,
    show 4096=2^12 by decide,Nat.mod_mod_of_dvd _ dvd,←Nat.shiftRight_eq_div_pow,
    ←Nat.shiftRight_add,Nat.mul_add]

theorem of_doubled {k M:ℕ} [NeZero k] (D:Fin 4→ℕ) (hm:mask k=M)
    (valid:∀ t:Fin 4,∀ s:Fin k,window (D t) k s.val &&& M = window (D t) k s.val)
    (per:∀ t:Fin 4,∀ i:Fin (2*k),signAt (D t) (i.val%k)=signAt (D t) i.val)
    (orth:∀ s:Fin k,s≠0→ (2* ∑ t:Fin 4, (window (D t) k 0 ^^^ window (D t) k s.val))%4095
      =(4*k)%4095) : AtOrder 4095 (4*k) := by
  let f : Fin 4→Seq 4095 (Fin k) := fun t i => signAt (D t) i.val
  have hsign : ∀t i,Sign (f t i) := by
    intro t i
    dsimp [f,signAt]
    split <;> simp [Sign]
  have hc (s:Fin k) (hs:s≠0) : ∑t,cyclicCorr (f t) (f t) s=0 := by
    have clean (t:Fin 4) (s':Fin k) : Clean k (window (D t) k s'.val) := by
      apply clean_of_mask
      rw [hm]
      exact valid t s'
    have corr (t:Fin 4) : cyclicCorr (f t) (f t) s=
        (k:ZMod 4095)-2*↑(window (D t) k 0 ^^^ window (D t) k s.val) := by
      have zd : (0:Fin k).val=0 := by simp
      have eqdot := dot k _ _ (clean t (0:Fin k)) (clean t s)
      rw [zd] at eqdot
      rw [← eqdot]
      apply Finset.sum_congr rfl
      intro i _
      simp only [Fin.val_zero,sign_window _ _ _ i.val i.isLt,zero_add]
      change signAt (D t) i.val * signAt (D t) (i+s).val = signAt (D t) i.val * _
      rw [Fin.val_add]
      have pp:=per t ⟨i.val+s.val,by omega⟩
      rw [show signAt (D t) ((↑i+↑s)%k)=signAt (D t) (↑i+↑s) from pp, Nat.add_comm i.val s.val]
    simp only [corr,Finset.sum_sub_distrib,Finset.sum_const,Finset.card_univ,
      Fintype.card_fin,nsmul_eq_mul,←Finset.mul_sum]
    have eq := (ZMod.natCast_eq_natCast_iff _ _ 4095).mpr (orth s hs)
    push_cast at eq
    linear_combination -eq
  simpa only [Fintype.card_fin] using goethals_AtOrder f hsign hc
end HadamardMod.Lanes4095
