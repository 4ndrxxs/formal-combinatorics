import Quantum.Hadamard.NineteenRaw.R188B0
import Quantum.Hadamard.NineteenRaw.R188B1
import Quantum.Hadamard.NineteenRaw.R188B2
import Quantum.Hadamard.NineteenRaw.R188B3
import Quantum.Hadamard.NineteenRaw.R188B4
namespace HadamardMod.Nineteen.R188
set_option maxRecDepth 150000
private theorem p0_80 : Lanes4095.rows word 188 0 80=true := Lanes4095.combine word 188 0 40 40 b0 b1
private theorem p120_68 : Lanes4095.rows word 188 120 68=true := Lanes4095.combine word 188 120 40 28 b3 b4
private theorem p80_108 : Lanes4095.rows word 188 80 108=true := Lanes4095.combine word 188 80 40 68 b2 p120_68
private theorem p0_188 : Lanes4095.rows word 188 0 188=true := Lanes4095.combine word 188 0 80 108 p0_80 p80_108
theorem real_matrix (m:ℕ) : AtOrder m 188 := modulus_above_order (by decide : 188<4095) (Lanes4095.of_checked word wide bits p0_188) m
#print axioms real_matrix
end HadamardMod.Nineteen.R188
