import Quantum.Hadamard.NineteenRaw.R668B15
namespace HadamardMod.Nineteen.R668
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b16 : Lanes4095.rows word 668 640 28=true := by decide +kernel
end HadamardMod.Nineteen.R668
