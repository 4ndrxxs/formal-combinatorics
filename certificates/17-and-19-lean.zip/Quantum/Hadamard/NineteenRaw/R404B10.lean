import Quantum.Hadamard.NineteenRaw.R404B9
namespace HadamardMod.Nineteen.R404
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b10 : Lanes4095.rows word 404 400 4=true := by decide +kernel
end HadamardMod.Nineteen.R404
