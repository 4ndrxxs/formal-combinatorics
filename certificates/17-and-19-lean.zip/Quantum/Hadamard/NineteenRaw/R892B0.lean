import Quantum.Hadamard.NineteenRaw.R892Data
namespace HadamardMod.Nineteen.R892
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b0 : Lanes4095.rows word 892 0 40=true := by decide +kernel
end HadamardMod.Nineteen.R892
