import Quantum.Hadamard.NineteenRaw.R892B8
namespace HadamardMod.Nineteen.R892
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b9 : Lanes4095.rows word 892 360 40=true := by decide +kernel
end HadamardMod.Nineteen.R892
