import Quantum.Hadamard.NineteenRaw.R596B13
namespace HadamardMod.Nineteen.R596
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b14 : Lanes4095.rows word 596 560 36=true := by decide +kernel
end HadamardMod.Nineteen.R596
