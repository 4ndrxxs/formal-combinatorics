import Quantum.Hadamard.NineteenRaw.R428B0
namespace HadamardMod.Nineteen.R428
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b1 : Lanes4095.rows word 428 40 40=true := by decide +kernel
end HadamardMod.Nineteen.R428
