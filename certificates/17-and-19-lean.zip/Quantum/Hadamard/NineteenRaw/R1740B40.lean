import Quantum.Hadamard.NineteenRaw.R1740B39
namespace HadamardMod.Nineteen.R1740
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b40 : Lanes4095.rows word 1740 960 24=true := by decide +kernel
end HadamardMod.Nineteen.R1740
