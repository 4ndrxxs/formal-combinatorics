import Quantum.Hadamard.NineteenRaw.R756B15
namespace HadamardMod.Nineteen.R756
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b16 : Lanes4095.rows word 756 640 40=true := by decide +kernel
end HadamardMod.Nineteen.R756
