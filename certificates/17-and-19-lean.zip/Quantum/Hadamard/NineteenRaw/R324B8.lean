import Quantum.Hadamard.NineteenRaw.R324B7
namespace HadamardMod.Nineteen.R324
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b8 : Lanes4095.rows word 324 320 4=true := by decide +kernel
end HadamardMod.Nineteen.R324
