import Quantum.Hadamard.NineteenRaw.R404B7
namespace HadamardMod.Nineteen.R404
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b8 : Lanes4095.rows word 404 320 40=true := by decide +kernel
end HadamardMod.Nineteen.R404
