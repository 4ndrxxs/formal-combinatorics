import Quantum.Hadamard.NineteenRaw.R1100B13
namespace HadamardMod.Nineteen.R1100
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b14 : Lanes4095.rows word 1100 560 40=true := by decide +kernel
end HadamardMod.Nineteen.R1100
