import Quantum.Hadamard.NineteenRaw.R892B0
import Quantum.Hadamard.NineteenRaw.R892B1
import Quantum.Hadamard.NineteenRaw.R892B2
import Quantum.Hadamard.NineteenRaw.R892B3
import Quantum.Hadamard.NineteenRaw.R892B4
import Quantum.Hadamard.NineteenRaw.R892B5
import Quantum.Hadamard.NineteenRaw.R892B6
import Quantum.Hadamard.NineteenRaw.R892B7
import Quantum.Hadamard.NineteenRaw.R892B8
import Quantum.Hadamard.NineteenRaw.R892B9
import Quantum.Hadamard.NineteenRaw.R892B10
import Quantum.Hadamard.NineteenRaw.R892B11
import Quantum.Hadamard.NineteenRaw.R892B12
import Quantum.Hadamard.NineteenRaw.R892B13
import Quantum.Hadamard.NineteenRaw.R892B14
import Quantum.Hadamard.NineteenRaw.R892B15
import Quantum.Hadamard.NineteenRaw.R892B16
import Quantum.Hadamard.NineteenRaw.R892B17
import Quantum.Hadamard.NineteenRaw.R892B18
import Quantum.Hadamard.NineteenRaw.R892B19
import Quantum.Hadamard.NineteenRaw.R892B20
import Quantum.Hadamard.NineteenRaw.R892B21
import Quantum.Hadamard.NineteenRaw.R892B22
namespace HadamardMod.Nineteen.R892
set_option maxRecDepth 150000
private theorem p0_80 : Lanes4095.rows word 892 0 80=true := Lanes4095.combine word 892 0 40 40 b0 b1
private theorem p120_80 : Lanes4095.rows word 892 120 80=true := Lanes4095.combine word 892 120 40 40 b3 b4
private theorem p80_120 : Lanes4095.rows word 892 80 120=true := Lanes4095.combine word 892 80 40 80 b2 p120_80
private theorem p0_200 : Lanes4095.rows word 892 0 200=true := Lanes4095.combine word 892 0 80 120 p0_80 p80_120
private theorem p240_80 : Lanes4095.rows word 892 240 80=true := Lanes4095.combine word 892 240 40 40 b6 b7
private theorem p200_120 : Lanes4095.rows word 892 200 120=true := Lanes4095.combine word 892 200 40 80 b5 p240_80
private theorem p360_80 : Lanes4095.rows word 892 360 80=true := Lanes4095.combine word 892 360 40 40 b9 b10
private theorem p320_120 : Lanes4095.rows word 892 320 120=true := Lanes4095.combine word 892 320 40 80 b8 p360_80
private theorem p200_240 : Lanes4095.rows word 892 200 240=true := Lanes4095.combine word 892 200 120 120 p200_120 p320_120
private theorem p0_440 : Lanes4095.rows word 892 0 440=true := Lanes4095.combine word 892 0 200 240 p0_200 p200_240
private theorem p480_80 : Lanes4095.rows word 892 480 80=true := Lanes4095.combine word 892 480 40 40 b12 b13
private theorem p440_120 : Lanes4095.rows word 892 440 120=true := Lanes4095.combine word 892 440 40 80 b11 p480_80
private theorem p600_80 : Lanes4095.rows word 892 600 80=true := Lanes4095.combine word 892 600 40 40 b15 b16
private theorem p560_120 : Lanes4095.rows word 892 560 120=true := Lanes4095.combine word 892 560 40 80 b14 p600_80
private theorem p440_240 : Lanes4095.rows word 892 440 240=true := Lanes4095.combine word 892 440 120 120 p440_120 p560_120
private theorem p720_80 : Lanes4095.rows word 892 720 80=true := Lanes4095.combine word 892 720 40 40 b18 b19
private theorem p680_120 : Lanes4095.rows word 892 680 120=true := Lanes4095.combine word 892 680 40 80 b17 p720_80
private theorem p840_52 : Lanes4095.rows word 892 840 52=true := Lanes4095.combine word 892 840 40 12 b21 b22
private theorem p800_92 : Lanes4095.rows word 892 800 92=true := Lanes4095.combine word 892 800 40 52 b20 p840_52
private theorem p680_212 : Lanes4095.rows word 892 680 212=true := Lanes4095.combine word 892 680 120 92 p680_120 p800_92
private theorem p440_452 : Lanes4095.rows word 892 440 452=true := Lanes4095.combine word 892 440 240 212 p440_240 p680_212
private theorem p0_892 : Lanes4095.rows word 892 0 892=true := Lanes4095.combine word 892 0 440 452 p0_440 p440_452
theorem real_matrix (m:ℕ) : AtOrder m 892 := modulus_above_order (by decide : 892<4095) (Lanes4095.of_checked word wide bits p0_892) m
#print axioms real_matrix
end HadamardMod.Nineteen.R892
