import Quantum.Hadamard.NineteenRaw.R2564B86
namespace HadamardMod.Nineteen.R2564
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b87 : Lanes4095.rows word 2564 2088 24=true := by decide +kernel
end HadamardMod.Nineteen.R2564
