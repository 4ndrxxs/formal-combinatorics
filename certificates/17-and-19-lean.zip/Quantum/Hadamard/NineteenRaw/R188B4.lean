import Quantum.Hadamard.NineteenRaw.R188B3
namespace HadamardMod.Nineteen.R188
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b4 : Lanes4095.rows word 188 160 28=true := by decide +kernel
end HadamardMod.Nineteen.R188
