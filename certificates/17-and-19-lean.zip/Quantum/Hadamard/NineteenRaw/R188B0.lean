import Quantum.Hadamard.NineteenRaw.R188Data
namespace HadamardMod.Nineteen.R188
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b0 : Lanes4095.rows word 188 0 40=true := by decide +kernel
end HadamardMod.Nineteen.R188
