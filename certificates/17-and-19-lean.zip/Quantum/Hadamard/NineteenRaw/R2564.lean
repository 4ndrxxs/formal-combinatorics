import Quantum.Hadamard.NineteenRaw.R2564B0
import Quantum.Hadamard.NineteenRaw.R2564B1
import Quantum.Hadamard.NineteenRaw.R2564B2
import Quantum.Hadamard.NineteenRaw.R2564B3
import Quantum.Hadamard.NineteenRaw.R2564B4
import Quantum.Hadamard.NineteenRaw.R2564B5
import Quantum.Hadamard.NineteenRaw.R2564B6
import Quantum.Hadamard.NineteenRaw.R2564B7
import Quantum.Hadamard.NineteenRaw.R2564B8
import Quantum.Hadamard.NineteenRaw.R2564B9
import Quantum.Hadamard.NineteenRaw.R2564B10
import Quantum.Hadamard.NineteenRaw.R2564B11
import Quantum.Hadamard.NineteenRaw.R2564B12
import Quantum.Hadamard.NineteenRaw.R2564B13
import Quantum.Hadamard.NineteenRaw.R2564B14
import Quantum.Hadamard.NineteenRaw.R2564B15
import Quantum.Hadamard.NineteenRaw.R2564B16
import Quantum.Hadamard.NineteenRaw.R2564B17
import Quantum.Hadamard.NineteenRaw.R2564B18
import Quantum.Hadamard.NineteenRaw.R2564B19
import Quantum.Hadamard.NineteenRaw.R2564B20
import Quantum.Hadamard.NineteenRaw.R2564B21
import Quantum.Hadamard.NineteenRaw.R2564B22
import Quantum.Hadamard.NineteenRaw.R2564B23
import Quantum.Hadamard.NineteenRaw.R2564B24
import Quantum.Hadamard.NineteenRaw.R2564B25
import Quantum.Hadamard.NineteenRaw.R2564B26
import Quantum.Hadamard.NineteenRaw.R2564B27
import Quantum.Hadamard.NineteenRaw.R2564B28
import Quantum.Hadamard.NineteenRaw.R2564B29
import Quantum.Hadamard.NineteenRaw.R2564B30
import Quantum.Hadamard.NineteenRaw.R2564B31
import Quantum.Hadamard.NineteenRaw.R2564B32
import Quantum.Hadamard.NineteenRaw.R2564B33
import Quantum.Hadamard.NineteenRaw.R2564B34
import Quantum.Hadamard.NineteenRaw.R2564B35
import Quantum.Hadamard.NineteenRaw.R2564B36
import Quantum.Hadamard.NineteenRaw.R2564B37
import Quantum.Hadamard.NineteenRaw.R2564B38
import Quantum.Hadamard.NineteenRaw.R2564B39
import Quantum.Hadamard.NineteenRaw.R2564B40
import Quantum.Hadamard.NineteenRaw.R2564B41
import Quantum.Hadamard.NineteenRaw.R2564B42
import Quantum.Hadamard.NineteenRaw.R2564B43
import Quantum.Hadamard.NineteenRaw.R2564B44
import Quantum.Hadamard.NineteenRaw.R2564B45
import Quantum.Hadamard.NineteenRaw.R2564B46
import Quantum.Hadamard.NineteenRaw.R2564B47
import Quantum.Hadamard.NineteenRaw.R2564B48
import Quantum.Hadamard.NineteenRaw.R2564B49
import Quantum.Hadamard.NineteenRaw.R2564B50
import Quantum.Hadamard.NineteenRaw.R2564B51
import Quantum.Hadamard.NineteenRaw.R2564B52
import Quantum.Hadamard.NineteenRaw.R2564B53
import Quantum.Hadamard.NineteenRaw.R2564B54
import Quantum.Hadamard.NineteenRaw.R2564B55
import Quantum.Hadamard.NineteenRaw.R2564B56
import Quantum.Hadamard.NineteenRaw.R2564B57
import Quantum.Hadamard.NineteenRaw.R2564B58
import Quantum.Hadamard.NineteenRaw.R2564B59
import Quantum.Hadamard.NineteenRaw.R2564B60
import Quantum.Hadamard.NineteenRaw.R2564B61
import Quantum.Hadamard.NineteenRaw.R2564B62
import Quantum.Hadamard.NineteenRaw.R2564B63
import Quantum.Hadamard.NineteenRaw.R2564B64
import Quantum.Hadamard.NineteenRaw.R2564B65
import Quantum.Hadamard.NineteenRaw.R2564B66
import Quantum.Hadamard.NineteenRaw.R2564B67
import Quantum.Hadamard.NineteenRaw.R2564B68
import Quantum.Hadamard.NineteenRaw.R2564B69
import Quantum.Hadamard.NineteenRaw.R2564B70
import Quantum.Hadamard.NineteenRaw.R2564B71
import Quantum.Hadamard.NineteenRaw.R2564B72
import Quantum.Hadamard.NineteenRaw.R2564B73
import Quantum.Hadamard.NineteenRaw.R2564B74
import Quantum.Hadamard.NineteenRaw.R2564B75
import Quantum.Hadamard.NineteenRaw.R2564B76
import Quantum.Hadamard.NineteenRaw.R2564B77
import Quantum.Hadamard.NineteenRaw.R2564B78
import Quantum.Hadamard.NineteenRaw.R2564B79
import Quantum.Hadamard.NineteenRaw.R2564B80
import Quantum.Hadamard.NineteenRaw.R2564B81
import Quantum.Hadamard.NineteenRaw.R2564B82
import Quantum.Hadamard.NineteenRaw.R2564B83
import Quantum.Hadamard.NineteenRaw.R2564B84
import Quantum.Hadamard.NineteenRaw.R2564B85
import Quantum.Hadamard.NineteenRaw.R2564B86
import Quantum.Hadamard.NineteenRaw.R2564B87
import Quantum.Hadamard.NineteenRaw.R2564B88
import Quantum.Hadamard.NineteenRaw.R2564B89
import Quantum.Hadamard.NineteenRaw.R2564B90
import Quantum.Hadamard.NineteenRaw.R2564B91
import Quantum.Hadamard.NineteenRaw.R2564B92
import Quantum.Hadamard.NineteenRaw.R2564B93
import Quantum.Hadamard.NineteenRaw.R2564B94
import Quantum.Hadamard.NineteenRaw.R2564B95
import Quantum.Hadamard.NineteenRaw.R2564B96
import Quantum.Hadamard.NineteenRaw.R2564B97
import Quantum.Hadamard.NineteenRaw.R2564B98
import Quantum.Hadamard.NineteenRaw.R2564B99
import Quantum.Hadamard.NineteenRaw.R2564B100
import Quantum.Hadamard.NineteenRaw.R2564B101
import Quantum.Hadamard.NineteenRaw.R2564B102
import Quantum.Hadamard.NineteenRaw.R2564B103
import Quantum.Hadamard.NineteenRaw.R2564B104
import Quantum.Hadamard.NineteenRaw.R2564B105
import Quantum.Hadamard.NineteenRaw.R2564B106
namespace HadamardMod.Nineteen.R2564
set_option maxRecDepth 150000
private theorem p24_48 : Lanes4095.rows word 2564 24 48=true := Lanes4095.combine word 2564 24 24 24 b1 b2
private theorem p0_72 : Lanes4095.rows word 2564 0 72=true := Lanes4095.combine word 2564 0 24 48 b0 p24_48
private theorem p96_48 : Lanes4095.rows word 2564 96 48=true := Lanes4095.combine word 2564 96 24 24 b4 b5
private theorem p72_72 : Lanes4095.rows word 2564 72 72=true := Lanes4095.combine word 2564 72 24 48 b3 p96_48
private theorem p0_144 : Lanes4095.rows word 2564 0 144=true := Lanes4095.combine word 2564 0 72 72 p0_72 p72_72
private theorem p168_48 : Lanes4095.rows word 2564 168 48=true := Lanes4095.combine word 2564 168 24 24 b7 b8
private theorem p144_72 : Lanes4095.rows word 2564 144 72=true := Lanes4095.combine word 2564 144 24 48 b6 p168_48
private theorem p216_48 : Lanes4095.rows word 2564 216 48=true := Lanes4095.combine word 2564 216 24 24 b9 b10
private theorem p264_48 : Lanes4095.rows word 2564 264 48=true := Lanes4095.combine word 2564 264 24 24 b11 b12
private theorem p216_96 : Lanes4095.rows word 2564 216 96=true := Lanes4095.combine word 2564 216 48 48 p216_48 p264_48
private theorem p144_168 : Lanes4095.rows word 2564 144 168=true := Lanes4095.combine word 2564 144 72 96 p144_72 p216_96
private theorem p0_312 : Lanes4095.rows word 2564 0 312=true := Lanes4095.combine word 2564 0 144 168 p0_144 p144_168
private theorem p336_48 : Lanes4095.rows word 2564 336 48=true := Lanes4095.combine word 2564 336 24 24 b14 b15
private theorem p312_72 : Lanes4095.rows word 2564 312 72=true := Lanes4095.combine word 2564 312 24 48 b13 p336_48
private theorem p408_48 : Lanes4095.rows word 2564 408 48=true := Lanes4095.combine word 2564 408 24 24 b17 b18
private theorem p384_72 : Lanes4095.rows word 2564 384 72=true := Lanes4095.combine word 2564 384 24 48 b16 p408_48
private theorem p312_144 : Lanes4095.rows word 2564 312 144=true := Lanes4095.combine word 2564 312 72 72 p312_72 p384_72
private theorem p480_48 : Lanes4095.rows word 2564 480 48=true := Lanes4095.combine word 2564 480 24 24 b20 b21
private theorem p456_72 : Lanes4095.rows word 2564 456 72=true := Lanes4095.combine word 2564 456 24 48 b19 p480_48
private theorem p528_48 : Lanes4095.rows word 2564 528 48=true := Lanes4095.combine word 2564 528 24 24 b22 b23
private theorem p576_48 : Lanes4095.rows word 2564 576 48=true := Lanes4095.combine word 2564 576 24 24 b24 b25
private theorem p528_96 : Lanes4095.rows word 2564 528 96=true := Lanes4095.combine word 2564 528 48 48 p528_48 p576_48
private theorem p456_168 : Lanes4095.rows word 2564 456 168=true := Lanes4095.combine word 2564 456 72 96 p456_72 p528_96
private theorem p312_312 : Lanes4095.rows word 2564 312 312=true := Lanes4095.combine word 2564 312 144 168 p312_144 p456_168
private theorem p0_624 : Lanes4095.rows word 2564 0 624=true := Lanes4095.combine word 2564 0 312 312 p0_312 p312_312
private theorem p648_48 : Lanes4095.rows word 2564 648 48=true := Lanes4095.combine word 2564 648 24 24 b27 b28
private theorem p624_72 : Lanes4095.rows word 2564 624 72=true := Lanes4095.combine word 2564 624 24 48 b26 p648_48
private theorem p720_48 : Lanes4095.rows word 2564 720 48=true := Lanes4095.combine word 2564 720 24 24 b30 b31
private theorem p696_72 : Lanes4095.rows word 2564 696 72=true := Lanes4095.combine word 2564 696 24 48 b29 p720_48
private theorem p624_144 : Lanes4095.rows word 2564 624 144=true := Lanes4095.combine word 2564 624 72 72 p624_72 p696_72
private theorem p792_48 : Lanes4095.rows word 2564 792 48=true := Lanes4095.combine word 2564 792 24 24 b33 b34
private theorem p768_72 : Lanes4095.rows word 2564 768 72=true := Lanes4095.combine word 2564 768 24 48 b32 p792_48
private theorem p840_48 : Lanes4095.rows word 2564 840 48=true := Lanes4095.combine word 2564 840 24 24 b35 b36
private theorem p888_48 : Lanes4095.rows word 2564 888 48=true := Lanes4095.combine word 2564 888 24 24 b37 b38
private theorem p840_96 : Lanes4095.rows word 2564 840 96=true := Lanes4095.combine word 2564 840 48 48 p840_48 p888_48
private theorem p768_168 : Lanes4095.rows word 2564 768 168=true := Lanes4095.combine word 2564 768 72 96 p768_72 p840_96
private theorem p624_312 : Lanes4095.rows word 2564 624 312=true := Lanes4095.combine word 2564 624 144 168 p624_144 p768_168
private theorem p960_48 : Lanes4095.rows word 2564 960 48=true := Lanes4095.combine word 2564 960 24 24 b40 b41
private theorem p936_72 : Lanes4095.rows word 2564 936 72=true := Lanes4095.combine word 2564 936 24 48 b39 p960_48
private theorem p1008_48 : Lanes4095.rows word 2564 1008 48=true := Lanes4095.combine word 2564 1008 24 24 b42 b43
private theorem p1056_48 : Lanes4095.rows word 2564 1056 48=true := Lanes4095.combine word 2564 1056 24 24 b44 b45
private theorem p1008_96 : Lanes4095.rows word 2564 1008 96=true := Lanes4095.combine word 2564 1008 48 48 p1008_48 p1056_48
private theorem p936_168 : Lanes4095.rows word 2564 936 168=true := Lanes4095.combine word 2564 936 72 96 p936_72 p1008_96
private theorem p1128_48 : Lanes4095.rows word 2564 1128 48=true := Lanes4095.combine word 2564 1128 24 24 b47 b48
private theorem p1104_72 : Lanes4095.rows word 2564 1104 72=true := Lanes4095.combine word 2564 1104 24 48 b46 p1128_48
private theorem p1176_48 : Lanes4095.rows word 2564 1176 48=true := Lanes4095.combine word 2564 1176 24 24 b49 b50
private theorem p1224_48 : Lanes4095.rows word 2564 1224 48=true := Lanes4095.combine word 2564 1224 24 24 b51 b52
private theorem p1176_96 : Lanes4095.rows word 2564 1176 96=true := Lanes4095.combine word 2564 1176 48 48 p1176_48 p1224_48
private theorem p1104_168 : Lanes4095.rows word 2564 1104 168=true := Lanes4095.combine word 2564 1104 72 96 p1104_72 p1176_96
private theorem p936_336 : Lanes4095.rows word 2564 936 336=true := Lanes4095.combine word 2564 936 168 168 p936_168 p1104_168
private theorem p624_648 : Lanes4095.rows word 2564 624 648=true := Lanes4095.combine word 2564 624 312 336 p624_312 p936_336
private theorem p0_1272 : Lanes4095.rows word 2564 0 1272=true := Lanes4095.combine word 2564 0 624 648 p0_624 p624_648
private theorem p1296_48 : Lanes4095.rows word 2564 1296 48=true := Lanes4095.combine word 2564 1296 24 24 b54 b55
private theorem p1272_72 : Lanes4095.rows word 2564 1272 72=true := Lanes4095.combine word 2564 1272 24 48 b53 p1296_48
private theorem p1368_48 : Lanes4095.rows word 2564 1368 48=true := Lanes4095.combine word 2564 1368 24 24 b57 b58
private theorem p1344_72 : Lanes4095.rows word 2564 1344 72=true := Lanes4095.combine word 2564 1344 24 48 b56 p1368_48
private theorem p1272_144 : Lanes4095.rows word 2564 1272 144=true := Lanes4095.combine word 2564 1272 72 72 p1272_72 p1344_72
private theorem p1440_48 : Lanes4095.rows word 2564 1440 48=true := Lanes4095.combine word 2564 1440 24 24 b60 b61
private theorem p1416_72 : Lanes4095.rows word 2564 1416 72=true := Lanes4095.combine word 2564 1416 24 48 b59 p1440_48
private theorem p1488_48 : Lanes4095.rows word 2564 1488 48=true := Lanes4095.combine word 2564 1488 24 24 b62 b63
private theorem p1536_48 : Lanes4095.rows word 2564 1536 48=true := Lanes4095.combine word 2564 1536 24 24 b64 b65
private theorem p1488_96 : Lanes4095.rows word 2564 1488 96=true := Lanes4095.combine word 2564 1488 48 48 p1488_48 p1536_48
private theorem p1416_168 : Lanes4095.rows word 2564 1416 168=true := Lanes4095.combine word 2564 1416 72 96 p1416_72 p1488_96
private theorem p1272_312 : Lanes4095.rows word 2564 1272 312=true := Lanes4095.combine word 2564 1272 144 168 p1272_144 p1416_168
private theorem p1608_48 : Lanes4095.rows word 2564 1608 48=true := Lanes4095.combine word 2564 1608 24 24 b67 b68
private theorem p1584_72 : Lanes4095.rows word 2564 1584 72=true := Lanes4095.combine word 2564 1584 24 48 b66 p1608_48
private theorem p1656_48 : Lanes4095.rows word 2564 1656 48=true := Lanes4095.combine word 2564 1656 24 24 b69 b70
private theorem p1704_48 : Lanes4095.rows word 2564 1704 48=true := Lanes4095.combine word 2564 1704 24 24 b71 b72
private theorem p1656_96 : Lanes4095.rows word 2564 1656 96=true := Lanes4095.combine word 2564 1656 48 48 p1656_48 p1704_48
private theorem p1584_168 : Lanes4095.rows word 2564 1584 168=true := Lanes4095.combine word 2564 1584 72 96 p1584_72 p1656_96
private theorem p1776_48 : Lanes4095.rows word 2564 1776 48=true := Lanes4095.combine word 2564 1776 24 24 b74 b75
private theorem p1752_72 : Lanes4095.rows word 2564 1752 72=true := Lanes4095.combine word 2564 1752 24 48 b73 p1776_48
private theorem p1824_48 : Lanes4095.rows word 2564 1824 48=true := Lanes4095.combine word 2564 1824 24 24 b76 b77
private theorem p1872_48 : Lanes4095.rows word 2564 1872 48=true := Lanes4095.combine word 2564 1872 24 24 b78 b79
private theorem p1824_96 : Lanes4095.rows word 2564 1824 96=true := Lanes4095.combine word 2564 1824 48 48 p1824_48 p1872_48
private theorem p1752_168 : Lanes4095.rows word 2564 1752 168=true := Lanes4095.combine word 2564 1752 72 96 p1752_72 p1824_96
private theorem p1584_336 : Lanes4095.rows word 2564 1584 336=true := Lanes4095.combine word 2564 1584 168 168 p1584_168 p1752_168
private theorem p1272_648 : Lanes4095.rows word 2564 1272 648=true := Lanes4095.combine word 2564 1272 312 336 p1272_312 p1584_336
private theorem p1944_48 : Lanes4095.rows word 2564 1944 48=true := Lanes4095.combine word 2564 1944 24 24 b81 b82
private theorem p1920_72 : Lanes4095.rows word 2564 1920 72=true := Lanes4095.combine word 2564 1920 24 48 b80 p1944_48
private theorem p2016_48 : Lanes4095.rows word 2564 2016 48=true := Lanes4095.combine word 2564 2016 24 24 b84 b85
private theorem p1992_72 : Lanes4095.rows word 2564 1992 72=true := Lanes4095.combine word 2564 1992 24 48 b83 p2016_48
private theorem p1920_144 : Lanes4095.rows word 2564 1920 144=true := Lanes4095.combine word 2564 1920 72 72 p1920_72 p1992_72
private theorem p2088_48 : Lanes4095.rows word 2564 2088 48=true := Lanes4095.combine word 2564 2088 24 24 b87 b88
private theorem p2064_72 : Lanes4095.rows word 2564 2064 72=true := Lanes4095.combine word 2564 2064 24 48 b86 p2088_48
private theorem p2136_48 : Lanes4095.rows word 2564 2136 48=true := Lanes4095.combine word 2564 2136 24 24 b89 b90
private theorem p2184_48 : Lanes4095.rows word 2564 2184 48=true := Lanes4095.combine word 2564 2184 24 24 b91 b92
private theorem p2136_96 : Lanes4095.rows word 2564 2136 96=true := Lanes4095.combine word 2564 2136 48 48 p2136_48 p2184_48
private theorem p2064_168 : Lanes4095.rows word 2564 2064 168=true := Lanes4095.combine word 2564 2064 72 96 p2064_72 p2136_96
private theorem p1920_312 : Lanes4095.rows word 2564 1920 312=true := Lanes4095.combine word 2564 1920 144 168 p1920_144 p2064_168
private theorem p2256_48 : Lanes4095.rows word 2564 2256 48=true := Lanes4095.combine word 2564 2256 24 24 b94 b95
private theorem p2232_72 : Lanes4095.rows word 2564 2232 72=true := Lanes4095.combine word 2564 2232 24 48 b93 p2256_48
private theorem p2304_48 : Lanes4095.rows word 2564 2304 48=true := Lanes4095.combine word 2564 2304 24 24 b96 b97
private theorem p2352_48 : Lanes4095.rows word 2564 2352 48=true := Lanes4095.combine word 2564 2352 24 24 b98 b99
private theorem p2304_96 : Lanes4095.rows word 2564 2304 96=true := Lanes4095.combine word 2564 2304 48 48 p2304_48 p2352_48
private theorem p2232_168 : Lanes4095.rows word 2564 2232 168=true := Lanes4095.combine word 2564 2232 72 96 p2232_72 p2304_96
private theorem p2424_48 : Lanes4095.rows word 2564 2424 48=true := Lanes4095.combine word 2564 2424 24 24 b101 b102
private theorem p2400_72 : Lanes4095.rows word 2564 2400 72=true := Lanes4095.combine word 2564 2400 24 48 b100 p2424_48
private theorem p2472_48 : Lanes4095.rows word 2564 2472 48=true := Lanes4095.combine word 2564 2472 24 24 b103 b104
private theorem p2520_44 : Lanes4095.rows word 2564 2520 44=true := Lanes4095.combine word 2564 2520 24 20 b105 b106
private theorem p2472_92 : Lanes4095.rows word 2564 2472 92=true := Lanes4095.combine word 2564 2472 48 44 p2472_48 p2520_44
private theorem p2400_164 : Lanes4095.rows word 2564 2400 164=true := Lanes4095.combine word 2564 2400 72 92 p2400_72 p2472_92
private theorem p2232_332 : Lanes4095.rows word 2564 2232 332=true := Lanes4095.combine word 2564 2232 168 164 p2232_168 p2400_164
private theorem p1920_644 : Lanes4095.rows word 2564 1920 644=true := Lanes4095.combine word 2564 1920 312 332 p1920_312 p2232_332
private theorem p1272_1292 : Lanes4095.rows word 2564 1272 1292=true := Lanes4095.combine word 2564 1272 648 644 p1272_648 p1920_644
private theorem p0_2564 : Lanes4095.rows word 2564 0 2564=true := Lanes4095.combine word 2564 0 1272 1292 p0_1272 p1272_1292
theorem real_matrix (m:ℕ) : AtOrder m 2564 := modulus_above_order (by decide : 2564<4095) (Lanes4095.of_checked word wide bits p0_2564) m
#print axioms real_matrix
end HadamardMod.Nineteen.R2564
