import Quantum.Hadamard.NineteenRaw.R1100B12
namespace HadamardMod.Nineteen.R1100
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b13 : Lanes4095.rows word 1100 520 40=true := by decide +kernel
end HadamardMod.Nineteen.R1100
