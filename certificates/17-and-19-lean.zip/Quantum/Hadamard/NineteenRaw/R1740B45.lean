import Quantum.Hadamard.NineteenRaw.R1740B44
namespace HadamardMod.Nineteen.R1740
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b45 : Lanes4095.rows word 1740 1080 24=true := by decide +kernel
end HadamardMod.Nineteen.R1740
