import Quantum.Hadamard.NineteenRaw.R324B0
import Quantum.Hadamard.NineteenRaw.R324B1
import Quantum.Hadamard.NineteenRaw.R324B2
import Quantum.Hadamard.NineteenRaw.R324B3
import Quantum.Hadamard.NineteenRaw.R324B4
import Quantum.Hadamard.NineteenRaw.R324B5
import Quantum.Hadamard.NineteenRaw.R324B6
import Quantum.Hadamard.NineteenRaw.R324B7
import Quantum.Hadamard.NineteenRaw.R324B8
namespace HadamardMod.Nineteen.R324
set_option maxRecDepth 150000
private theorem p0_80 : Lanes4095.rows word 324 0 80=true := Lanes4095.combine word 324 0 40 40 b0 b1
private theorem p80_80 : Lanes4095.rows word 324 80 80=true := Lanes4095.combine word 324 80 40 40 b2 b3
private theorem p0_160 : Lanes4095.rows word 324 0 160=true := Lanes4095.combine word 324 0 80 80 p0_80 p80_80
private theorem p160_80 : Lanes4095.rows word 324 160 80=true := Lanes4095.combine word 324 160 40 40 b4 b5
private theorem p280_44 : Lanes4095.rows word 324 280 44=true := Lanes4095.combine word 324 280 40 4 b7 b8
private theorem p240_84 : Lanes4095.rows word 324 240 84=true := Lanes4095.combine word 324 240 40 44 b6 p280_44
private theorem p160_164 : Lanes4095.rows word 324 160 164=true := Lanes4095.combine word 324 160 80 84 p160_80 p240_84
private theorem p0_324 : Lanes4095.rows word 324 0 324=true := Lanes4095.combine word 324 0 160 164 p0_160 p160_164
theorem real_matrix (m:ℕ) : AtOrder m 324 := modulus_above_order (by decide : 324<4095) (Lanes4095.of_checked word wide bits p0_324) m
#print axioms real_matrix
end HadamardMod.Nineteen.R324
