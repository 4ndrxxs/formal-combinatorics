import Quantum.Hadamard.NineteenRaw.R1100B5
namespace HadamardMod.Nineteen.R1100
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b6 : Lanes4095.rows word 1100 240 40=true := by decide +kernel
end HadamardMod.Nineteen.R1100
