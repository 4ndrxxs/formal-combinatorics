import Quantum.Hadamard.NineteenRaw.R892B10
namespace HadamardMod.Nineteen.R892
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b11 : Lanes4095.rows word 892 440 40=true := by decide +kernel
end HadamardMod.Nineteen.R892
