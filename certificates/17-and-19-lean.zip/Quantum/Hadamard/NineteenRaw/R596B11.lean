import Quantum.Hadamard.NineteenRaw.R596B10
namespace HadamardMod.Nineteen.R596
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b11 : Lanes4095.rows word 596 440 40=true := by decide +kernel
end HadamardMod.Nineteen.R596
