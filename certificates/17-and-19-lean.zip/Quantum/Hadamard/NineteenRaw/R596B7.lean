import Quantum.Hadamard.NineteenRaw.R596B6
namespace HadamardMod.Nineteen.R596
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b7 : Lanes4095.rows word 596 280 40=true := by decide +kernel
end HadamardMod.Nineteen.R596
