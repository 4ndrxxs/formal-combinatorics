import Quantum.Hadamard.NineteenRaw.R428B3
namespace HadamardMod.Nineteen.R428
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b4 : Lanes4095.rows word 428 160 40=true := by decide +kernel
end HadamardMod.Nineteen.R428
