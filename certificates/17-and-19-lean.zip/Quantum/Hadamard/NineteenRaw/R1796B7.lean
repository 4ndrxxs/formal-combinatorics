import Quantum.Hadamard.NineteenRaw.R1796B6
namespace HadamardMod.Nineteen.R1796
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b7 : Lanes4095.rows word 1796 168 24=true := by decide +kernel
end HadamardMod.Nineteen.R1796
