import Quantum.Hadamard.NineteenRaw.R1740B0
import Quantum.Hadamard.NineteenRaw.R1740B1
import Quantum.Hadamard.NineteenRaw.R1740B2
import Quantum.Hadamard.NineteenRaw.R1740B3
import Quantum.Hadamard.NineteenRaw.R1740B4
import Quantum.Hadamard.NineteenRaw.R1740B5
import Quantum.Hadamard.NineteenRaw.R1740B6
import Quantum.Hadamard.NineteenRaw.R1740B7
import Quantum.Hadamard.NineteenRaw.R1740B8
import Quantum.Hadamard.NineteenRaw.R1740B9
import Quantum.Hadamard.NineteenRaw.R1740B10
import Quantum.Hadamard.NineteenRaw.R1740B11
import Quantum.Hadamard.NineteenRaw.R1740B12
import Quantum.Hadamard.NineteenRaw.R1740B13
import Quantum.Hadamard.NineteenRaw.R1740B14
import Quantum.Hadamard.NineteenRaw.R1740B15
import Quantum.Hadamard.NineteenRaw.R1740B16
import Quantum.Hadamard.NineteenRaw.R1740B17
import Quantum.Hadamard.NineteenRaw.R1740B18
import Quantum.Hadamard.NineteenRaw.R1740B19
import Quantum.Hadamard.NineteenRaw.R1740B20
import Quantum.Hadamard.NineteenRaw.R1740B21
import Quantum.Hadamard.NineteenRaw.R1740B22
import Quantum.Hadamard.NineteenRaw.R1740B23
import Quantum.Hadamard.NineteenRaw.R1740B24
import Quantum.Hadamard.NineteenRaw.R1740B25
import Quantum.Hadamard.NineteenRaw.R1740B26
import Quantum.Hadamard.NineteenRaw.R1740B27
import Quantum.Hadamard.NineteenRaw.R1740B28
import Quantum.Hadamard.NineteenRaw.R1740B29
import Quantum.Hadamard.NineteenRaw.R1740B30
import Quantum.Hadamard.NineteenRaw.R1740B31
import Quantum.Hadamard.NineteenRaw.R1740B32
import Quantum.Hadamard.NineteenRaw.R1740B33
import Quantum.Hadamard.NineteenRaw.R1740B34
import Quantum.Hadamard.NineteenRaw.R1740B35
import Quantum.Hadamard.NineteenRaw.R1740B36
import Quantum.Hadamard.NineteenRaw.R1740B37
import Quantum.Hadamard.NineteenRaw.R1740B38
import Quantum.Hadamard.NineteenRaw.R1740B39
import Quantum.Hadamard.NineteenRaw.R1740B40
import Quantum.Hadamard.NineteenRaw.R1740B41
import Quantum.Hadamard.NineteenRaw.R1740B42
import Quantum.Hadamard.NineteenRaw.R1740B43
import Quantum.Hadamard.NineteenRaw.R1740B44
import Quantum.Hadamard.NineteenRaw.R1740B45
import Quantum.Hadamard.NineteenRaw.R1740B46
import Quantum.Hadamard.NineteenRaw.R1740B47
import Quantum.Hadamard.NineteenRaw.R1740B48
import Quantum.Hadamard.NineteenRaw.R1740B49
import Quantum.Hadamard.NineteenRaw.R1740B50
import Quantum.Hadamard.NineteenRaw.R1740B51
import Quantum.Hadamard.NineteenRaw.R1740B52
import Quantum.Hadamard.NineteenRaw.R1740B53
import Quantum.Hadamard.NineteenRaw.R1740B54
import Quantum.Hadamard.NineteenRaw.R1740B55
import Quantum.Hadamard.NineteenRaw.R1740B56
import Quantum.Hadamard.NineteenRaw.R1740B57
import Quantum.Hadamard.NineteenRaw.R1740B58
import Quantum.Hadamard.NineteenRaw.R1740B59
import Quantum.Hadamard.NineteenRaw.R1740B60
import Quantum.Hadamard.NineteenRaw.R1740B61
import Quantum.Hadamard.NineteenRaw.R1740B62
import Quantum.Hadamard.NineteenRaw.R1740B63
import Quantum.Hadamard.NineteenRaw.R1740B64
import Quantum.Hadamard.NineteenRaw.R1740B65
import Quantum.Hadamard.NineteenRaw.R1740B66
import Quantum.Hadamard.NineteenRaw.R1740B67
import Quantum.Hadamard.NineteenRaw.R1740B68
import Quantum.Hadamard.NineteenRaw.R1740B69
import Quantum.Hadamard.NineteenRaw.R1740B70
import Quantum.Hadamard.NineteenRaw.R1740B71
import Quantum.Hadamard.NineteenRaw.R1740B72
namespace HadamardMod.Nineteen.R1740
set_option maxRecDepth 150000
private theorem p0_48 : Lanes4095.rows word 1740 0 48=true := Lanes4095.combine word 1740 0 24 24 b0 b1
private theorem p48_48 : Lanes4095.rows word 1740 48 48=true := Lanes4095.combine word 1740 48 24 24 b2 b3
private theorem p0_96 : Lanes4095.rows word 1740 0 96=true := Lanes4095.combine word 1740 0 48 48 p0_48 p48_48
private theorem p96_48 : Lanes4095.rows word 1740 96 48=true := Lanes4095.combine word 1740 96 24 24 b4 b5
private theorem p168_48 : Lanes4095.rows word 1740 168 48=true := Lanes4095.combine word 1740 168 24 24 b7 b8
private theorem p144_72 : Lanes4095.rows word 1740 144 72=true := Lanes4095.combine word 1740 144 24 48 b6 p168_48
private theorem p96_120 : Lanes4095.rows word 1740 96 120=true := Lanes4095.combine word 1740 96 48 72 p96_48 p144_72
private theorem p0_216 : Lanes4095.rows word 1740 0 216=true := Lanes4095.combine word 1740 0 96 120 p0_96 p96_120
private theorem p216_48 : Lanes4095.rows word 1740 216 48=true := Lanes4095.combine word 1740 216 24 24 b9 b10
private theorem p264_48 : Lanes4095.rows word 1740 264 48=true := Lanes4095.combine word 1740 264 24 24 b11 b12
private theorem p216_96 : Lanes4095.rows word 1740 216 96=true := Lanes4095.combine word 1740 216 48 48 p216_48 p264_48
private theorem p312_48 : Lanes4095.rows word 1740 312 48=true := Lanes4095.combine word 1740 312 24 24 b13 b14
private theorem p384_48 : Lanes4095.rows word 1740 384 48=true := Lanes4095.combine word 1740 384 24 24 b16 b17
private theorem p360_72 : Lanes4095.rows word 1740 360 72=true := Lanes4095.combine word 1740 360 24 48 b15 p384_48
private theorem p312_120 : Lanes4095.rows word 1740 312 120=true := Lanes4095.combine word 1740 312 48 72 p312_48 p360_72
private theorem p216_216 : Lanes4095.rows word 1740 216 216=true := Lanes4095.combine word 1740 216 96 120 p216_96 p312_120
private theorem p0_432 : Lanes4095.rows word 1740 0 432=true := Lanes4095.combine word 1740 0 216 216 p0_216 p216_216
private theorem p432_48 : Lanes4095.rows word 1740 432 48=true := Lanes4095.combine word 1740 432 24 24 b18 b19
private theorem p480_48 : Lanes4095.rows word 1740 480 48=true := Lanes4095.combine word 1740 480 24 24 b20 b21
private theorem p432_96 : Lanes4095.rows word 1740 432 96=true := Lanes4095.combine word 1740 432 48 48 p432_48 p480_48
private theorem p528_48 : Lanes4095.rows word 1740 528 48=true := Lanes4095.combine word 1740 528 24 24 b22 b23
private theorem p600_48 : Lanes4095.rows word 1740 600 48=true := Lanes4095.combine word 1740 600 24 24 b25 b26
private theorem p576_72 : Lanes4095.rows word 1740 576 72=true := Lanes4095.combine word 1740 576 24 48 b24 p600_48
private theorem p528_120 : Lanes4095.rows word 1740 528 120=true := Lanes4095.combine word 1740 528 48 72 p528_48 p576_72
private theorem p432_216 : Lanes4095.rows word 1740 432 216=true := Lanes4095.combine word 1740 432 96 120 p432_96 p528_120
private theorem p648_48 : Lanes4095.rows word 1740 648 48=true := Lanes4095.combine word 1740 648 24 24 b27 b28
private theorem p696_48 : Lanes4095.rows word 1740 696 48=true := Lanes4095.combine word 1740 696 24 24 b29 b30
private theorem p648_96 : Lanes4095.rows word 1740 648 96=true := Lanes4095.combine word 1740 648 48 48 p648_48 p696_48
private theorem p744_48 : Lanes4095.rows word 1740 744 48=true := Lanes4095.combine word 1740 744 24 24 b31 b32
private theorem p816_48 : Lanes4095.rows word 1740 816 48=true := Lanes4095.combine word 1740 816 24 24 b34 b35
private theorem p792_72 : Lanes4095.rows word 1740 792 72=true := Lanes4095.combine word 1740 792 24 48 b33 p816_48
private theorem p744_120 : Lanes4095.rows word 1740 744 120=true := Lanes4095.combine word 1740 744 48 72 p744_48 p792_72
private theorem p648_216 : Lanes4095.rows word 1740 648 216=true := Lanes4095.combine word 1740 648 96 120 p648_96 p744_120
private theorem p432_432 : Lanes4095.rows word 1740 432 432=true := Lanes4095.combine word 1740 432 216 216 p432_216 p648_216
private theorem p0_864 : Lanes4095.rows word 1740 0 864=true := Lanes4095.combine word 1740 0 432 432 p0_432 p432_432
private theorem p864_48 : Lanes4095.rows word 1740 864 48=true := Lanes4095.combine word 1740 864 24 24 b36 b37
private theorem p912_48 : Lanes4095.rows word 1740 912 48=true := Lanes4095.combine word 1740 912 24 24 b38 b39
private theorem p864_96 : Lanes4095.rows word 1740 864 96=true := Lanes4095.combine word 1740 864 48 48 p864_48 p912_48
private theorem p960_48 : Lanes4095.rows word 1740 960 48=true := Lanes4095.combine word 1740 960 24 24 b40 b41
private theorem p1032_48 : Lanes4095.rows word 1740 1032 48=true := Lanes4095.combine word 1740 1032 24 24 b43 b44
private theorem p1008_72 : Lanes4095.rows word 1740 1008 72=true := Lanes4095.combine word 1740 1008 24 48 b42 p1032_48
private theorem p960_120 : Lanes4095.rows word 1740 960 120=true := Lanes4095.combine word 1740 960 48 72 p960_48 p1008_72
private theorem p864_216 : Lanes4095.rows word 1740 864 216=true := Lanes4095.combine word 1740 864 96 120 p864_96 p960_120
private theorem p1080_48 : Lanes4095.rows word 1740 1080 48=true := Lanes4095.combine word 1740 1080 24 24 b45 b46
private theorem p1128_48 : Lanes4095.rows word 1740 1128 48=true := Lanes4095.combine word 1740 1128 24 24 b47 b48
private theorem p1080_96 : Lanes4095.rows word 1740 1080 96=true := Lanes4095.combine word 1740 1080 48 48 p1080_48 p1128_48
private theorem p1176_48 : Lanes4095.rows word 1740 1176 48=true := Lanes4095.combine word 1740 1176 24 24 b49 b50
private theorem p1248_48 : Lanes4095.rows word 1740 1248 48=true := Lanes4095.combine word 1740 1248 24 24 b52 b53
private theorem p1224_72 : Lanes4095.rows word 1740 1224 72=true := Lanes4095.combine word 1740 1224 24 48 b51 p1248_48
private theorem p1176_120 : Lanes4095.rows word 1740 1176 120=true := Lanes4095.combine word 1740 1176 48 72 p1176_48 p1224_72
private theorem p1080_216 : Lanes4095.rows word 1740 1080 216=true := Lanes4095.combine word 1740 1080 96 120 p1080_96 p1176_120
private theorem p864_432 : Lanes4095.rows word 1740 864 432=true := Lanes4095.combine word 1740 864 216 216 p864_216 p1080_216
private theorem p1296_48 : Lanes4095.rows word 1740 1296 48=true := Lanes4095.combine word 1740 1296 24 24 b54 b55
private theorem p1344_48 : Lanes4095.rows word 1740 1344 48=true := Lanes4095.combine word 1740 1344 24 24 b56 b57
private theorem p1296_96 : Lanes4095.rows word 1740 1296 96=true := Lanes4095.combine word 1740 1296 48 48 p1296_48 p1344_48
private theorem p1392_48 : Lanes4095.rows word 1740 1392 48=true := Lanes4095.combine word 1740 1392 24 24 b58 b59
private theorem p1464_48 : Lanes4095.rows word 1740 1464 48=true := Lanes4095.combine word 1740 1464 24 24 b61 b62
private theorem p1440_72 : Lanes4095.rows word 1740 1440 72=true := Lanes4095.combine word 1740 1440 24 48 b60 p1464_48
private theorem p1392_120 : Lanes4095.rows word 1740 1392 120=true := Lanes4095.combine word 1740 1392 48 72 p1392_48 p1440_72
private theorem p1296_216 : Lanes4095.rows word 1740 1296 216=true := Lanes4095.combine word 1740 1296 96 120 p1296_96 p1392_120
private theorem p1512_48 : Lanes4095.rows word 1740 1512 48=true := Lanes4095.combine word 1740 1512 24 24 b63 b64
private theorem p1584_48 : Lanes4095.rows word 1740 1584 48=true := Lanes4095.combine word 1740 1584 24 24 b66 b67
private theorem p1560_72 : Lanes4095.rows word 1740 1560 72=true := Lanes4095.combine word 1740 1560 24 48 b65 p1584_48
private theorem p1512_120 : Lanes4095.rows word 1740 1512 120=true := Lanes4095.combine word 1740 1512 48 72 p1512_48 p1560_72
private theorem p1632_48 : Lanes4095.rows word 1740 1632 48=true := Lanes4095.combine word 1740 1632 24 24 b68 b69
private theorem p1704_36 : Lanes4095.rows word 1740 1704 36=true := Lanes4095.combine word 1740 1704 24 12 b71 b72
private theorem p1680_60 : Lanes4095.rows word 1740 1680 60=true := Lanes4095.combine word 1740 1680 24 36 b70 p1704_36
private theorem p1632_108 : Lanes4095.rows word 1740 1632 108=true := Lanes4095.combine word 1740 1632 48 60 p1632_48 p1680_60
private theorem p1512_228 : Lanes4095.rows word 1740 1512 228=true := Lanes4095.combine word 1740 1512 120 108 p1512_120 p1632_108
private theorem p1296_444 : Lanes4095.rows word 1740 1296 444=true := Lanes4095.combine word 1740 1296 216 228 p1296_216 p1512_228
private theorem p864_876 : Lanes4095.rows word 1740 864 876=true := Lanes4095.combine word 1740 864 432 444 p864_432 p1296_444
private theorem p0_1740 : Lanes4095.rows word 1740 0 1740=true := Lanes4095.combine word 1740 0 864 876 p0_864 p864_876
theorem real_matrix (m:ℕ) : AtOrder m 1740 := modulus_above_order (by decide : 1740<4095) (Lanes4095.of_checked word wide bits p0_1740) m
#print axioms real_matrix
end HadamardMod.Nineteen.R1740
