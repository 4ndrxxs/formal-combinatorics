import Quantum.Hadamard.NineteenRaw.R324B2
namespace HadamardMod.Nineteen.R324
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b3 : Lanes4095.rows word 324 120 40=true := by decide +kernel
end HadamardMod.Nineteen.R324
