import Quantum.Hadamard.NineteenRaw.R324B5
namespace HadamardMod.Nineteen.R324
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b6 : Lanes4095.rows word 324 240 40=true := by decide +kernel
end HadamardMod.Nineteen.R324
