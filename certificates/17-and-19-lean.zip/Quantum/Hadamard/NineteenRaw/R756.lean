import Quantum.Hadamard.NineteenRaw.R756B0
import Quantum.Hadamard.NineteenRaw.R756B1
import Quantum.Hadamard.NineteenRaw.R756B2
import Quantum.Hadamard.NineteenRaw.R756B3
import Quantum.Hadamard.NineteenRaw.R756B4
import Quantum.Hadamard.NineteenRaw.R756B5
import Quantum.Hadamard.NineteenRaw.R756B6
import Quantum.Hadamard.NineteenRaw.R756B7
import Quantum.Hadamard.NineteenRaw.R756B8
import Quantum.Hadamard.NineteenRaw.R756B9
import Quantum.Hadamard.NineteenRaw.R756B10
import Quantum.Hadamard.NineteenRaw.R756B11
import Quantum.Hadamard.NineteenRaw.R756B12
import Quantum.Hadamard.NineteenRaw.R756B13
import Quantum.Hadamard.NineteenRaw.R756B14
import Quantum.Hadamard.NineteenRaw.R756B15
import Quantum.Hadamard.NineteenRaw.R756B16
import Quantum.Hadamard.NineteenRaw.R756B17
import Quantum.Hadamard.NineteenRaw.R756B18
namespace HadamardMod.Nineteen.R756
set_option maxRecDepth 150000
private theorem p0_80 : Lanes4095.rows word 756 0 80=true := Lanes4095.combine word 756 0 40 40 b0 b1
private theorem p80_80 : Lanes4095.rows word 756 80 80=true := Lanes4095.combine word 756 80 40 40 b2 b3
private theorem p0_160 : Lanes4095.rows word 756 0 160=true := Lanes4095.combine word 756 0 80 80 p0_80 p80_80
private theorem p160_80 : Lanes4095.rows word 756 160 80=true := Lanes4095.combine word 756 160 40 40 b4 b5
private theorem p280_80 : Lanes4095.rows word 756 280 80=true := Lanes4095.combine word 756 280 40 40 b7 b8
private theorem p240_120 : Lanes4095.rows word 756 240 120=true := Lanes4095.combine word 756 240 40 80 b6 p280_80
private theorem p160_200 : Lanes4095.rows word 756 160 200=true := Lanes4095.combine word 756 160 80 120 p160_80 p240_120
private theorem p0_360 : Lanes4095.rows word 756 0 360=true := Lanes4095.combine word 756 0 160 200 p0_160 p160_200
private theorem p360_80 : Lanes4095.rows word 756 360 80=true := Lanes4095.combine word 756 360 40 40 b9 b10
private theorem p480_80 : Lanes4095.rows word 756 480 80=true := Lanes4095.combine word 756 480 40 40 b12 b13
private theorem p440_120 : Lanes4095.rows word 756 440 120=true := Lanes4095.combine word 756 440 40 80 b11 p480_80
private theorem p360_200 : Lanes4095.rows word 756 360 200=true := Lanes4095.combine word 756 360 80 120 p360_80 p440_120
private theorem p560_80 : Lanes4095.rows word 756 560 80=true := Lanes4095.combine word 756 560 40 40 b14 b15
private theorem p680_76 : Lanes4095.rows word 756 680 76=true := Lanes4095.combine word 756 680 40 36 b17 b18
private theorem p640_116 : Lanes4095.rows word 756 640 116=true := Lanes4095.combine word 756 640 40 76 b16 p680_76
private theorem p560_196 : Lanes4095.rows word 756 560 196=true := Lanes4095.combine word 756 560 80 116 p560_80 p640_116
private theorem p360_396 : Lanes4095.rows word 756 360 396=true := Lanes4095.combine word 756 360 200 196 p360_200 p560_196
private theorem p0_756 : Lanes4095.rows word 756 0 756=true := Lanes4095.combine word 756 0 360 396 p0_360 p360_396
theorem real_matrix (m:ℕ) : AtOrder m 756 := modulus_above_order (by decide : 756<4095) (Lanes4095.of_checked word wide bits p0_756) m
#print axioms real_matrix
end HadamardMod.Nineteen.R756
