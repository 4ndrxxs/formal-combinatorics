import Quantum.Hadamard.NineteenRaw.R1796B68
namespace HadamardMod.Nineteen.R1796
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b69 : Lanes4095.rows word 1796 1656 24=true := by decide +kernel
end HadamardMod.Nineteen.R1796
