import Quantum.Hadamard.NineteenRaw.R404B0
import Quantum.Hadamard.NineteenRaw.R404B1
import Quantum.Hadamard.NineteenRaw.R404B2
import Quantum.Hadamard.NineteenRaw.R404B3
import Quantum.Hadamard.NineteenRaw.R404B4
import Quantum.Hadamard.NineteenRaw.R404B5
import Quantum.Hadamard.NineteenRaw.R404B6
import Quantum.Hadamard.NineteenRaw.R404B7
import Quantum.Hadamard.NineteenRaw.R404B8
import Quantum.Hadamard.NineteenRaw.R404B9
import Quantum.Hadamard.NineteenRaw.R404B10
namespace HadamardMod.Nineteen.R404
set_option maxRecDepth 150000
private theorem p0_80 : Lanes4095.rows word 404 0 80=true := Lanes4095.combine word 404 0 40 40 b0 b1
private theorem p120_80 : Lanes4095.rows word 404 120 80=true := Lanes4095.combine word 404 120 40 40 b3 b4
private theorem p80_120 : Lanes4095.rows word 404 80 120=true := Lanes4095.combine word 404 80 40 80 b2 p120_80
private theorem p0_200 : Lanes4095.rows word 404 0 200=true := Lanes4095.combine word 404 0 80 120 p0_80 p80_120
private theorem p240_80 : Lanes4095.rows word 404 240 80=true := Lanes4095.combine word 404 240 40 40 b6 b7
private theorem p200_120 : Lanes4095.rows word 404 200 120=true := Lanes4095.combine word 404 200 40 80 b5 p240_80
private theorem p360_44 : Lanes4095.rows word 404 360 44=true := Lanes4095.combine word 404 360 40 4 b9 b10
private theorem p320_84 : Lanes4095.rows word 404 320 84=true := Lanes4095.combine word 404 320 40 44 b8 p360_44
private theorem p200_204 : Lanes4095.rows word 404 200 204=true := Lanes4095.combine word 404 200 120 84 p200_120 p320_84
private theorem p0_404 : Lanes4095.rows word 404 0 404=true := Lanes4095.combine word 404 0 200 204 p0_200 p200_204
theorem real_matrix (m:ℕ) : AtOrder m 404 := modulus_above_order (by decide : 404<4095) (Lanes4095.of_checked word wide bits p0_404) m
#print axioms real_matrix
end HadamardMod.Nineteen.R404
