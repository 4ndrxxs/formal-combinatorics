import Quantum.Hadamard.NineteenRaw.R1796B0
import Quantum.Hadamard.NineteenRaw.R1796B1
import Quantum.Hadamard.NineteenRaw.R1796B2
import Quantum.Hadamard.NineteenRaw.R1796B3
import Quantum.Hadamard.NineteenRaw.R1796B4
import Quantum.Hadamard.NineteenRaw.R1796B5
import Quantum.Hadamard.NineteenRaw.R1796B6
import Quantum.Hadamard.NineteenRaw.R1796B7
import Quantum.Hadamard.NineteenRaw.R1796B8
import Quantum.Hadamard.NineteenRaw.R1796B9
import Quantum.Hadamard.NineteenRaw.R1796B10
import Quantum.Hadamard.NineteenRaw.R1796B11
import Quantum.Hadamard.NineteenRaw.R1796B12
import Quantum.Hadamard.NineteenRaw.R1796B13
import Quantum.Hadamard.NineteenRaw.R1796B14
import Quantum.Hadamard.NineteenRaw.R1796B15
import Quantum.Hadamard.NineteenRaw.R1796B16
import Quantum.Hadamard.NineteenRaw.R1796B17
import Quantum.Hadamard.NineteenRaw.R1796B18
import Quantum.Hadamard.NineteenRaw.R1796B19
import Quantum.Hadamard.NineteenRaw.R1796B20
import Quantum.Hadamard.NineteenRaw.R1796B21
import Quantum.Hadamard.NineteenRaw.R1796B22
import Quantum.Hadamard.NineteenRaw.R1796B23
import Quantum.Hadamard.NineteenRaw.R1796B24
import Quantum.Hadamard.NineteenRaw.R1796B25
import Quantum.Hadamard.NineteenRaw.R1796B26
import Quantum.Hadamard.NineteenRaw.R1796B27
import Quantum.Hadamard.NineteenRaw.R1796B28
import Quantum.Hadamard.NineteenRaw.R1796B29
import Quantum.Hadamard.NineteenRaw.R1796B30
import Quantum.Hadamard.NineteenRaw.R1796B31
import Quantum.Hadamard.NineteenRaw.R1796B32
import Quantum.Hadamard.NineteenRaw.R1796B33
import Quantum.Hadamard.NineteenRaw.R1796B34
import Quantum.Hadamard.NineteenRaw.R1796B35
import Quantum.Hadamard.NineteenRaw.R1796B36
import Quantum.Hadamard.NineteenRaw.R1796B37
import Quantum.Hadamard.NineteenRaw.R1796B38
import Quantum.Hadamard.NineteenRaw.R1796B39
import Quantum.Hadamard.NineteenRaw.R1796B40
import Quantum.Hadamard.NineteenRaw.R1796B41
import Quantum.Hadamard.NineteenRaw.R1796B42
import Quantum.Hadamard.NineteenRaw.R1796B43
import Quantum.Hadamard.NineteenRaw.R1796B44
import Quantum.Hadamard.NineteenRaw.R1796B45
import Quantum.Hadamard.NineteenRaw.R1796B46
import Quantum.Hadamard.NineteenRaw.R1796B47
import Quantum.Hadamard.NineteenRaw.R1796B48
import Quantum.Hadamard.NineteenRaw.R1796B49
import Quantum.Hadamard.NineteenRaw.R1796B50
import Quantum.Hadamard.NineteenRaw.R1796B51
import Quantum.Hadamard.NineteenRaw.R1796B52
import Quantum.Hadamard.NineteenRaw.R1796B53
import Quantum.Hadamard.NineteenRaw.R1796B54
import Quantum.Hadamard.NineteenRaw.R1796B55
import Quantum.Hadamard.NineteenRaw.R1796B56
import Quantum.Hadamard.NineteenRaw.R1796B57
import Quantum.Hadamard.NineteenRaw.R1796B58
import Quantum.Hadamard.NineteenRaw.R1796B59
import Quantum.Hadamard.NineteenRaw.R1796B60
import Quantum.Hadamard.NineteenRaw.R1796B61
import Quantum.Hadamard.NineteenRaw.R1796B62
import Quantum.Hadamard.NineteenRaw.R1796B63
import Quantum.Hadamard.NineteenRaw.R1796B64
import Quantum.Hadamard.NineteenRaw.R1796B65
import Quantum.Hadamard.NineteenRaw.R1796B66
import Quantum.Hadamard.NineteenRaw.R1796B67
import Quantum.Hadamard.NineteenRaw.R1796B68
import Quantum.Hadamard.NineteenRaw.R1796B69
import Quantum.Hadamard.NineteenRaw.R1796B70
import Quantum.Hadamard.NineteenRaw.R1796B71
import Quantum.Hadamard.NineteenRaw.R1796B72
import Quantum.Hadamard.NineteenRaw.R1796B73
import Quantum.Hadamard.NineteenRaw.R1796B74
namespace HadamardMod.Nineteen.R1796
set_option maxRecDepth 150000
private theorem p0_48 : Lanes4095.rows word 1796 0 48=true := Lanes4095.combine word 1796 0 24 24 b0 b1
private theorem p48_48 : Lanes4095.rows word 1796 48 48=true := Lanes4095.combine word 1796 48 24 24 b2 b3
private theorem p0_96 : Lanes4095.rows word 1796 0 96=true := Lanes4095.combine word 1796 0 48 48 p0_48 p48_48
private theorem p96_48 : Lanes4095.rows word 1796 96 48=true := Lanes4095.combine word 1796 96 24 24 b4 b5
private theorem p168_48 : Lanes4095.rows word 1796 168 48=true := Lanes4095.combine word 1796 168 24 24 b7 b8
private theorem p144_72 : Lanes4095.rows word 1796 144 72=true := Lanes4095.combine word 1796 144 24 48 b6 p168_48
private theorem p96_120 : Lanes4095.rows word 1796 96 120=true := Lanes4095.combine word 1796 96 48 72 p96_48 p144_72
private theorem p0_216 : Lanes4095.rows word 1796 0 216=true := Lanes4095.combine word 1796 0 96 120 p0_96 p96_120
private theorem p216_48 : Lanes4095.rows word 1796 216 48=true := Lanes4095.combine word 1796 216 24 24 b9 b10
private theorem p264_48 : Lanes4095.rows word 1796 264 48=true := Lanes4095.combine word 1796 264 24 24 b11 b12
private theorem p216_96 : Lanes4095.rows word 1796 216 96=true := Lanes4095.combine word 1796 216 48 48 p216_48 p264_48
private theorem p312_48 : Lanes4095.rows word 1796 312 48=true := Lanes4095.combine word 1796 312 24 24 b13 b14
private theorem p384_48 : Lanes4095.rows word 1796 384 48=true := Lanes4095.combine word 1796 384 24 24 b16 b17
private theorem p360_72 : Lanes4095.rows word 1796 360 72=true := Lanes4095.combine word 1796 360 24 48 b15 p384_48
private theorem p312_120 : Lanes4095.rows word 1796 312 120=true := Lanes4095.combine word 1796 312 48 72 p312_48 p360_72
private theorem p216_216 : Lanes4095.rows word 1796 216 216=true := Lanes4095.combine word 1796 216 96 120 p216_96 p312_120
private theorem p0_432 : Lanes4095.rows word 1796 0 432=true := Lanes4095.combine word 1796 0 216 216 p0_216 p216_216
private theorem p432_48 : Lanes4095.rows word 1796 432 48=true := Lanes4095.combine word 1796 432 24 24 b18 b19
private theorem p480_48 : Lanes4095.rows word 1796 480 48=true := Lanes4095.combine word 1796 480 24 24 b20 b21
private theorem p432_96 : Lanes4095.rows word 1796 432 96=true := Lanes4095.combine word 1796 432 48 48 p432_48 p480_48
private theorem p528_48 : Lanes4095.rows word 1796 528 48=true := Lanes4095.combine word 1796 528 24 24 b22 b23
private theorem p600_48 : Lanes4095.rows word 1796 600 48=true := Lanes4095.combine word 1796 600 24 24 b25 b26
private theorem p576_72 : Lanes4095.rows word 1796 576 72=true := Lanes4095.combine word 1796 576 24 48 b24 p600_48
private theorem p528_120 : Lanes4095.rows word 1796 528 120=true := Lanes4095.combine word 1796 528 48 72 p528_48 p576_72
private theorem p432_216 : Lanes4095.rows word 1796 432 216=true := Lanes4095.combine word 1796 432 96 120 p432_96 p528_120
private theorem p648_48 : Lanes4095.rows word 1796 648 48=true := Lanes4095.combine word 1796 648 24 24 b27 b28
private theorem p720_48 : Lanes4095.rows word 1796 720 48=true := Lanes4095.combine word 1796 720 24 24 b30 b31
private theorem p696_72 : Lanes4095.rows word 1796 696 72=true := Lanes4095.combine word 1796 696 24 48 b29 p720_48
private theorem p648_120 : Lanes4095.rows word 1796 648 120=true := Lanes4095.combine word 1796 648 48 72 p648_48 p696_72
private theorem p768_48 : Lanes4095.rows word 1796 768 48=true := Lanes4095.combine word 1796 768 24 24 b32 b33
private theorem p840_48 : Lanes4095.rows word 1796 840 48=true := Lanes4095.combine word 1796 840 24 24 b35 b36
private theorem p816_72 : Lanes4095.rows word 1796 816 72=true := Lanes4095.combine word 1796 816 24 48 b34 p840_48
private theorem p768_120 : Lanes4095.rows word 1796 768 120=true := Lanes4095.combine word 1796 768 48 72 p768_48 p816_72
private theorem p648_240 : Lanes4095.rows word 1796 648 240=true := Lanes4095.combine word 1796 648 120 120 p648_120 p768_120
private theorem p432_456 : Lanes4095.rows word 1796 432 456=true := Lanes4095.combine word 1796 432 216 240 p432_216 p648_240
private theorem p0_888 : Lanes4095.rows word 1796 0 888=true := Lanes4095.combine word 1796 0 432 456 p0_432 p432_456
private theorem p888_48 : Lanes4095.rows word 1796 888 48=true := Lanes4095.combine word 1796 888 24 24 b37 b38
private theorem p936_48 : Lanes4095.rows word 1796 936 48=true := Lanes4095.combine word 1796 936 24 24 b39 b40
private theorem p888_96 : Lanes4095.rows word 1796 888 96=true := Lanes4095.combine word 1796 888 48 48 p888_48 p936_48
private theorem p984_48 : Lanes4095.rows word 1796 984 48=true := Lanes4095.combine word 1796 984 24 24 b41 b42
private theorem p1056_48 : Lanes4095.rows word 1796 1056 48=true := Lanes4095.combine word 1796 1056 24 24 b44 b45
private theorem p1032_72 : Lanes4095.rows word 1796 1032 72=true := Lanes4095.combine word 1796 1032 24 48 b43 p1056_48
private theorem p984_120 : Lanes4095.rows word 1796 984 120=true := Lanes4095.combine word 1796 984 48 72 p984_48 p1032_72
private theorem p888_216 : Lanes4095.rows word 1796 888 216=true := Lanes4095.combine word 1796 888 96 120 p888_96 p984_120
private theorem p1104_48 : Lanes4095.rows word 1796 1104 48=true := Lanes4095.combine word 1796 1104 24 24 b46 b47
private theorem p1176_48 : Lanes4095.rows word 1796 1176 48=true := Lanes4095.combine word 1796 1176 24 24 b49 b50
private theorem p1152_72 : Lanes4095.rows word 1796 1152 72=true := Lanes4095.combine word 1796 1152 24 48 b48 p1176_48
private theorem p1104_120 : Lanes4095.rows word 1796 1104 120=true := Lanes4095.combine word 1796 1104 48 72 p1104_48 p1152_72
private theorem p1224_48 : Lanes4095.rows word 1796 1224 48=true := Lanes4095.combine word 1796 1224 24 24 b51 b52
private theorem p1296_48 : Lanes4095.rows word 1796 1296 48=true := Lanes4095.combine word 1796 1296 24 24 b54 b55
private theorem p1272_72 : Lanes4095.rows word 1796 1272 72=true := Lanes4095.combine word 1796 1272 24 48 b53 p1296_48
private theorem p1224_120 : Lanes4095.rows word 1796 1224 120=true := Lanes4095.combine word 1796 1224 48 72 p1224_48 p1272_72
private theorem p1104_240 : Lanes4095.rows word 1796 1104 240=true := Lanes4095.combine word 1796 1104 120 120 p1104_120 p1224_120
private theorem p888_456 : Lanes4095.rows word 1796 888 456=true := Lanes4095.combine word 1796 888 216 240 p888_216 p1104_240
private theorem p1344_48 : Lanes4095.rows word 1796 1344 48=true := Lanes4095.combine word 1796 1344 24 24 b56 b57
private theorem p1392_48 : Lanes4095.rows word 1796 1392 48=true := Lanes4095.combine word 1796 1392 24 24 b58 b59
private theorem p1344_96 : Lanes4095.rows word 1796 1344 96=true := Lanes4095.combine word 1796 1344 48 48 p1344_48 p1392_48
private theorem p1440_48 : Lanes4095.rows word 1796 1440 48=true := Lanes4095.combine word 1796 1440 24 24 b60 b61
private theorem p1512_48 : Lanes4095.rows word 1796 1512 48=true := Lanes4095.combine word 1796 1512 24 24 b63 b64
private theorem p1488_72 : Lanes4095.rows word 1796 1488 72=true := Lanes4095.combine word 1796 1488 24 48 b62 p1512_48
private theorem p1440_120 : Lanes4095.rows word 1796 1440 120=true := Lanes4095.combine word 1796 1440 48 72 p1440_48 p1488_72
private theorem p1344_216 : Lanes4095.rows word 1796 1344 216=true := Lanes4095.combine word 1796 1344 96 120 p1344_96 p1440_120
private theorem p1560_48 : Lanes4095.rows word 1796 1560 48=true := Lanes4095.combine word 1796 1560 24 24 b65 b66
private theorem p1632_48 : Lanes4095.rows word 1796 1632 48=true := Lanes4095.combine word 1796 1632 24 24 b68 b69
private theorem p1608_72 : Lanes4095.rows word 1796 1608 72=true := Lanes4095.combine word 1796 1608 24 48 b67 p1632_48
private theorem p1560_120 : Lanes4095.rows word 1796 1560 120=true := Lanes4095.combine word 1796 1560 48 72 p1560_48 p1608_72
private theorem p1680_48 : Lanes4095.rows word 1796 1680 48=true := Lanes4095.combine word 1796 1680 24 24 b70 b71
private theorem p1752_44 : Lanes4095.rows word 1796 1752 44=true := Lanes4095.combine word 1796 1752 24 20 b73 b74
private theorem p1728_68 : Lanes4095.rows word 1796 1728 68=true := Lanes4095.combine word 1796 1728 24 44 b72 p1752_44
private theorem p1680_116 : Lanes4095.rows word 1796 1680 116=true := Lanes4095.combine word 1796 1680 48 68 p1680_48 p1728_68
private theorem p1560_236 : Lanes4095.rows word 1796 1560 236=true := Lanes4095.combine word 1796 1560 120 116 p1560_120 p1680_116
private theorem p1344_452 : Lanes4095.rows word 1796 1344 452=true := Lanes4095.combine word 1796 1344 216 236 p1344_216 p1560_236
private theorem p888_908 : Lanes4095.rows word 1796 888 908=true := Lanes4095.combine word 1796 888 456 452 p888_456 p1344_452
private theorem p0_1796 : Lanes4095.rows word 1796 0 1796=true := Lanes4095.combine word 1796 0 888 908 p0_888 p888_908
theorem real_matrix (m:ℕ) : AtOrder m 1796 := modulus_above_order (by decide : 1796<4095) (Lanes4095.of_checked word wide bits p0_1796) m
#print axioms real_matrix
end HadamardMod.Nineteen.R1796
