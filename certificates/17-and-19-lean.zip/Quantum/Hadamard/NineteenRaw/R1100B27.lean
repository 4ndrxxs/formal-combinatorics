import Quantum.Hadamard.NineteenRaw.R1100B26
namespace HadamardMod.Nineteen.R1100
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b27 : Lanes4095.rows word 1100 1080 20=true := by decide +kernel
end HadamardMod.Nineteen.R1100
