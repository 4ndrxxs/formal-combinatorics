import Quantum.Hadamard.NineteenRaw.R324Data
namespace HadamardMod.Nineteen.R324
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b0 : Lanes4095.rows word 324 0 40=true := by decide +kernel
end HadamardMod.Nineteen.R324
