import Quantum.Hadamard.NineteenRaw.R1740B14
namespace HadamardMod.Nineteen.R1740
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b15 : Lanes4095.rows word 1740 360 24=true := by decide +kernel
end HadamardMod.Nineteen.R1740
