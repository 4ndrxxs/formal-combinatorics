import Quantum.Hadamard.NineteenRaw.R668B14
namespace HadamardMod.Nineteen.R668
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b15 : Lanes4095.rows word 668 600 40=true := by decide +kernel
end HadamardMod.Nineteen.R668
