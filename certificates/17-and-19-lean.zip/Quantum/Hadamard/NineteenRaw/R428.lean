import Quantum.Hadamard.NineteenRaw.R428B0
import Quantum.Hadamard.NineteenRaw.R428B1
import Quantum.Hadamard.NineteenRaw.R428B2
import Quantum.Hadamard.NineteenRaw.R428B3
import Quantum.Hadamard.NineteenRaw.R428B4
import Quantum.Hadamard.NineteenRaw.R428B5
import Quantum.Hadamard.NineteenRaw.R428B6
import Quantum.Hadamard.NineteenRaw.R428B7
import Quantum.Hadamard.NineteenRaw.R428B8
import Quantum.Hadamard.NineteenRaw.R428B9
import Quantum.Hadamard.NineteenRaw.R428B10
namespace HadamardMod.Nineteen.R428
set_option maxRecDepth 150000
private theorem p0_80 : Lanes4095.rows word 428 0 80=true := Lanes4095.combine word 428 0 40 40 b0 b1
private theorem p120_80 : Lanes4095.rows word 428 120 80=true := Lanes4095.combine word 428 120 40 40 b3 b4
private theorem p80_120 : Lanes4095.rows word 428 80 120=true := Lanes4095.combine word 428 80 40 80 b2 p120_80
private theorem p0_200 : Lanes4095.rows word 428 0 200=true := Lanes4095.combine word 428 0 80 120 p0_80 p80_120
private theorem p240_80 : Lanes4095.rows word 428 240 80=true := Lanes4095.combine word 428 240 40 40 b6 b7
private theorem p200_120 : Lanes4095.rows word 428 200 120=true := Lanes4095.combine word 428 200 40 80 b5 p240_80
private theorem p360_68 : Lanes4095.rows word 428 360 68=true := Lanes4095.combine word 428 360 40 28 b9 b10
private theorem p320_108 : Lanes4095.rows word 428 320 108=true := Lanes4095.combine word 428 320 40 68 b8 p360_68
private theorem p200_228 : Lanes4095.rows word 428 200 228=true := Lanes4095.combine word 428 200 120 108 p200_120 p320_108
private theorem p0_428 : Lanes4095.rows word 428 0 428=true := Lanes4095.combine word 428 0 200 228 p0_200 p200_228
theorem real_matrix (m:ℕ) : AtOrder m 428 := modulus_above_order (by decide : 428<4095) (Lanes4095.of_checked word wide bits p0_428) m
#print axioms real_matrix
end HadamardMod.Nineteen.R428
