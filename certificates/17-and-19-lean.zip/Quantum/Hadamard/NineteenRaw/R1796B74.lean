import Quantum.Hadamard.NineteenRaw.R1796B73
namespace HadamardMod.Nineteen.R1796
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b74 : Lanes4095.rows word 1796 1776 20=true := by decide +kernel
end HadamardMod.Nineteen.R1796
