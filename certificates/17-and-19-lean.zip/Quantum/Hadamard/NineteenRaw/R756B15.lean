import Quantum.Hadamard.NineteenRaw.R756B14
namespace HadamardMod.Nineteen.R756
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b15 : Lanes4095.rows word 756 600 40=true := by decide +kernel
end HadamardMod.Nineteen.R756
