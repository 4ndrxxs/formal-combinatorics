import Quantum.Hadamard.NineteenRaw.R668B0
import Quantum.Hadamard.NineteenRaw.R668B1
import Quantum.Hadamard.NineteenRaw.R668B2
import Quantum.Hadamard.NineteenRaw.R668B3
import Quantum.Hadamard.NineteenRaw.R668B4
import Quantum.Hadamard.NineteenRaw.R668B5
import Quantum.Hadamard.NineteenRaw.R668B6
import Quantum.Hadamard.NineteenRaw.R668B7
import Quantum.Hadamard.NineteenRaw.R668B8
import Quantum.Hadamard.NineteenRaw.R668B9
import Quantum.Hadamard.NineteenRaw.R668B10
import Quantum.Hadamard.NineteenRaw.R668B11
import Quantum.Hadamard.NineteenRaw.R668B12
import Quantum.Hadamard.NineteenRaw.R668B13
import Quantum.Hadamard.NineteenRaw.R668B14
import Quantum.Hadamard.NineteenRaw.R668B15
import Quantum.Hadamard.NineteenRaw.R668B16
namespace HadamardMod.Nineteen.R668
set_option maxRecDepth 150000
private theorem p0_80 : Lanes4095.rows word 668 0 80=true := Lanes4095.combine word 668 0 40 40 b0 b1
private theorem p80_80 : Lanes4095.rows word 668 80 80=true := Lanes4095.combine word 668 80 40 40 b2 b3
private theorem p0_160 : Lanes4095.rows word 668 0 160=true := Lanes4095.combine word 668 0 80 80 p0_80 p80_80
private theorem p160_80 : Lanes4095.rows word 668 160 80=true := Lanes4095.combine word 668 160 40 40 b4 b5
private theorem p240_80 : Lanes4095.rows word 668 240 80=true := Lanes4095.combine word 668 240 40 40 b6 b7
private theorem p160_160 : Lanes4095.rows word 668 160 160=true := Lanes4095.combine word 668 160 80 80 p160_80 p240_80
private theorem p0_320 : Lanes4095.rows word 668 0 320=true := Lanes4095.combine word 668 0 160 160 p0_160 p160_160
private theorem p320_80 : Lanes4095.rows word 668 320 80=true := Lanes4095.combine word 668 320 40 40 b8 b9
private theorem p400_80 : Lanes4095.rows word 668 400 80=true := Lanes4095.combine word 668 400 40 40 b10 b11
private theorem p320_160 : Lanes4095.rows word 668 320 160=true := Lanes4095.combine word 668 320 80 80 p320_80 p400_80
private theorem p480_80 : Lanes4095.rows word 668 480 80=true := Lanes4095.combine word 668 480 40 40 b12 b13
private theorem p600_68 : Lanes4095.rows word 668 600 68=true := Lanes4095.combine word 668 600 40 28 b15 b16
private theorem p560_108 : Lanes4095.rows word 668 560 108=true := Lanes4095.combine word 668 560 40 68 b14 p600_68
private theorem p480_188 : Lanes4095.rows word 668 480 188=true := Lanes4095.combine word 668 480 80 108 p480_80 p560_108
private theorem p320_348 : Lanes4095.rows word 668 320 348=true := Lanes4095.combine word 668 320 160 188 p320_160 p480_188
private theorem p0_668 : Lanes4095.rows word 668 0 668=true := Lanes4095.combine word 668 0 320 348 p0_320 p320_348
theorem real_matrix (m:ℕ) : AtOrder m 668 := modulus_above_order (by decide : 668<4095) (Lanes4095.of_checked word wide bits p0_668) m
#print axioms real_matrix
end HadamardMod.Nineteen.R668
