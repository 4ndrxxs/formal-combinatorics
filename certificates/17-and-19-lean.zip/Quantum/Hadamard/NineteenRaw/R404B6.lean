import Quantum.Hadamard.NineteenRaw.R404B5
namespace HadamardMod.Nineteen.R404
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b6 : Lanes4095.rows word 404 240 40=true := by decide +kernel
end HadamardMod.Nineteen.R404
