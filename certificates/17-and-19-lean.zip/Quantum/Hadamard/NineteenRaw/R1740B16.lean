import Quantum.Hadamard.NineteenRaw.R1740B15
namespace HadamardMod.Nineteen.R1740
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b16 : Lanes4095.rows word 1740 384 24=true := by decide +kernel
end HadamardMod.Nineteen.R1740
