import Quantum.Hadamard.NineteenRaw.R188B0
namespace HadamardMod.Nineteen.R188
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b1 : Lanes4095.rows word 188 40 40=true := by decide +kernel
end HadamardMod.Nineteen.R188
