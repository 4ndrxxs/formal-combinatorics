import Quantum.Hadamard.NineteenRaw.R2564B11
namespace HadamardMod.Nineteen.R2564
set_option maxRecDepth 150000
set_option maxHeartbeats 0
theorem b12 : Lanes4095.rows word 2564 288 24=true := by decide +kernel
end HadamardMod.Nineteen.R2564
