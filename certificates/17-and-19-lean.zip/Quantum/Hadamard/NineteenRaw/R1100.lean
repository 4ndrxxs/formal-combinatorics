import Quantum.Hadamard.NineteenRaw.R1100B0
import Quantum.Hadamard.NineteenRaw.R1100B1
import Quantum.Hadamard.NineteenRaw.R1100B2
import Quantum.Hadamard.NineteenRaw.R1100B3
import Quantum.Hadamard.NineteenRaw.R1100B4
import Quantum.Hadamard.NineteenRaw.R1100B5
import Quantum.Hadamard.NineteenRaw.R1100B6
import Quantum.Hadamard.NineteenRaw.R1100B7
import Quantum.Hadamard.NineteenRaw.R1100B8
import Quantum.Hadamard.NineteenRaw.R1100B9
import Quantum.Hadamard.NineteenRaw.R1100B10
import Quantum.Hadamard.NineteenRaw.R1100B11
import Quantum.Hadamard.NineteenRaw.R1100B12
import Quantum.Hadamard.NineteenRaw.R1100B13
import Quantum.Hadamard.NineteenRaw.R1100B14
import Quantum.Hadamard.NineteenRaw.R1100B15
import Quantum.Hadamard.NineteenRaw.R1100B16
import Quantum.Hadamard.NineteenRaw.R1100B17
import Quantum.Hadamard.NineteenRaw.R1100B18
import Quantum.Hadamard.NineteenRaw.R1100B19
import Quantum.Hadamard.NineteenRaw.R1100B20
import Quantum.Hadamard.NineteenRaw.R1100B21
import Quantum.Hadamard.NineteenRaw.R1100B22
import Quantum.Hadamard.NineteenRaw.R1100B23
import Quantum.Hadamard.NineteenRaw.R1100B24
import Quantum.Hadamard.NineteenRaw.R1100B25
import Quantum.Hadamard.NineteenRaw.R1100B26
import Quantum.Hadamard.NineteenRaw.R1100B27
namespace HadamardMod.Nineteen.R1100
set_option maxRecDepth 150000
private theorem p40_80 : Lanes4095.rows word 1100 40 80=true := Lanes4095.combine word 1100 40 40 40 b1 b2
private theorem p0_120 : Lanes4095.rows word 1100 0 120=true := Lanes4095.combine word 1100 0 40 80 b0 p40_80
private theorem p120_80 : Lanes4095.rows word 1100 120 80=true := Lanes4095.combine word 1100 120 40 40 b3 b4
private theorem p200_80 : Lanes4095.rows word 1100 200 80=true := Lanes4095.combine word 1100 200 40 40 b5 b6
private theorem p120_160 : Lanes4095.rows word 1100 120 160=true := Lanes4095.combine word 1100 120 80 80 p120_80 p200_80
private theorem p0_280 : Lanes4095.rows word 1100 0 280=true := Lanes4095.combine word 1100 0 120 160 p0_120 p120_160
private theorem p320_80 : Lanes4095.rows word 1100 320 80=true := Lanes4095.combine word 1100 320 40 40 b8 b9
private theorem p280_120 : Lanes4095.rows word 1100 280 120=true := Lanes4095.combine word 1100 280 40 80 b7 p320_80
private theorem p400_80 : Lanes4095.rows word 1100 400 80=true := Lanes4095.combine word 1100 400 40 40 b10 b11
private theorem p480_80 : Lanes4095.rows word 1100 480 80=true := Lanes4095.combine word 1100 480 40 40 b12 b13
private theorem p400_160 : Lanes4095.rows word 1100 400 160=true := Lanes4095.combine word 1100 400 80 80 p400_80 p480_80
private theorem p280_280 : Lanes4095.rows word 1100 280 280=true := Lanes4095.combine word 1100 280 120 160 p280_120 p400_160
private theorem p0_560 : Lanes4095.rows word 1100 0 560=true := Lanes4095.combine word 1100 0 280 280 p0_280 p280_280
private theorem p600_80 : Lanes4095.rows word 1100 600 80=true := Lanes4095.combine word 1100 600 40 40 b15 b16
private theorem p560_120 : Lanes4095.rows word 1100 560 120=true := Lanes4095.combine word 1100 560 40 80 b14 p600_80
private theorem p680_80 : Lanes4095.rows word 1100 680 80=true := Lanes4095.combine word 1100 680 40 40 b17 b18
private theorem p760_80 : Lanes4095.rows word 1100 760 80=true := Lanes4095.combine word 1100 760 40 40 b19 b20
private theorem p680_160 : Lanes4095.rows word 1100 680 160=true := Lanes4095.combine word 1100 680 80 80 p680_80 p760_80
private theorem p560_280 : Lanes4095.rows word 1100 560 280=true := Lanes4095.combine word 1100 560 120 160 p560_120 p680_160
private theorem p880_80 : Lanes4095.rows word 1100 880 80=true := Lanes4095.combine word 1100 880 40 40 b22 b23
private theorem p840_120 : Lanes4095.rows word 1100 840 120=true := Lanes4095.combine word 1100 840 40 80 b21 p880_80
private theorem p960_80 : Lanes4095.rows word 1100 960 80=true := Lanes4095.combine word 1100 960 40 40 b24 b25
private theorem p1040_60 : Lanes4095.rows word 1100 1040 60=true := Lanes4095.combine word 1100 1040 40 20 b26 b27
private theorem p960_140 : Lanes4095.rows word 1100 960 140=true := Lanes4095.combine word 1100 960 80 60 p960_80 p1040_60
private theorem p840_260 : Lanes4095.rows word 1100 840 260=true := Lanes4095.combine word 1100 840 120 140 p840_120 p960_140
private theorem p560_540 : Lanes4095.rows word 1100 560 540=true := Lanes4095.combine word 1100 560 280 260 p560_280 p840_260
private theorem p0_1100 : Lanes4095.rows word 1100 0 1100=true := Lanes4095.combine word 1100 0 560 540 p0_560 p560_540
theorem real_matrix (m:ℕ) : AtOrder m 1100 := modulus_above_order (by decide : 1100<4095) (Lanes4095.of_checked word wide bits p0_1100) m
#print axioms real_matrix
end HadamardMod.Nineteen.R1100
