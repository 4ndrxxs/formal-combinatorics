import Quantum.Hadamard.NineteenRaw.R596B0
import Quantum.Hadamard.NineteenRaw.R596B1
import Quantum.Hadamard.NineteenRaw.R596B2
import Quantum.Hadamard.NineteenRaw.R596B3
import Quantum.Hadamard.NineteenRaw.R596B4
import Quantum.Hadamard.NineteenRaw.R596B5
import Quantum.Hadamard.NineteenRaw.R596B6
import Quantum.Hadamard.NineteenRaw.R596B7
import Quantum.Hadamard.NineteenRaw.R596B8
import Quantum.Hadamard.NineteenRaw.R596B9
import Quantum.Hadamard.NineteenRaw.R596B10
import Quantum.Hadamard.NineteenRaw.R596B11
import Quantum.Hadamard.NineteenRaw.R596B12
import Quantum.Hadamard.NineteenRaw.R596B13
import Quantum.Hadamard.NineteenRaw.R596B14
namespace HadamardMod.Nineteen.R596
set_option maxRecDepth 150000
private theorem p40_80 : Lanes4095.rows word 596 40 80=true := Lanes4095.combine word 596 40 40 40 b1 b2
private theorem p0_120 : Lanes4095.rows word 596 0 120=true := Lanes4095.combine word 596 0 40 80 b0 p40_80
private theorem p120_80 : Lanes4095.rows word 596 120 80=true := Lanes4095.combine word 596 120 40 40 b3 b4
private theorem p200_80 : Lanes4095.rows word 596 200 80=true := Lanes4095.combine word 596 200 40 40 b5 b6
private theorem p120_160 : Lanes4095.rows word 596 120 160=true := Lanes4095.combine word 596 120 80 80 p120_80 p200_80
private theorem p0_280 : Lanes4095.rows word 596 0 280=true := Lanes4095.combine word 596 0 120 160 p0_120 p120_160
private theorem p280_80 : Lanes4095.rows word 596 280 80=true := Lanes4095.combine word 596 280 40 40 b7 b8
private theorem p360_80 : Lanes4095.rows word 596 360 80=true := Lanes4095.combine word 596 360 40 40 b9 b10
private theorem p280_160 : Lanes4095.rows word 596 280 160=true := Lanes4095.combine word 596 280 80 80 p280_80 p360_80
private theorem p440_80 : Lanes4095.rows word 596 440 80=true := Lanes4095.combine word 596 440 40 40 b11 b12
private theorem p520_76 : Lanes4095.rows word 596 520 76=true := Lanes4095.combine word 596 520 40 36 b13 b14
private theorem p440_156 : Lanes4095.rows word 596 440 156=true := Lanes4095.combine word 596 440 80 76 p440_80 p520_76
private theorem p280_316 : Lanes4095.rows word 596 280 316=true := Lanes4095.combine word 596 280 160 156 p280_160 p440_156
private theorem p0_596 : Lanes4095.rows word 596 0 596=true := Lanes4095.combine word 596 0 280 316 p0_280 p280_316
theorem real_matrix (m:ℕ) : AtOrder m 596 := modulus_above_order (by decide : 596<4095) (Lanes4095.of_checked word wide bits p0_596) m
#print axioms real_matrix
end HadamardMod.Nineteen.R596
