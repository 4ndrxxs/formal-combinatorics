import Quantum.Hadamard.NineteenCirculants.V93
namespace HadamardMod.Nineteen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert103
private def words : Fin 4 → ℕ := ![10141204801825835211973625643006,0,1760368345969468176824550810518,0]
private def mult (i:Fin 2) : Fin 103  := Fin.ofNat _ (#[98,102][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 103  := Fin.ofNat _ (#[41,102][i.val]! : ℕ)
private def level (i:Fin 103) : ℕ := #[0,0,7,13,14,51,20,47,21,24,7,42,27,30,3,11,28,32,31,22,14,9,49,27,34,49,37,37,10,16,18,46,35,2,39,47,38,10,29,43,21,1,16,26,5,24,34,18,41,43,5,45,44,6,44,40,17,35,23,4,25,15,2,20,42,30,9,39,46,40,3,36,45,19,17,11,36,38,50,33,28,48,8,13,23,32,33,29,12,4,31,26,41,6,25,22,48,19,50,15,12,8,1][i.val]!
private def step (i:Fin 103) : Fin 2  := Fin.ofNat _ (#[0,0,0,1,0,1,1,0,0,0,1,1,1,0,0,0,0,0,0,0,1,1,1,0,1,0,0,1,0,0,0,1,0,0,0,1,0,1,0,1,1,0,1,1,1,1,0,1,1,0,0,1,0,1,1,0,0,1,0,0,0,0,1,0,0,1,0,1,0,1,1,1,0,1,1,1,0,1,1,0,1,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,0,1,0,1,1][i.val]! : ℕ)
theorem result : AtOrder 19 (4*103) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert103
end HadamardMod.Nineteen
