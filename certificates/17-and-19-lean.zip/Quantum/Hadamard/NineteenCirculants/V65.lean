import Quantum.Hadamard.NineteenCirculants.V43
namespace HadamardMod.Nineteen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert65
private def words : Fin 4 → ℕ := ![35703375626534616030,21426528425725225554,14281350800436769164,35698872026907237342]
private def mult (i:Fin 2) : Fin 65  := Fin.ofNat _ (#[59,64][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 65  := Fin.ofNat _ (#[54,64][i.val]! : ℕ)
private def level (i:Fin 65) : ℕ := #[0,0,0,3,9,0,12,10,9,3,1,2,12,0,7,4,4,8,3,5,2,10,2,9,7,4,0,6,7,11,5,4,4,5,3,6,10,6,5,1,3,8,10,1,9,3,6,2,7,5,5,6,1,11,1,2,2,8,11,11,1,8,4,1,1][i.val]!
private def step (i:Fin 65) : Fin 2  := Fin.ofNat _ (#[0,0,0,0,1,0,1,0,1,1,0,1,1,0,1,0,0,1,1,0,0,1,1,0,0,1,0,1,1,1,0,1,0,1,0,1,0,0,0,0,0,1,1,0,0,1,1,0,0,1,1,0,0,0,0,1,0,0,1,0,1,0,1,1,1][i.val]! : ℕ)
theorem result : AtOrder 19 (4*65) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert65
end HadamardMod.Nineteen
