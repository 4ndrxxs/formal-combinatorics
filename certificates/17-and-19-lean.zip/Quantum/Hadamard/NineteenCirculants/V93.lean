import Quantum.Hadamard.NineteenCirculants.V85
namespace HadamardMod.Nineteen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert93
private def words : Fin 4 → ℕ := ![1396619310617758458637992740,7077644397121480710863953626,1400320630720180759934338706,25504488768743413424707070]
private def mult (i:Fin 2) : Fin 93  := Fin.ofNat _ (#[82,92][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 93  := Fin.ofNat _ (#[76,92][i.val]! : ℕ)
private def level (i:Fin 93) : ℕ := #[0,0,0,0,9,8,12,4,9,14,2,15,9,12,4,5,3,2,11,7,2,4,15,7,6,10,6,11,13,13,2,0,3,15,2,12,8,14,7,9,11,5,1,11,9,4,7,6,3,8,10,2,6,12,8,8,13,7,13,1,14,4,1,3,12,14,12,5,11,7,6,14,5,3,8,10,1,4,6,5,11,10,14,3,13,10,5,13,9,10,1,1,1][i.val]!
private def step (i:Fin 93) : Fin 2  := Fin.ofNat _ (#[0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,0,0,1,1,0,0,0,1,1,0,0,1,0,0,1,0,0,0,1,1,0,1,1,0,1,0,0,0,1,1,1,1,0,0,0,0,1,1,1,0,1,0,0,1,0,0,1,1,1,0,1,1,0,1,1,0,0,1,1,1,0,0,1,1,1,0,1,0,1,0,1,1,1,1,1,1,1,1][i.val]! : ℕ)
theorem result : AtOrder 19 (4*93) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert93
end HadamardMod.Nineteen
