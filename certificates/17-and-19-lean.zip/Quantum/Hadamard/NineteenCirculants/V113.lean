import Quantum.Hadamard.NineteenCirculants.V109
namespace HadamardMod.Nineteen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert113
private def words : Fin 4 → ℕ := ![8561596147842411913300398058103190,0,10357930495283864187676812512056830,8585639269525596893793762630814614]
private def mult (i:Fin 1) : Fin 113  := Fin.ofNat _ (#[97][i.val]! : ℕ)
private def inv (i:Fin 1) : Fin 113  := Fin.ofNat _ (#[7][i.val]! : ℕ)
private def level (i:Fin 113) : ℕ := #[0,0,0,0,3,0,0,1,3,0,0,9,3,0,1,9,6,13,13,2,3,1,8,5,3,4,4,4,4,11,12,6,6,13,2,1,3,12,2,5,3,9,1,8,12,9,5,6,6,2,8,12,3,5,4,4,4,11,11,11,12,10,5,1,9,13,13,12,2,5,1,8,2,10,12,9,5,10,8,9,6,13,13,5,4,11,11,11,11,10,12,1,8,10,9,6,6,13,2,8,7,10,2,7,7,10,8,7,7,10,7,7,7][i.val]!
private def step (i:Fin 113) : Fin 1  := Fin.ofNat _ (#[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0][i.val]! : ℕ)
theorem result : AtOrder 19 (4*113) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert113
end HadamardMod.Nineteen
