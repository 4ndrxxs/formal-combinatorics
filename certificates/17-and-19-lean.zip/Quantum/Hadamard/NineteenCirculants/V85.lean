import Quantum.Hadamard.NineteenCirculants.V73
namespace HadamardMod.Nineteen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert85
private def words : Fin 4 → ℕ := ![37437702800969161539288030,23709363325583514563858034,37437702800969161539288030,14976262902084619026739596]
private def mult (i:Fin 2) : Fin 85  := Fin.ofNat _ (#[76,84][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 85  := Fin.ofNat _ (#[66,84][i.val]! : ℕ)
private def level (i:Fin 85) : ℕ := #[0,0,0,0,7,0,0,4,7,8,2,4,7,6,4,0,4,0,8,2,2,2,3,5,7,3,3,8,1,2,2,7,4,4,0,4,5,5,2,6,4,2,2,3,3,3,5,1,4,6,3,1,3,5,8,1,1,2,7,4,2,6,6,2,3,3,1,7,1,5,1,3,5,6,5,1,7,6,3,1,1,6,1,1,1][i.val]!
private def step (i:Fin 85) : Fin 2  := Fin.ofNat _ (#[0,0,0,0,1,0,0,1,1,1,1,0,1,1,1,0,0,0,1,1,0,0,1,0,1,1,0,1,0,1,1,0,0,1,0,1,0,1,1,1,1,0,0,1,1,0,0,0,0,1,0,1,0,1,1,0,0,1,0,1,0,0,1,0,1,1,0,0,1,1,1,0,0,0,1,0,0,0,0,1,1,0,1,1,1][i.val]! : ℕ)
theorem result : AtOrder 19 (4*85) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert85
end HadamardMod.Nineteen
