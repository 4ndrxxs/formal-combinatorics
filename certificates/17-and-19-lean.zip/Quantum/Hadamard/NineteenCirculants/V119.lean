import Quantum.Hadamard.NineteenCirculants.V113
namespace HadamardMod.Nineteen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert119
private def words : Fin 4 → ℕ := ![549483697073430292780434454740628712,5315271425951361674516589237879702,115367263455644958846017405088570472,5640028908129230178458029448878078]
private def mult (i:Fin 2) : Fin 119  := Fin.ofNat _ (#[100,118][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 119  := Fin.ofNat _ (#[25,118][i.val]! : ℕ)
private def level (i:Fin 119) : ℕ := #[0,0,11,0,22,10,11,0,9,5,21,4,22,7,3,15,20,0,16,24,8,0,15,8,9,1,18,5,3,3,2,12,7,9,2,2,3,5,11,7,19,17,3,21,2,15,19,15,20,1,12,2,5,19,16,19,1,24,14,14,13,13,23,2,18,17,20,4,1,13,2,21,14,18,16,1,22,4,18,20,6,10,4,4,3,3,8,8,13,3,2,2,6,17,2,10,7,14,1,9,23,17,1,21,16,4,6,23,3,22,6,10,1,12,11,23,1,12,1][i.val]!
private def step (i:Fin 119) : Fin 2  := Fin.ofNat _ (#[0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,1,0,0,1,1,0,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,0,0,0,1,0,1,1,0,0,0,1,1,0,0,1,0,1,1,1,0,0,0,1,0,1,1,0,0,1,1,1,0,0,1,0,1,1,1,1,0,0,0,1,1,1,0,1,1,1,0,0,1,0,1,1,0,0,1,1,0,1,1,1,1,1,0,1,0,1,1,1,1,1,1,1,1,1,1][i.val]! : ℕ)
theorem result : AtOrder 19 (4*119) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert119
end HadamardMod.Nineteen
