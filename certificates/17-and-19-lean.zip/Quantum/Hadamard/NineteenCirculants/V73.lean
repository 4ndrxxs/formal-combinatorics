import Quantum.Hadamard.NineteenCirculants.V65
namespace HadamardMod.Nineteen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert73
private def words : Fin 4 → ℕ := ![18482773012462502166,0,18482773012462502166,0]
private def mult (i:Fin 2) : Fin 73  := Fin.ofNat _ (#[55,72][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 73  := Fin.ofNat _ (#[4,72][i.val]! : ℕ)
private def level (i:Fin 73) : ℕ := #[0,0,5,0,1,0,5,2,6,4,5,0,1,8,7,6,2,9,9,8,1,8,5,7,6,3,4,4,3,2,2,5,7,7,5,5,5,4,4,4,6,8,4,3,1,4,3,3,2,7,8,6,9,2,9,8,8,3,7,8,7,2,1,6,3,7,3,6,1,2,1,6,1][i.val]!
private def step (i:Fin 73) : Fin 2  := Fin.ofNat _ (#[0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,1,1,0,0,0,0,0,0,1,1,1,0,1,0,1,0,1,1,1,1,0,0,0,0,1,0,1,0,1,0,0,0,1,1,1,1,1,1,0,0,1,1,1,0,1,1,1,0,1,1,1,1,1,1,1,1][i.val]! : ℕ)
theorem result : AtOrder 19 (4*73) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert73
end HadamardMod.Nineteen
