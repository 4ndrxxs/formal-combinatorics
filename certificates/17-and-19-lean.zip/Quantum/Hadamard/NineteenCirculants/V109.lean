import Quantum.Hadamard.NineteenCirculants.V103
namespace HadamardMod.Nineteen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert109
private def words : Fin 4 → ℕ := ![475955680532168492806985487996670,473022961816146413042658758988474,475955680532168492806985487996670,2932718716022079764326729008196]
private def mult (i:Fin 2) : Fin 109  := Fin.ofNat _ (#[97,108][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 109  := Fin.ofNat _ (#[9,108][i.val]! : ℕ)
private def level (i:Fin 109) : ℕ := #[0,0,0,14,13,8,14,17,13,1,8,8,27,12,17,22,24,18,1,10,21,4,19,6,27,16,23,15,3,6,22,11,24,22,4,25,14,13,21,26,21,3,4,7,19,9,19,10,11,7,16,5,23,2,15,16,3,24,6,17,8,12,11,18,10,20,6,5,4,20,25,22,14,13,26,3,21,25,10,23,5,2,16,24,17,26,7,20,5,20,9,2,19,25,23,18,11,26,7,9,2,12,18,15,9,12,15,1,1][i.val]!
private def step (i:Fin 109) : Fin 2  := Fin.ofNat _ (#[0,0,0,0,1,0,0,0,1,0,0,1,1,1,0,0,0,0,0,1,1,0,0,0,1,0,0,0,1,1,0,1,0,1,1,0,1,0,0,1,1,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,0,1,1,0,1,0,0,1,0,1,0,0,1,1,1,0,1,1,1,0,0,1,1,1,1,1,0,0,0,1,1,0,1,1,1,0,1,1,1][i.val]! : ℕ)
theorem result : AtOrder 19 (4*109) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert109
end HadamardMod.Nineteen
