import Quantum.Hadamard.NineteenCirculants.V25
namespace HadamardMod.Nineteen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert43
private def words : Fin 4 → ℕ := ![8796093022206,3678700564050,8796093022206,3678700564050]
private def mult (i:Fin 2) : Fin 43  := Fin.ofNat _ (#[40,42][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 43  := Fin.ofNat _ (#[14,42][i.val]! : ℕ)
private def level (i:Fin 43) : ℕ := #[0,0,16,21,9,18,14,8,4,19,11,12,9,10,1,16,18,4,14,3,6,6,7,5,2,13,5,19,17,2,11,8,13,12,20,3,7,15,17,10,20,15,1][i.val]!
private def step (i:Fin 43) : Fin 2  := Fin.ofNat _ (#[0,0,1,1,0,1,0,1,1,0,0,0,1,0,0,0,0,0,1,1,1,0,1,0,0,0,1,1,1,1,1,0,1,1,1,0,0,1,0,1,0,0,1][i.val]! : ℕ)
theorem result : AtOrder 19 (4*43) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert43
end HadamardMod.Nineteen
