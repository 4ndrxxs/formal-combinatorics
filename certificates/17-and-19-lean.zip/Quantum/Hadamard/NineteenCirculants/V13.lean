import Quantum.Hadamard.GoethalsOrbit
namespace HadamardMod.Nineteen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert13
private def words : Fin 4 → ℕ := ![5106,3084,7470,7470]
private def mult (i:Fin 1) : Fin 13  := Fin.ofNat _ (#[8][i.val]! : ℕ)
private def inv (i:Fin 1) : Fin 13  := Fin.ofNat _ (#[5][i.val]! : ℕ)
private def level (i:Fin 13) : ℕ := #[0,0,0,3,0,1,3,1,3,2,1,2,2][i.val]!
private def step (i:Fin 13) : Fin 1  := Fin.ofNat _ (#[0,0,0,0,0,0,0,0,0,0,0,0,0][i.val]! : ℕ)
theorem result : AtOrder 19 (4*13) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert13
end HadamardMod.Nineteen
