import Quantum.Hadamard.NineteenCirculants.V13
namespace HadamardMod.Nineteen
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Cert25
private def words : Fin 4 → ℕ := ![4362404,15154670,2197602,23813878]
private def mult (i:Fin 2) : Fin 25  := Fin.ofNat _ (#[21,24][i.val]! : ℕ)
private def inv (i:Fin 2) : Fin 25  := Fin.ofNat _ (#[6,24][i.val]! : ℕ)
private def level (i:Fin 25) : ℕ := #[0,0,0,3,5,0,1,3,5,4,0,2,1,2,3,1,3,4,4,2,1,4,2,1,1][i.val]!
private def step (i:Fin 25) : Fin 2  := Fin.ofNat _ (#[0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,1,0,0,1,1,1,0,0,1,1][i.val]! : ℕ)
theorem result : AtOrder 19 (4*25) := of_multiplier_four words mult inv level step
  (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end Cert25
end HadamardMod.Nineteen
