import Quantum.Hadamard.Basic

/-! At an order strictly below the modulus, all modular off-diagonal inner
products between sign rows vanish over the ordinary integers. -/
namespace HadamardMod
open Finset

theorem modulus_above_order {b n : ℕ} (small : n<b) (h : AtOrder b n) (m : ℕ) : AtOrder m n := by
  obtain ⟨H,sign,gram⟩ := integer_gram h
  let A : RowMatrix m (Fin n) := fun i j => (H i j:ZMod m)
  refine ⟨A,⟨?_,?_⟩⟩
  · intro i j
    rcases sign i j with s|s <;> simp [A,s,Sign]
  · intro i k ne
    let f (j:Fin n) := H i j*H k j
    have each (j:Fin n) : -1≤f j ∧ f j≤1 := by
      rcases sign i j with a|a <;> rcases sign k j with c|c <;> simp [f,a,c]
    have lo := Finset.sum_le_sum (s:=Finset.univ) (fun j _ => (each j).1)
    have hi := Finset.sum_le_sum (s:=Finset.univ) (fun j _ => (each j).2)
    simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,
      Int.cast_ofNat,mul_one,mul_neg,Int.cast_natCast] at lo hi
    have div : (b:ℤ) ∣ ∑ j,f j := by simpa [f,Matrix.mul_apply,ne] using gram i k
    have zero : ∑ j,f j=0 := by
      apply Int.eq_zero_of_dvd_of_natAbs_lt_natAbs div
      rw [Int.natAbs_natCast]
      have lt : (n:ℤ)<b := by exact_mod_cast small
      have v : |∑ j,f j|<(b:ℤ) := abs_lt.mpr ⟨by linarith,by linarith⟩
      rw [←Int.natCast_natAbs] at v
      exact_mod_cast v
    have eq := congrArg (fun v:ℤ => (v:ZMod m)) zero
    simpa only [A,f,Int.cast_sum,Int.cast_mul,Int.cast_zero] using eq

#print axioms modulus_above_order
end HadamardMod
