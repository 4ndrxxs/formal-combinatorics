import Quantum.Hadamard.NineteenCirculants.V965
import Quantum.Hadamard.NineteenFinite
import Quantum.Hadamard.PaleySecond
import Quantum.Hadamard.NineteenRaw.R188
import Quantum.Hadamard.NineteenRaw.R324
import Quantum.Hadamard.NineteenRaw.R404
import Quantum.Hadamard.NineteenRaw.R428
import Quantum.Hadamard.NineteenRaw.R596
import Quantum.Hadamard.NineteenRaw.R668
import Quantum.Hadamard.NineteenRaw.R756
import Quantum.Hadamard.NineteenRaw.R892
import Quantum.Hadamard.NineteenRaw.R1100
import Quantum.Hadamard.NineteenRaw.R1740
import Quantum.Hadamard.NineteenRaw.R1796
import Quantum.Hadamard.NineteenRaw.R2564
import Quantum.Hadamard.NineteenRaw.R2652

namespace HadamardMod.Nineteen
set_option maxHeartbeats 0
set_option maxRecDepth 500000

theorem order1 : AtOrder 19 1 := by
  refine ⟨fun _ _ => 1, ⟨fun _ _ => Or.inl rfl, ?_⟩⟩
  intro i j ne
  exact False.elim (ne (Subsingleton.elim i j))

theorem order2 : AtOrder 19 2 := by
  exact order_two 19

theorem order4 : AtOrder 19 4 := by
  exact offdiag_four (by decide)

theorem order8 : AtOrder 19 8 := by
  have : Fact (Nat.Prime 7) := ⟨by norm_num⟩
  exact paley_order 19 7 (by decide)

theorem order12 : AtOrder 19 12 := by
  have : Fact (Nat.Prime 11) := ⟨by norm_num⟩
  exact paley_order 19 11 (by decide)

theorem order20 : AtOrder 19 20 := by
  have : Fact (Nat.Prime 19) := ⟨by norm_num⟩
  exact paley_order 19 19 (by decide)

theorem order23 : AtOrder 19 23 := by
  exact offdiag_four (by decide)

theorem order24 : AtOrder 19 24 := by
  have : Fact (Nat.Prime 23) := ⟨by norm_num⟩
  exact paley_order 19 23 (by decide)

theorem order28 : AtOrder 19 28 := by
  have : Fact (Nat.Prime 13) := ⟨by norm_num⟩
  exact paley_second 19 13 (by decide)

theorem order32 : AtOrder 19 32 := by
  have : Fact (Nat.Prime 31) := ⟨by norm_num⟩
  exact paley_order 19 31 (by decide)

theorem order36 : AtOrder 19 36 := by
  have : Fact (Nat.Prime 17) := ⟨by norm_num⟩
  exact paley_second 19 17 (by decide)

theorem order40 : AtOrder 19 40 := by
  exact d2.iterate (n:=2) (by decide) order2 (by decide) 1

theorem order44 : AtOrder 19 44 := by
  have : Fact (Nat.Prime 43) := ⟨by norm_num⟩
  exact paley_order 19 43 (by decide)

theorem order48 : AtOrder 19 48 := by
  have : Fact (Nat.Prime 47) := ⟨by norm_num⟩
  exact paley_order 19 47 (by decide)

theorem order52 : AtOrder 19 52 := by
  exact Cert13.result

theorem order56 : AtOrder 19 56 := by
  exact at_mul (a:=2) (b:=28) order2 order28

theorem order60 : AtOrder 19 60 := by
  have : Fact (Nat.Prime 59) := ⟨by norm_num⟩
  exact paley_order 19 59 (by decide)

theorem order61 : AtOrder 19 61 := by
  exact offdiag_four (by decide)

theorem order64 : AtOrder 19 64 := by
  exact at_mul (a:=2) (b:=32) order2 order32

theorem order68 : AtOrder 19 68 := by
  have : Fact (Nat.Prime 67) := ⟨by norm_num⟩
  exact paley_order 19 67 (by decide)

theorem order72 : AtOrder 19 72 := by
  have : Fact (Nat.Prime 71) := ⟨by norm_num⟩
  exact paley_order 19 71 (by decide)

theorem order88 : AtOrder 19 88 := by
  exact goethals_residue (k:=22) (by decide)

theorem order92 : AtOrder 19 92 := by
  exact goethals_residue (k:=23) (by decide)

theorem order96 : AtOrder 19 96 := by
  exact at_mul (a:=2) (b:=48) order2 order48

theorem order99 : AtOrder 19 99 := by
  exact offdiag_four (by decide)

theorem order100 : AtOrder 19 100 := by
  exact Cert25.result

theorem order104 : AtOrder 19 104 := by
  have : Fact (Nat.Prime 103) := ⟨by norm_num⟩
  exact paley_order 19 103 (by decide)

theorem order108 : AtOrder 19 108 := by
  have : Fact (Nat.Prime 107) := ⟨by norm_num⟩
  exact paley_order 19 107 (by decide)

theorem order112 : AtOrder 19 112 := by
  exact at_mul (a:=4) (b:=28) order4 order28

theorem order120 : AtOrder 19 120 := by
  exact at_mul (a:=2) (b:=60) order2 order60

theorem order124 : AtOrder 19 124 := by
  have : Fact (Nat.Prime 61) := ⟨by norm_num⟩
  exact paley_second 19 61 (by decide)

theorem order128 : AtOrder 19 128 := by
  have : Fact (Nat.Prime 127) := ⟨by norm_num⟩
  exact paley_order 19 127 (by decide)

theorem order132 : AtOrder 19 132 := by
  have : Fact (Nat.Prime 131) := ⟨by norm_num⟩
  exact paley_order 19 131 (by decide)

theorem order136 : AtOrder 19 136 := by
  exact at_mul (a:=2) (b:=68) order2 order68

theorem order140 : AtOrder 19 140 := by
  have : Fact (Nat.Prime 139) := ⟨by norm_num⟩
  exact paley_order 19 139 (by decide)

theorem order144 : AtOrder 19 144 := by
  exact at_mul (a:=2) (b:=72) order2 order72

theorem order148 : AtOrder 19 148 := by
  have : Fact (Nat.Prime 73) := ⟨by norm_num⟩
  exact paley_second 19 73 (by decide)

theorem order164 : AtOrder 19 164 := by
  have : Fact (Nat.Prime 163) := ⟨by norm_num⟩
  exact paley_order 19 163 (by decide)

theorem order168 : AtOrder 19 168 := by
  have : Fact (Nat.Prime 167) := ⟨by norm_num⟩
  exact paley_order 19 167 (by decide)

theorem order172 : AtOrder 19 172 := by
  exact Cert43.result

theorem order176 : AtOrder 19 176 := by
  exact at_mul (a:=2) (b:=88) order2 order88

theorem order180 : AtOrder 19 180 := by
  have : Fact (Nat.Prime 179) := ⟨by norm_num⟩
  exact paley_order 19 179 (by decide)

theorem order184 : AtOrder 19 184 := by
  exact at_mul (a:=2) (b:=92) order2 order92

theorem order188 : AtOrder 19 188 := by
  exact R188.real_matrix 19

theorem order196 : AtOrder 19 196 := by
  have : Fact (Nat.Prime 97) := ⟨by norm_num⟩
  exact paley_second 19 97 (by decide)

theorem order200 : AtOrder 19 200 := by
  have : Fact (Nat.Prime 199) := ⟨by norm_num⟩
  exact paley_order 19 199 (by decide)

theorem order204 : AtOrder 19 204 := by
  have : Fact (Nat.Prime 101) := ⟨by norm_num⟩
  exact paley_second 19 101 (by decide)

theorem order208 : AtOrder 19 208 := by
  exact at_mul (a:=2) (b:=104) order2 order104

theorem order212 : AtOrder 19 212 := by
  have : Fact (Nat.Prime 211) := ⟨by norm_num⟩
  exact paley_order 19 211 (by decide)

theorem order216 : AtOrder 19 216 := by
  exact at_mul (a:=2) (b:=108) order2 order108

theorem order220 : AtOrder 19 220 := by
  have : Fact (Nat.Prime 109) := ⟨by norm_num⟩
  exact paley_second 19 109 (by decide)

theorem order224 : AtOrder 19 224 := by
  have : Fact (Nat.Prime 223) := ⟨by norm_num⟩
  exact paley_order 19 223 (by decide)

theorem order248 : AtOrder 19 248 := by
  exact at_mul (a:=2) (b:=124) order2 order124

theorem order252 : AtOrder 19 252 := by
  have : Fact (Nat.Prime 251) := ⟨by norm_num⟩
  exact paley_order 19 251 (by decide)

theorem order256 : AtOrder 19 256 := by
  exact at_mul (a:=2) (b:=128) order2 order128

theorem order260 : AtOrder 19 260 := by
  exact Cert65.result

theorem order264 : AtOrder 19 264 := by
  have : Fact (Nat.Prime 263) := ⟨by norm_num⟩
  exact paley_order 19 263 (by decide)

theorem order272 : AtOrder 19 272 := by
  have : Fact (Nat.Prime 271) := ⟨by norm_num⟩
  exact paley_order 19 271 (by decide)

theorem order276 : AtOrder 19 276 := by
  have : Fact (Nat.Prime 137) := ⟨by norm_num⟩
  exact paley_second 19 137 (by decide)

theorem order284 : AtOrder 19 284 := by
  have : Fact (Nat.Prime 283) := ⟨by norm_num⟩
  exact paley_order 19 283 (by decide)

theorem order288 : AtOrder 19 288 := by
  exact at_mul (a:=4) (b:=72) order4 order72

theorem order292 : AtOrder 19 292 := by
  exact Cert73.result

theorem order296 : AtOrder 19 296 := by
  exact at_mul (a:=2) (b:=148) order2 order148

theorem order300 : AtOrder 19 300 := by
  have : Fact (Nat.Prime 149) := ⟨by norm_num⟩
  exact paley_second 19 149 (by decide)

theorem order320 : AtOrder 19 320 := by
  exact goethals_residue (k:=80) (by decide)

theorem order324 : AtOrder 19 324 := by
  exact R324.real_matrix 19

theorem order328 : AtOrder 19 328 := by
  exact at_mul (a:=2) (b:=164) order2 order164

theorem order332 : AtOrder 19 332 := by
  have : Fact (Nat.Prime 331) := ⟨by norm_num⟩
  exact paley_order 19 331 (by decide)

theorem order336 : AtOrder 19 336 := by
  exact at_mul (a:=2) (b:=168) order2 order168

theorem order340 : AtOrder 19 340 := by
  exact Cert85.result

theorem order348 : AtOrder 19 348 := by
  have : Fact (Nat.Prime 347) := ⟨by norm_num⟩
  exact paley_order 19 347 (by decide)

theorem order352 : AtOrder 19 352 := by
  exact at_mul (a:=4) (b:=88) order4 order88

theorem order356 : AtOrder 19 356 := by
  exact d14.iterate (n:=204) (by decide) order204 (by decide) 1

theorem order360 : AtOrder 19 360 := by
  have : Fact (Nat.Prime 359) := ⟨by norm_num⟩
  exact paley_order 19 359 (by decide)

theorem order364 : AtOrder 19 364 := by
  have : Fact (Nat.Prime 181) := ⟨by norm_num⟩
  exact paley_second 19 181 (by decide)

theorem order368 : AtOrder 19 368 := by
  have : Fact (Nat.Prime 367) := ⟨by norm_num⟩
  exact paley_order 19 367 (by decide)

theorem order372 : AtOrder 19 372 := by
  exact Cert93.result

theorem order376 : AtOrder 19 376 := by
  exact at_mul (a:=2) (b:=188) order2 order188

theorem order392 : AtOrder 19 392 := by
  exact goethals_residue (k:=98) (by decide)

theorem order396 : AtOrder 19 396 := by
  have : Fact (Nat.Prime 197) := ⟨by norm_num⟩
  exact paley_second 19 197 (by decide)

theorem order400 : AtOrder 19 400 := by
  exact d1.iterate (n:=1) (by decide) order1 (by decide) 1

theorem order404 : AtOrder 19 404 := by
  exact R404.real_matrix 19

theorem order408 : AtOrder 19 408 := by
  exact at_mul (a:=2) (b:=204) order2 order204

theorem order412 : AtOrder 19 412 := by
  exact Cert103.result

theorem order416 : AtOrder 19 416 := by
  exact at_mul (a:=4) (b:=104) order4 order104

theorem order424 : AtOrder 19 424 := by
  exact at_mul (a:=2) (b:=212) order2 order212

theorem order428 : AtOrder 19 428 := by
  exact R428.real_matrix 19

theorem order436 : AtOrder 19 436 := by
  exact Cert109.result

theorem order440 : AtOrder 19 440 := by
  have : Fact (Nat.Prime 439) := ⟨by norm_num⟩
  exact paley_order 19 439 (by decide)

theorem order444 : AtOrder 19 444 := by
  have : Fact (Nat.Prime 443) := ⟨by norm_num⟩
  exact paley_order 19 443 (by decide)

theorem order448 : AtOrder 19 448 := by
  exact at_mul (a:=2) (b:=224) order2 order224

theorem order452 : AtOrder 19 452 := by
  exact Cert113.result

theorem order468 : AtOrder 19 468 := by
  have : Fact (Nat.Prime 467) := ⟨by norm_num⟩
  exact paley_order 19 467 (by decide)

theorem order472 : AtOrder 19 472 := by
  exact goethals_residue (k:=118) (by decide)

theorem order476 : AtOrder 19 476 := by
  exact Cert119.result

theorem order480 : AtOrder 19 480 := by
  have : Fact (Nat.Prime 479) := ⟨by norm_num⟩
  exact paley_order 19 479 (by decide)

theorem order484 : AtOrder 19 484 := by
  have : Fact (Nat.Prime 241) := ⟨by norm_num⟩
  exact paley_second 19 241 (by decide)

theorem order488 : AtOrder 19 488 := by
  have : Fact (Nat.Prime 487) := ⟨by norm_num⟩
  exact paley_order 19 487 (by decide)

theorem order492 : AtOrder 19 492 := by
  have : Fact (Nat.Prime 491) := ⟨by norm_num⟩
  exact paley_order 19 491 (by decide)

theorem order500 : AtOrder 19 500 := by
  have : Fact (Nat.Prime 499) := ⟨by norm_num⟩
  exact paley_order 19 499 (by decide)

theorem order504 : AtOrder 19 504 := by
  have : Fact (Nat.Prime 503) := ⟨by norm_num⟩
  exact paley_order 19 503 (by decide)

theorem order512 : AtOrder 19 512 := by
  exact at_mul (a:=4) (b:=128) order4 order128

theorem order516 : AtOrder 19 516 := by
  have : Fact (Nat.Prime 257) := ⟨by norm_num⟩
  exact paley_second 19 257 (by decide)

theorem order520 : AtOrder 19 520 := by
  exact at_mul (a:=2) (b:=260) order2 order260

theorem order524 : AtOrder 19 524 := by
  have : Fact (Nat.Prime 523) := ⟨by norm_num⟩
  exact paley_order 19 523 (by decide)

theorem order528 : AtOrder 19 528 := by
  exact at_mul (a:=2) (b:=264) order2 order264

theorem order548 : AtOrder 19 548 := by
  have : Fact (Nat.Prime 547) := ⟨by norm_num⟩
  exact paley_order 19 547 (by decide)

theorem order552 : AtOrder 19 552 := by
  exact at_mul (a:=2) (b:=276) order2 order276

theorem order556 : AtOrder 19 556 := by
  have : Fact (Nat.Prime 277) := ⟨by norm_num⟩
  exact paley_second 19 277 (by decide)

theorem order560 : AtOrder 19 560 := by
  exact at_mul (a:=4) (b:=140) order4 order140

theorem order564 : AtOrder 19 564 := by
  have : Fact (Nat.Prime 563) := ⟨by norm_num⟩
  exact paley_order 19 563 (by decide)

theorem order568 : AtOrder 19 568 := by
  exact at_mul (a:=2) (b:=284) order2 order284

theorem order576 : AtOrder 19 576 := by
  exact at_mul (a:=8) (b:=72) order8 order72

theorem order580 : AtOrder 19 580 := by
  exact Cert145.result

theorem order588 : AtOrder 19 588 := by
  have : Fact (Nat.Prime 587) := ⟨by norm_num⟩
  exact paley_order 19 587 (by decide)

theorem order592 : AtOrder 19 592 := by
  exact at_mul (a:=4) (b:=148) order4 order148

theorem order596 : AtOrder 19 596 := by
  exact R596.real_matrix 19

theorem order600 : AtOrder 19 600 := by
  have : Fact (Nat.Prime 599) := ⟨by norm_num⟩
  exact paley_order 19 599 (by decide)

theorem order604 : AtOrder 19 604 := by
  exact Cert151.result

theorem order620 : AtOrder 19 620 := by
  have : Fact (Nat.Prime 619) := ⟨by norm_num⟩
  exact paley_order 19 619 (by decide)

theorem order628 : AtOrder 19 628 := by
  have : Fact (Nat.Prime 313) := ⟨by norm_num⟩
  exact paley_second 19 313 (by decide)

theorem order632 : AtOrder 19 632 := by
  have : Fact (Nat.Prime 631) := ⟨by norm_num⟩
  exact paley_order 19 631 (by decide)

theorem order636 : AtOrder 19 636 := by
  have : Fact (Nat.Prime 317) := ⟨by norm_num⟩
  exact paley_second 19 317 (by decide)

theorem order640 : AtOrder 19 640 := by
  exact at_mul (a:=2) (b:=320) order2 order320

theorem order644 : AtOrder 19 644 := by
  have : Fact (Nat.Prime 643) := ⟨by norm_num⟩
  exact paley_order 19 643 (by decide)

theorem order652 : AtOrder 19 652 := by
  exact Cert163.result

theorem order656 : AtOrder 19 656 := by
  exact at_mul (a:=4) (b:=164) order4 order164

theorem order664 : AtOrder 19 664 := by
  exact at_mul (a:=2) (b:=332) order2 order332

theorem order668 : AtOrder 19 668 := by
  exact R668.real_matrix 19

theorem order672 : AtOrder 19 672 := by
  exact at_mul (a:=4) (b:=168) order4 order168

theorem order676 : AtOrder 19 676 := by
  have : Fact (Nat.Prime 337) := ⟨by norm_num⟩
  exact paley_second 19 337 (by decide)

theorem order680 : AtOrder 19 680 := by
  exact at_mul (a:=2) (b:=340) order2 order340

theorem order704 : AtOrder 19 704 := by
  exact at_mul (a:=8) (b:=88) order8 order88

theorem order708 : AtOrder 19 708 := by
  have : Fact (Nat.Prime 353) := ⟨by norm_num⟩
  exact paley_second 19 353 (by decide)

theorem order712 : AtOrder 19 712 := by
  exact at_mul (a:=2) (b:=356) order2 order356

theorem order716 : AtOrder 19 716 := by
  exact Cert179.result

theorem order720 : AtOrder 19 720 := by
  have : Fact (Nat.Prime 719) := ⟨by norm_num⟩
  exact paley_order 19 719 (by decide)

theorem order728 : AtOrder 19 728 := by
  have : Fact (Nat.Prime 727) := ⟨by norm_num⟩
  exact paley_order 19 727 (by decide)

theorem order732 : AtOrder 19 732 := by
  exact at_mul (a:=12) (b:=61) order12 order61

theorem order740 : AtOrder 19 740 := by
  have : Fact (Nat.Prime 739) := ⟨by norm_num⟩
  exact paley_order 19 739 (by decide)

theorem order744 : AtOrder 19 744 := by
  have : Fact (Nat.Prime 743) := ⟨by norm_num⟩
  exact paley_order 19 743 (by decide)

theorem order748 : AtOrder 19 748 := by
  have : Fact (Nat.Prime 373) := ⟨by norm_num⟩
  exact paley_second 19 373 (by decide)

theorem order752 : AtOrder 19 752 := by
  have : Fact (Nat.Prime 751) := ⟨by norm_num⟩
  exact paley_order 19 751 (by decide)

theorem order756 : AtOrder 19 756 := by
  exact R756.real_matrix 19

theorem order780 : AtOrder 19 780 := by
  have : Fact (Nat.Prime 389) := ⟨by norm_num⟩
  exact paley_second 19 389 (by decide)

theorem order784 : AtOrder 19 784 := by
  exact at_mul (a:=2) (b:=392) order2 order392

theorem order788 : AtOrder 19 788 := by
  have : Fact (Nat.Prime 787) := ⟨by norm_num⟩
  exact paley_order 19 787 (by decide)

theorem order792 : AtOrder 19 792 := by
  exact at_mul (a:=2) (b:=396) order2 order396

theorem order796 : AtOrder 19 796 := by
  have : Fact (Nat.Prime 397) := ⟨by norm_num⟩
  exact paley_second 19 397 (by decide)

theorem order804 : AtOrder 19 804 := by
  have : Fact (Nat.Prime 401) := ⟨by norm_num⟩
  exact paley_second 19 401 (by decide)

theorem order808 : AtOrder 19 808 := by
  exact Cert202.result

theorem order816 : AtOrder 19 816 := by
  exact at_mul (a:=4) (b:=204) order4 order204

theorem order820 : AtOrder 19 820 := by
  have : Fact (Nat.Prime 409) := ⟨by norm_num⟩
  exact paley_second 19 409 (by decide)

theorem order824 : AtOrder 19 824 := by
  have : Fact (Nat.Prime 823) := ⟨by norm_num⟩
  exact paley_order 19 823 (by decide)

theorem order828 : AtOrder 19 828 := by
  have : Fact (Nat.Prime 827) := ⟨by norm_num⟩
  exact paley_order 19 827 (by decide)

theorem order832 : AtOrder 19 832 := by
  exact at_mul (a:=8) (b:=104) order8 order104

theorem order856 : AtOrder 19 856 := by
  exact at_mul (a:=2) (b:=428) order2 order428

theorem order860 : AtOrder 19 860 := by
  have : Fact (Nat.Prime 859) := ⟨by norm_num⟩
  exact paley_order 19 859 (by decide)

theorem order864 : AtOrder 19 864 := by
  have : Fact (Nat.Prime 863) := ⟨by norm_num⟩
  exact paley_order 19 863 (by decide)

theorem order868 : AtOrder 19 868 := by
  have : Fact (Nat.Prime 433) := ⟨by norm_num⟩
  exact paley_second 19 433 (by decide)

theorem order872 : AtOrder 19 872 := by
  exact at_mul (a:=2) (b:=436) order2 order436

theorem order880 : AtOrder 19 880 := by
  exact at_mul (a:=2) (b:=440) order2 order440

theorem order884 : AtOrder 19 884 := by
  have : Fact (Nat.Prime 883) := ⟨by norm_num⟩
  exact paley_order 19 883 (by decide)

theorem order892 : AtOrder 19 892 := by
  exact R892.real_matrix 19

theorem order896 : AtOrder 19 896 := by
  exact at_mul (a:=4) (b:=224) order4 order224

theorem order900 : AtOrder 19 900 := by
  have : Fact (Nat.Prime 449) := ⟨by norm_num⟩
  exact paley_second 19 449 (by decide)

theorem order904 : AtOrder 19 904 := by
  exact at_mul (a:=2) (b:=452) order2 order452

theorem order908 : AtOrder 19 908 := by
  have : Fact (Nat.Prime 907) := ⟨by norm_num⟩
  exact paley_order 19 907 (by decide)

theorem order932 : AtOrder 19 932 := by
  exact Cert233.result

theorem order936 : AtOrder 19 936 := by
  exact at_mul (a:=2) (b:=468) order2 order468

theorem order948 : AtOrder 19 948 := by
  have : Fact (Nat.Prime 947) := ⟨by norm_num⟩
  exact paley_order 19 947 (by decide)

theorem order956 : AtOrder 19 956 := by
  exact Cert239.result

theorem order960 : AtOrder 19 960 := by
  exact at_mul (a:=2) (b:=480) order2 order480

theorem order968 : AtOrder 19 968 := by
  have : Fact (Nat.Prime 967) := ⟨by norm_num⟩
  exact paley_order 19 967 (by decide)

theorem order972 : AtOrder 19 972 := by
  have : Fact (Nat.Prime 971) := ⟨by norm_num⟩
  exact paley_order 19 971 (by decide)

theorem order976 : AtOrder 19 976 := by
  exact at_mul (a:=2) (b:=488) order2 order488

theorem order980 : AtOrder 19 980 := by
  exact Cert245.result

theorem order984 : AtOrder 19 984 := by
  have : Fact (Nat.Prime 983) := ⟨by norm_num⟩
  exact paley_order 19 983 (by decide)

theorem order1008 : AtOrder 19 1008 := by
  exact at_mul (a:=2) (b:=504) order2 order504

theorem order1016 : AtOrder 19 1016 := by
  exact d9.iterate (n:=180) (by decide) order180 (by decide) 1

theorem order1024 : AtOrder 19 1024 := by
  exact at_mul (a:=8) (b:=128) order8 order128

theorem order1036 : AtOrder 19 1036 := by
  exact Cert259.result

theorem order1044 : AtOrder 19 1044 := by
  have : Fact (Nat.Prime 521) := ⟨by norm_num⟩
  exact paley_second 19 521 (by decide)

theorem order1048 : AtOrder 19 1048 := by
  exact at_mul (a:=2) (b:=524) order2 order524

theorem order1052 : AtOrder 19 1052 := by
  have : Fact (Nat.Prime 1051) := ⟨by norm_num⟩
  exact paley_order 19 1051 (by decide)

theorem order1056 : AtOrder 19 1056 := by
  exact at_mul (a:=4) (b:=264) order4 order264

theorem order1060 : AtOrder 19 1060 := by
  exact Cert265.result

theorem order1084 : AtOrder 19 1084 := by
  have : Fact (Nat.Prime 541) := ⟨by norm_num⟩
  exact paley_second 19 541 (by decide)

theorem order1088 : AtOrder 19 1088 := by
  have : Fact (Nat.Prime 1087) := ⟨by norm_num⟩
  exact paley_order 19 1087 (by decide)

theorem order1092 : AtOrder 19 1092 := by
  have : Fact (Nat.Prime 1091) := ⟨by norm_num⟩
  exact paley_order 19 1091 (by decide)

theorem order1100 : AtOrder 19 1100 := by
  exact R1100.real_matrix 19

theorem order1112 : AtOrder 19 1112 := by
  exact at_mul (a:=2) (b:=556) order2 order556

theorem order1120 : AtOrder 19 1120 := by
  exact at_mul (a:=8) (b:=140) order8 order140

theorem order1124 : AtOrder 19 1124 := by
  have : Fact (Nat.Prime 1123) := ⟨by norm_num⟩
  exact paley_order 19 1123 (by decide)

theorem order1128 : AtOrder 19 1128 := by
  exact at_mul (a:=2) (b:=564) order2 order564

theorem order1132 : AtOrder 19 1132 := by
  exact Cert283.result

theorem order1160 : AtOrder 19 1160 := by
  exact at_mul (a:=2) (b:=580) order2 order580

theorem order1164 : AtOrder 19 1164 := by
  have : Fact (Nat.Prime 1163) := ⟨by norm_num⟩
  exact paley_order 19 1163 (by decide)

theorem order1168 : AtOrder 19 1168 := by
  exact d9.iterate (n:=332) (by decide) order332 (by decide) 1

theorem order1176 : AtOrder 19 1176 := by
  exact at_mul (a:=2) (b:=588) order2 order588

theorem order1188 : AtOrder 19 1188 := by
  have : Fact (Nat.Prime 1187) := ⟨by norm_num⟩
  exact paley_order 19 1187 (by decide)

theorem order1196 : AtOrder 19 1196 := by
  exact at_mul (a:=23) (b:=52) order23 order52

theorem order1200 : AtOrder 19 1200 := by
  exact at_mul (a:=2) (b:=600) order2 order600

theorem order1204 : AtOrder 19 1204 := by
  have : Fact (Nat.Prime 601) := ⟨by norm_num⟩
  exact paley_second 19 601 (by decide)

theorem order1208 : AtOrder 19 1208 := by
  exact at_mul (a:=2) (b:=604) order2 order604

theorem order1236 : AtOrder 19 1236 := by
  have : Fact (Nat.Prime 617) := ⟨by norm_num⟩
  exact paley_second 19 617 (by decide)

theorem order1244 : AtOrder 19 1244 := by
  exact d9.iterate (n:=408) (by decide) order408 (by decide) 1

theorem order1252 : AtOrder 19 1252 := by
  exact Cert313.result

theorem order1264 : AtOrder 19 1264 := by
  exact at_mul (a:=2) (b:=632) order2 order632

theorem order1272 : AtOrder 19 1272 := by
  exact at_mul (a:=2) (b:=636) order2 order636

theorem order1276 : AtOrder 19 1276 := by
  exact Cert319.result

theorem order1280 : AtOrder 19 1280 := by
  have : Fact (Nat.Prime 1279) := ⟨by norm_num⟩
  exact paley_order 19 1279 (by decide)

theorem order1284 : AtOrder 19 1284 := by
  have : Fact (Nat.Prime 1283) := ⟨by norm_num⟩
  exact paley_order 19 1283 (by decide)

theorem order1312 : AtOrder 19 1312 := by
  exact at_mul (a:=8) (b:=164) order8 order164

theorem order1328 : AtOrder 19 1328 := by
  have : Fact (Nat.Prime 1327) := ⟨by norm_num⟩
  exact paley_order 19 1327 (by decide)

theorem order1340 : AtOrder 19 1340 := by
  exact Cert335.result

theorem order1348 : AtOrder 19 1348 := by
  have : Fact (Nat.Prime 673) := ⟨by norm_num⟩
  exact paley_second 19 673 (by decide)

theorem order1352 : AtOrder 19 1352 := by
  exact at_mul (a:=2) (b:=676) order2 order676

theorem order1356 : AtOrder 19 1356 := by
  have : Fact (Nat.Prime 677) := ⟨by norm_num⟩
  exact paley_second 19 677 (by decide)

theorem order1360 : AtOrder 19 1360 := by
  exact at_mul (a:=20) (b:=68) order20 order68

theorem order1364 : AtOrder 19 1364 := by
  exact d15.iterate (n:=300) (by decide) order300 (by decide) 1

theorem order1388 : AtOrder 19 1388 := by
  exact Cert347.result

theorem order1404 : AtOrder 19 1404 := by
  have : Fact (Nat.Prime 701) := ⟨by norm_num⟩
  exact paley_second 19 701 (by decide)

theorem order1416 : AtOrder 19 1416 := by
  exact at_mul (a:=2) (b:=708) order2 order708

theorem order1424 : AtOrder 19 1424 := by
  have : Fact (Nat.Prime 1423) := ⟨by norm_num⟩
  exact paley_order 19 1423 (by decide)

theorem order1428 : AtOrder 19 1428 := by
  have : Fact (Nat.Prime 1427) := ⟨by norm_num⟩
  exact paley_order 19 1427 (by decide)

theorem order1432 : AtOrder 19 1432 := by
  exact at_mul (a:=2) (b:=716) order2 order716

theorem order1436 : AtOrder 19 1436 := by
  exact Cert359.result

theorem order1464 : AtOrder 19 1464 := by
  exact at_mul (a:=24) (b:=61) order24 order61

theorem order1480 : AtOrder 19 1480 := by
  exact at_mul (a:=2) (b:=740) order2 order740

theorem order1492 : AtOrder 19 1492 := by
  exact Cert373.result

theorem order1500 : AtOrder 19 1500 := by
  have : Fact (Nat.Prime 1499) := ⟨by norm_num⟩
  exact paley_order 19 1499 (by decide)

theorem order1504 : AtOrder 19 1504 := by
  exact at_mul (a:=2) (b:=752) order2 order752

theorem order1508 : AtOrder 19 1508 := by
  exact Cert377.result

theorem order1512 : AtOrder 19 1512 := by
  have : Fact (Nat.Prime 1511) := ⟨by norm_num⟩
  exact paley_order 19 1511 (by decide)

theorem order1516 : AtOrder 19 1516 := by
  have : Fact (Nat.Prime 757) := ⟨by norm_num⟩
  exact paley_second 19 757 (by decide)

theorem order1540 : AtOrder 19 1540 := by
  have : Fact (Nat.Prime 769) := ⟨by norm_num⟩
  exact paley_second 19 769 (by decide)

theorem order1556 : AtOrder 19 1556 := by
  exact Cert389.result

theorem order1568 : AtOrder 19 1568 := by
  have : Fact (Nat.Prime 1567) := ⟨by norm_num⟩
  exact paley_order 19 1567 (by decide)

theorem order1576 : AtOrder 19 1576 := by
  exact at_mul (a:=2) (b:=788) order2 order788

theorem order1580 : AtOrder 19 1580 := by
  have : Fact (Nat.Prime 1579) := ⟨by norm_num⟩
  exact paley_order 19 1579 (by decide)

theorem order1584 : AtOrder 19 1584 := by
  have : Fact (Nat.Prime 1583) := ⟨by norm_num⟩
  exact paley_order 19 1583 (by decide)

theorem order1588 : AtOrder 19 1588 := by
  exact Cert397.result

theorem order1632 : AtOrder 19 1632 := by
  exact at_mul (a:=8) (b:=204) order8 order204

theorem order1644 : AtOrder 19 1644 := by
  have : Fact (Nat.Prime 821) := ⟨by norm_num⟩
  exact paley_second 19 821 (by decide)

theorem order1652 : AtOrder 19 1652 := by
  exact Cert413.result

theorem order1656 : AtOrder 19 1656 := by
  exact at_mul (a:=2) (b:=828) order2 order828

theorem order1660 : AtOrder 19 1660 := by
  have : Fact (Nat.Prime 829) := ⟨by norm_num⟩
  exact paley_second 19 829 (by decide)

theorem order1664 : AtOrder 19 1664 := by
  have : Fact (Nat.Prime 1663) := ⟨by norm_num⟩
  exact paley_order 19 1663 (by decide)

theorem order1668 : AtOrder 19 1668 := by
  have : Fact (Nat.Prime 1667) := ⟨by norm_num⟩
  exact paley_order 19 1667 (by decide)

theorem order1708 : AtOrder 19 1708 := by
  have : Fact (Nat.Prime 853) := ⟨by norm_num⟩
  exact paley_second 19 853 (by decide)

theorem order1720 : AtOrder 19 1720 := by
  exact at_mul (a:=2) (b:=860) order2 order860

theorem order1728 : AtOrder 19 1728 := by
  exact at_mul (a:=2) (b:=864) order2 order864

theorem order1732 : AtOrder 19 1732 := by
  exact Cert433.result

theorem order1736 : AtOrder 19 1736 := by
  exact at_mul (a:=2) (b:=868) order2 order868

theorem order1740 : AtOrder 19 1740 := by
  exact R1740.real_matrix 19

theorem order1744 : AtOrder 19 1744 := by
  exact d15.iterate (n:=680) (by decide) order680 (by decide) 1

theorem order1784 : AtOrder 19 1784 := by
  have : Fact (Nat.Prime 1783) := ⟨by norm_num⟩
  exact paley_order 19 1783 (by decide)

theorem order1796 : AtOrder 19 1796 := by
  exact R1796.real_matrix 19

theorem order1804 : AtOrder 19 1804 := by
  exact Cert451.result

theorem order1808 : AtOrder 19 1808 := by
  exact at_mul (a:=4) (b:=452) order4 order452

theorem order1812 : AtOrder 19 1812 := by
  have : Fact (Nat.Prime 1811) := ⟨by norm_num⟩
  exact paley_order 19 1811 (by decide)

theorem order1816 : AtOrder 19 1816 := by
  exact at_mul (a:=2) (b:=908) order2 order908

theorem order1820 : AtOrder 19 1820 := by
  exact d15.iterate (n:=756) (by decide) order756 (by decide) 1

theorem order1860 : AtOrder 19 1860 := by
  have : Fact (Nat.Prime 929) := ⟨by norm_num⟩
  exact paley_second 19 929 (by decide)

theorem order1872 : AtOrder 19 1872 := by
  have : Fact (Nat.Prime 1871) := ⟨by norm_num⟩
  exact paley_order 19 1871 (by decide)

theorem order1880 : AtOrder 19 1880 := by
  have : Fact (Nat.Prime 1879) := ⟨by norm_num⟩
  exact paley_order 19 1879 (by decide)

theorem order1884 : AtOrder 19 1884 := by
  have : Fact (Nat.Prime 941) := ⟨by norm_num⟩
  exact paley_second 19 941 (by decide)

theorem order1888 : AtOrder 19 1888 := by
  exact at_mul (a:=4) (b:=472) order4 order472

theorem order1892 : AtOrder 19 1892 := by
  exact Cert473.result

theorem order1936 : AtOrder 19 1936 := by
  exact at_mul (a:=2) (b:=968) order2 order968

theorem order1948 : AtOrder 19 1948 := by
  exact Cert487.result

theorem order1956 : AtOrder 19 1956 := by
  have : Fact (Nat.Prime 977) := ⟨by norm_num⟩
  exact paley_second 19 977 (by decide)

theorem order1960 : AtOrder 19 1960 := by
  exact at_mul (a:=2) (b:=980) order2 order980

theorem order1964 : AtOrder 19 1964 := by
  exact Cert491.result

theorem order1968 : AtOrder 19 1968 := by
  exact at_mul (a:=2) (b:=984) order2 order984

theorem order2012 : AtOrder 19 2012 := by
  have : Fact (Nat.Prime 2011) := ⟨by norm_num⟩
  exact paley_order 19 2011 (by decide)

theorem order2024 : AtOrder 19 2024 := by
  exact at_mul (a:=23) (b:=88) order23 order88

theorem order2032 : AtOrder 19 2032 := by
  exact at_mul (a:=2) (b:=1016) order2 order1016

theorem order2036 : AtOrder 19 2036 := by
  exact Cert509.result

theorem order2040 : AtOrder 19 2040 := by
  have : Fact (Nat.Prime 2039) := ⟨by norm_num⟩
  exact paley_order 19 2039 (by decide)

theorem order2044 : AtOrder 19 2044 := by
  have : Fact (Nat.Prime 1021) := ⟨by norm_num⟩
  exact paley_second 19 1021 (by decide)

theorem order2088 : AtOrder 19 2088 := by
  have : Fact (Nat.Prime 2087) := ⟨by norm_num⟩
  exact paley_order 19 2087 (by decide)

theorem order2100 : AtOrder 19 2100 := by
  have : Fact (Nat.Prime 2099) := ⟨by norm_num⟩
  exact paley_order 19 2099 (by decide)

theorem order2108 : AtOrder 19 2108 := by
  exact Cert527.result

theorem order2112 : AtOrder 19 2112 := by
  have : Fact (Nat.Prime 2111) := ⟨by norm_num⟩
  exact paley_order 19 2111 (by decide)

theorem order2116 : AtOrder 19 2116 := by
  exact at_mul (a:=23) (b:=92) order23 order92

theorem order2120 : AtOrder 19 2120 := by
  exact at_mul (a:=2) (b:=1060) order2 order1060

theorem order2164 : AtOrder 19 2164 := by
  exact Cert541.result

theorem order2176 : AtOrder 19 2176 := by
  exact at_mul (a:=2) (b:=1088) order2 order1088

theorem order2184 : AtOrder 19 2184 := by
  exact at_mul (a:=2) (b:=1092) order2 order1092

theorem order2188 : AtOrder 19 2188 := by
  have : Fact (Nat.Prime 1093) := ⟨by norm_num⟩
  exact paley_second 19 1093 (by decide)

theorem order2192 : AtOrder 19 2192 := by
  exact at_mul (a:=4) (b:=548) order4 order548

theorem order2196 : AtOrder 19 2196 := by
  have : Fact (Nat.Prime 1097) := ⟨by norm_num⟩
  exact paley_second 19 1097 (by decide)

theorem order2252 : AtOrder 19 2252 := by
  have : Fact (Nat.Prime 2251) := ⟨by norm_num⟩
  exact paley_order 19 2251 (by decide)

theorem order2260 : AtOrder 19 2260 := by
  have : Fact (Nat.Prime 1129) := ⟨by norm_num⟩
  exact paley_second 19 1129 (by decide)

theorem order2264 : AtOrder 19 2264 := by
  exact at_mul (a:=2) (b:=1132) order2 order1132

theorem order2272 : AtOrder 19 2272 := by
  exact at_mul (a:=8) (b:=284) order8 order284

theorem order2328 : AtOrder 19 2328 := by
  exact at_mul (a:=2) (b:=1164) order2 order1164

theorem order2336 : AtOrder 19 2336 := by
  exact at_mul (a:=2) (b:=1168) order2 order1168

theorem order2340 : AtOrder 19 2340 := by
  have : Fact (Nat.Prime 2339) := ⟨by norm_num⟩
  exact paley_order 19 2339 (by decide)

theorem order2348 : AtOrder 19 2348 := by
  have : Fact (Nat.Prime 2347) := ⟨by norm_num⟩
  exact paley_order 19 2347 (by decide)

theorem order2404 : AtOrder 19 2404 := by
  have : Fact (Nat.Prime 1201) := ⟨by norm_num⟩
  exact paley_second 19 1201 (by decide)

theorem order2412 : AtOrder 19 2412 := by
  have : Fact (Nat.Prime 2411) := ⟨by norm_num⟩
  exact paley_order 19 2411 (by decide)

theorem order2416 : AtOrder 19 2416 := by
  exact at_mul (a:=4) (b:=604) order4 order604

theorem order2424 : AtOrder 19 2424 := by
  have : Fact (Nat.Prime 2423) := ⟨by norm_num⟩
  exact paley_order 19 2423 (by decide)

theorem order2480 : AtOrder 19 2480 := by
  exact at_mul (a:=4) (b:=620) order4 order620

theorem order2488 : AtOrder 19 2488 := by
  exact at_mul (a:=2) (b:=1244) order2 order1244

theorem order2492 : AtOrder 19 2492 := by
  exact Cert623.result

theorem order2500 : AtOrder 19 2500 := by
  have : Fact (Nat.Prime 1249) := ⟨by norm_num⟩
  exact paley_second 19 1249 (by decide)

theorem order2556 : AtOrder 19 2556 := by
  have : Fact (Nat.Prime 1277) := ⟨by norm_num⟩
  exact paley_second 19 1277 (by decide)

theorem order2564 : AtOrder 19 2564 := by
  exact R2564.real_matrix 19

theorem order2568 : AtOrder 19 2568 := by
  exact at_mul (a:=2) (b:=1284) order2 order1284

theorem order2576 : AtOrder 19 2576 := by
  exact at_mul (a:=4) (b:=644) order4 order644

theorem order2644 : AtOrder 19 2644 := by
  have : Fact (Nat.Prime 1321) := ⟨by norm_num⟩
  exact paley_second 19 1321 (by decide)

theorem order2652 : AtOrder 19 2652 := by
  exact R2652.real_matrix 19

theorem order2720 : AtOrder 19 2720 := by
  have : Fact (Nat.Prime 2719) := ⟨by norm_num⟩
  exact paley_order 19 2719 (by decide)

theorem order2728 : AtOrder 19 2728 := by
  exact at_mul (a:=2) (b:=1364) order2 order1364

theorem order2796 : AtOrder 19 2796 := by
  exact Cert699.result

theorem order2804 : AtOrder 19 2804 := by
  have : Fact (Nat.Prime 2803) := ⟨by norm_num⟩
  exact paley_order 19 2803 (by decide)

theorem order2872 : AtOrder 19 2872 := by
  exact at_mul (a:=2) (b:=1436) order2 order1436

theorem order2880 : AtOrder 19 2880 := by
  have : Fact (Nat.Prime 2879) := ⟨by norm_num⟩
  exact paley_order 19 2879 (by decide)

theorem order2948 : AtOrder 19 2948 := by
  exact Cert737.result

theorem order2956 : AtOrder 19 2956 := by
  exact Cert739.result

theorem order3024 : AtOrder 19 3024 := by
  have : Fact (Nat.Prime 3023) := ⟨by norm_num⟩
  exact paley_order 19 3023 (by decide)

theorem order3032 : AtOrder 19 3032 := by
  exact at_mul (a:=2) (b:=1516) order2 order1516

theorem order3100 : AtOrder 19 3100 := by
  have : Fact (Nat.Prime 1549) := ⟨by norm_num⟩
  exact paley_second 19 1549 (by decide)

theorem order3108 : AtOrder 19 3108 := by
  have : Fact (Nat.Prime 1553) := ⟨by norm_num⟩
  exact paley_second 19 1553 (by decide)

theorem order3176 : AtOrder 19 3176 := by
  exact at_mul (a:=2) (b:=1588) order2 order1588

theorem order3184 : AtOrder 19 3184 := by
  exact at_mul (a:=4) (b:=796) order4 order796

theorem order3252 : AtOrder 19 3252 := by
  have : Fact (Nat.Prime 3251) := ⟨by norm_num⟩
  exact paley_order 19 3251 (by decide)

theorem order3260 : AtOrder 19 3260 := by
  have : Fact (Nat.Prime 3259) := ⟨by norm_num⟩
  exact paley_order 19 3259 (by decide)

theorem order3328 : AtOrder 19 3328 := by
  exact at_mul (a:=2) (b:=1664) order2 order1664

theorem order3336 : AtOrder 19 3336 := by
  exact at_mul (a:=2) (b:=1668) order2 order1668

theorem order3404 : AtOrder 19 3404 := by
  exact at_mul (a:=23) (b:=148) order23 order148

theorem order3412 : AtOrder 19 3412 := by
  exact Cert853.result

theorem order3480 : AtOrder 19 3480 := by
  exact at_mul (a:=2) (b:=1740) order2 order1740

theorem order3488 : AtOrder 19 3488 := by
  exact at_mul (a:=2) (b:=1744) order2 order1744

theorem order3556 : AtOrder 19 3556 := by
  have : Fact (Nat.Prime 1777) := ⟨by norm_num⟩
  exact paley_second 19 1777 (by decide)

theorem order3564 : AtOrder 19 3564 := by
  exact at_mul (a:=36) (b:=99) order36 order99

theorem order3632 : AtOrder 19 3632 := by
  have : Fact (Nat.Prime 3631) := ⟨by norm_num⟩
  exact paley_order 19 3631 (by decide)

theorem order3640 : AtOrder 19 3640 := by
  exact at_mul (a:=2) (b:=1820) order2 order1820

theorem order3708 : AtOrder 19 3708 := by
  exact Cert927.result

theorem order3716 : AtOrder 19 3716 := by
  exact Cert929.result

theorem order3784 : AtOrder 19 3784 := by
  exact at_mul (a:=2) (b:=1892) order2 order1892

theorem order3792 : AtOrder 19 3792 := by
  exact at_mul (a:=4) (b:=948) order4 order948

theorem order3860 : AtOrder 19 3860 := by
  exact Cert965.result

theorem order3868 : AtOrder 19 3868 := by
  have : Fact (Nat.Prime 1933) := ⟨by norm_num⟩
  exact paley_second 19 1933 (by decide)

theorem order3936 : AtOrder 19 3936 := by
  exact at_mul (a:=4) (b:=984) order4 order984

theorem order3944 : AtOrder 19 3944 := by
  have : Fact (Nat.Prime 3943) := ⟨by norm_num⟩
  exact paley_order 19 3943 (by decide)

theorem seed1 (k : ℕ) (pos:0<k) (small:k≤399) (res:(4*k)%19=1) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 400, 0 < i.val → (4*i.val)%19=1 → i.val ∈ ([5,24,43,62,81,100,119,138,157,176,195,214,233,252,271,290,309,328,347,366,385]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact order20
  · exact order96
  · exact order172
  · exact order248
  · exact order324
  · exact order400
  · exact order476
  · exact order552
  · exact order628
  · exact order704
  · exact order780
  · exact order856
  · exact order932
  · exact order1008
  · exact order1084
  · exact order1160
  · exact order1236
  · exact order1312
  · exact order1388
  · exact order1464
  · exact order1540

theorem seed5 (k : ℕ) (pos:0<k) (small:k≤247) (res:(4*k)%19=5) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 248, 0 < i.val → (4*i.val)%19=5 → i.val ∈ ([6,25,44,63,82,101,120,139,158,177,196,215,234]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact order24
  · exact order100
  · exact order176
  · exact order252
  · exact order328
  · exact order404
  · exact order480
  · exact order556
  · exact order632
  · exact order708
  · exact order784
  · exact order860
  · exact order936

theorem seed9 (k : ℕ) (pos:0<k) (small:k≤209) (res:(4*k)%19=9) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 210, 0 < i.val → (4*i.val)%19=9 → i.val ∈ ([7,26,45,64,83,102,121,140,159,178,197]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact order28
  · exact order104
  · exact order180
  · exact order256
  · exact order332
  · exact order408
  · exact order484
  · exact order560
  · exact order636
  · exact order712
  · exact order788

theorem seed13 (k : ℕ) (pos:0<k) (small:k≤209) (res:(4*k)%19=13) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 210, 0 < i.val → (4*i.val)%19=13 → i.val ∈ ([8,27,46,65,84,103,122,141,160,179,198]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact order32
  · exact order108
  · exact order184
  · exact order260
  · exact order336
  · exact order412
  · exact order488
  · exact order564
  · exact order640
  · exact order716
  · exact order792

theorem seed17 (k : ℕ) (pos:0<k) (small:k≤551) (res:(4*k)%19=17) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 552, 0 < i.val → (4*i.val)%19=17 → i.val ∈ ([9,28,47,66,85,104,123,142,161,180,199,218,237,256,275,294,313,332,351,370,389,408,427,446,465,484,503,522,541]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact order36
  · exact order112
  · exact order188
  · exact order264
  · exact order340
  · exact order416
  · exact order492
  · exact order568
  · exact order644
  · exact order720
  · exact order796
  · exact order872
  · exact order948
  · exact order1024
  · exact order1100
  · exact order1176
  · exact order1252
  · exact order1328
  · exact order1404
  · exact order1480
  · exact order1556
  · exact order1632
  · exact order1708
  · exact order1784
  · exact order1860
  · exact order1936
  · exact order2012
  · exact order2088
  · exact order2164

theorem seed2 (k : ℕ) (pos:0<k) (small:k≤19) (res:(4*k)%19=2) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 20, 0 < i.val → (4*i.val)%19=2 → i.val ∈ ([10]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl
  · exact order40

theorem seed6 (k : ℕ) (pos:0<k) (small:k≤247) (res:(4*k)%19=6) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 248, 0 < i.val → (4*i.val)%19=6 → i.val ∈ ([11,30,49,68,87,106,125,144,163,182,201,220,239]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact order44
  · exact order120
  · exact order196
  · exact order272
  · exact order348
  · exact order424
  · exact order500
  · exact order576
  · exact order652
  · exact order728
  · exact order804
  · exact order880
  · exact order956

theorem seed10 (k : ℕ) (pos:0<k) (small:k≤646) (res:(4*k)%19=10) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 647, 0 < i.val → (4*i.val)%19=10 → i.val ∈ ([12,31,50,69,88,107,126,145,164,183,202,221,240,259,278,297,316,335,354,373,392,411,430,449,468,487,506,525,544,563,582,601,620,639]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact order48
  · exact order124
  · exact order200
  · exact order276
  · exact order352
  · exact order428
  · exact order504
  · exact order580
  · exact order656
  · exact order732
  · exact order808
  · exact order884
  · exact order960
  · exact order1036
  · exact order1112
  · exact order1188
  · exact order1264
  · exact order1340
  · exact order1416
  · exact order1492
  · exact order1568
  · exact order1644
  · exact order1720
  · exact order1796
  · exact order1872
  · exact order1948
  · exact order2024
  · exact order2100
  · exact order2176
  · exact order2252
  · exact order2328
  · exact order2404
  · exact order2480
  · exact order2556

theorem seed14 (k : ℕ) (pos:0<k) (small:k≤38) (res:(4*k)%19=14) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 39, 0 < i.val → (4*i.val)%19=14 → i.val ∈ ([13,32]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl
  · exact order52
  · exact order128

theorem seed18 (k : ℕ) (pos:0<k) (small:k≤646) (res:(4*k)%19=18) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 647, 0 < i.val → (4*i.val)%19=18 → i.val ∈ ([14,33,52,71,90,109,128,147,166,185,204,223,242,261,280,299,318,337,356,375,394,413,432,451,470,489,508,527,546,565,584,603,622,641]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact order56
  · exact order132
  · exact order208
  · exact order284
  · exact order360
  · exact order436
  · exact order512
  · exact order588
  · exact order664
  · exact order740
  · exact order816
  · exact order892
  · exact order968
  · exact order1044
  · exact order1120
  · exact order1196
  · exact order1272
  · exact order1348
  · exact order1424
  · exact order1500
  · exact order1576
  · exact order1652
  · exact order1728
  · exact order1804
  · exact order1880
  · exact order1956
  · exact order2032
  · exact order2108
  · exact order2184
  · exact order2260
  · exact order2336
  · exact order2412
  · exact order2488
  · exact order2564

theorem seed3 (k : ℕ) (pos:0<k) (small:k≤988) (res:(4*k)%19=3) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 989, 0 < i.val → (4*i.val)%19=3 → i.val ∈ ([15,34,53,72,91,110,129,148,167,186,205,224,243,262,281,300,319,338,357,376,395,414,433,452,471,490,509,528,547,566,585,604,623,642,661,680,699,718,737,756,775,794,813,832,851,870,889,908,927,946,965,984]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact order60
  · exact order136
  · exact order212
  · exact order288
  · exact order364
  · exact order440
  · exact order516
  · exact order592
  · exact order668
  · exact order744
  · exact order820
  · exact order896
  · exact order972
  · exact order1048
  · exact order1124
  · exact order1200
  · exact order1276
  · exact order1352
  · exact order1428
  · exact order1504
  · exact order1580
  · exact order1656
  · exact order1732
  · exact order1808
  · exact order1884
  · exact order1960
  · exact order2036
  · exact order2112
  · exact order2188
  · exact order2264
  · exact order2340
  · exact order2416
  · exact order2492
  · exact order2568
  · exact order2644
  · exact order2720
  · exact order2796
  · exact order2872
  · exact order2948
  · exact order3024
  · exact order3100
  · exact order3176
  · exact order3252
  · exact order3328
  · exact order3404
  · exact order3480
  · exact order3556
  · exact order3632
  · exact order3708
  · exact order3784
  · exact order3860
  · exact order3936

theorem seed7 (k : ℕ) (pos:0<k) (small:k≤551) (res:(4*k)%19=7) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 552, 0 < i.val → (4*i.val)%19=7 → i.val ∈ ([16,35,54,73,92,111,130,149,168,187,206,225,244,263,282,301,320,339,358,377,396,415,434,453,472,491,510,529,548]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact order64
  · exact order140
  · exact order216
  · exact order292
  · exact order368
  · exact order444
  · exact order520
  · exact order596
  · exact order672
  · exact order748
  · exact order824
  · exact order900
  · exact order976
  · exact order1052
  · exact order1128
  · exact order1204
  · exact order1280
  · exact order1356
  · exact order1432
  · exact order1508
  · exact order1584
  · exact order1660
  · exact order1736
  · exact order1812
  · exact order1888
  · exact order1964
  · exact order2040
  · exact order2116
  · exact order2192

theorem seed11 (k : ℕ) (pos:0<k) (small:k≤988) (res:(4*k)%19=11) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 989, 0 < i.val → (4*i.val)%19=11 → i.val ∈ ([17,36,55,74,93,112,131,150,169,188,207,226,245,264,283,302,321,340,359,378,397,416,435,454,473,492,511,530,549,568,587,606,625,644,663,682,701,720,739,758,777,796,815,834,853,872,891,910,929,948,967,986]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact order68
  · exact order144
  · exact order220
  · exact order296
  · exact order372
  · exact order448
  · exact order524
  · exact order600
  · exact order676
  · exact order752
  · exact order828
  · exact order904
  · exact order980
  · exact order1056
  · exact order1132
  · exact order1208
  · exact order1284
  · exact order1360
  · exact order1436
  · exact order1512
  · exact order1588
  · exact order1664
  · exact order1740
  · exact order1816
  · exact order1892
  · exact order1968
  · exact order2044
  · exact order2120
  · exact order2196
  · exact order2272
  · exact order2348
  · exact order2424
  · exact order2500
  · exact order2576
  · exact order2652
  · exact order2728
  · exact order2804
  · exact order2880
  · exact order2956
  · exact order3032
  · exact order3108
  · exact order3184
  · exact order3260
  · exact order3336
  · exact order3412
  · exact order3488
  · exact order3564
  · exact order3640
  · exact order3716
  · exact order3792
  · exact order3868
  · exact order3944

theorem seed15 (k : ℕ) (pos:0<k) (small:k≤266) (res:(4*k)%19=15) : AtOrder 19 (4*k) := by
  have check : ∀ i : Fin 267, 0 < i.val → (4*i.val)%19=15 → i.val ∈ ([18,37,56,75,94,113,132,151,170,189,208,227,246,265]:List ℕ) := by decide +kernel
  have h := check ⟨k,by omega⟩ pos res
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact order72
  · exact order148
  · exact order224
  · exact order300
  · exact order376
  · exact order452
  · exact order528
  · exact order604
  · exact order680
  · exact order756
  · exact order832
  · exact order908
  · exact order984
  · exact order1060
end HadamardMod.Nineteen
